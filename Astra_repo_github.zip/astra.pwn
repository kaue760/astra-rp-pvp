// Astra RP/PVP - arquivo principal (as partes ficam na mesma pasta)
#include "astra_p1.pwn"
#include "astra_p2.pwn"
#include "astra_p3.pwn"
#include "astra_p4.pwn"
