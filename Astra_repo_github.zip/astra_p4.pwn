public OnPlayerClickPlayer(playerid, clickedplayerid, source)
{
if(AstraModo[playerid] == ASTRA_MODO_PVP) return 1;
return 1;
}
public OnPlayerClickPlayerTextDraw(playerid, PlayerText:playertextid)
{
if(AstraModo[playerid] == ASTRA_MODO_PVP) return PVP_OnPlayerClickPlayerTextDraw(playerid, playertextid);
if(playertextid != PlayerText:INVALID_TEXT_DRAW)
{
if(playertextid == TextLoginP[playerid][6])
{
CancelSelectTextDraw(playerid);
for(new t; t < 22; t++)
{
PlayerTextDrawHide(playerid, TextLoginP[playerid][t]);
}
for(new t; t < 3; t++)
{
TextDrawHideForPlayer(playerid, TextLogin[t]);
}
Astra_EscolherModo(playerid);
PlayerTextDrawSetSelectable(playerid, TextLoginP[playerid][6], 0);
}
else if(playertextid == TextLoginP[playerid][7])
{
if(AcertouAsenha[playerid] == false)
{
ShowPlayerDialog(playerid, D_RECUPERAR, DIALOG_STYLE_INPUT, "{058AFF}Recupere sua conta", "\n{FFFFFF}Digite seu {04B404}nick {FFFFFF}abaixo para recuperar sua conta\n\nEnviaremos um {04B404}email {FFFFFF}para voce com as instru�oes", "Recuperar", "Logar");
}
else
{
SendClientMessage(playerid, COR_ERRO, "| ERRO | Voce ja fez o login, clique no botao 'ENTRAR' para jogar");
}
}
else if(playertextid == TextCellP[playerid][6])
{
for(new t; t < 7; t++)
{
PlayerTextDrawHide(playerid, TextCellP[playerid][t]);
}
new hh, mm, ss, dater[10]; gettime(hh, mm, ss); format(dater, sizeof(dater), "%02d:%02d", hh, mm);
TextDrawSetString(TextCell[12], dater);
TextDrawShowForPlayer(playerid, TextCell[12]);
for(new t = 14; t < 54; t++)
{
TextDrawShowForPlayer(playerid, TextCell[t]);
}
}
else if(playertextid == TextMegaSena[playerid][26])
{
CancelSelectTextDraw(playerid);
for(new t; t < 43; t++)
{
PlayerTextDrawHide(playerid, TextMegaSena[playerid][t]);
}
if(NumeroSelecionado[playerid][0] > 0 && NumeroSelecionado[playerid][1] > 0 && NumeroSelecionado[playerid][2] > 0)
{
if(Money[playerid] >= 500)
{
if(NumeroSelecionado[playerid][0] != NumeroSelecionado[playerid][1] && NumeroSelecionado[playerid][1] != NumeroSelecionado[playerid][2] && NumeroSelecionado[playerid][0] != NumeroSelecionado[playerid][2])
{
new a;
for(new m; m < MAX_PLAYERS; m++)
{
for(new mm; mm < 3; mm++)
{
if(NumeroMegaSena[m][mm] == NumeroSelecionado[playerid][0] || NumeroMegaSena[m][mm] == NumeroSelecionado[playerid][1] || NumeroMegaSena[m][mm] == NumeroSelecionado[playerid][2])
{
a ++;
}
}
if(a >= 3)
{
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Esses numeros ja foram escolhidos");
}
a = 0;
}
for(new m; m < MAX_PLAYERS; m++)
{
if(new_strcmp(NomeMegaSena[m], "Ninguem"))
{
format(NomeMegaSena[m], 25, "%s", PlayerName(playerid));
NumeroMegaSena[m][0] = NumeroSelecionado[playerid][0]; NumeroMegaSena[m][1] = NumeroSelecionado[playerid][1]; NumeroMegaSena[m][2] = NumeroSelecionado[playerid][2];
format(String, sizeof(String), "| MEGA-SENA | Voce jogou na Mega-Sena com sucesso, seus numeros: {00FF00}%02d-%02d-%02d{FFFFFF}, boa sorte!", NumeroSelecionado[playerid][0], NumeroSelecionado[playerid][1], NumeroSelecionado[playerid][2]);
SendClientMessage(playerid, -1, String);
Money[playerid] -= 500;
AcumuladosMegasena += 500;
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | A Mega-Sena ja chegou no limite de apostadores");
}
else
{
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Voce marcou numeros repetidos");
}
}
else
{
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Voce nao tem dinheiro suficiente");
}
}
}
else if(playertextid == TextSkinP[playerid][0])
{
CancelSelectTextDraw(playerid);
SetPlayerVirtualWorld(playerid, 0);
}
else if(playertextid == TextInvP[playerid][0])
{
PlayerPlaySound(playerid, 6400, 0, 0, 0);
for(new i; i < 15; i++)
{
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][i+3], -196);
if(SlotMochila[playerid][i] > 0)
{
ItemPreviewRot(playerid, SlotMochila[playerid][i], TextInvP[playerid][i+3]);
if(QuantidadeSlotMochila[playerid][i] == 0)
{
QuantidadeSlotMochila[playerid][i] = 1;
}
}
else if(SlotMochila[playerid][i] == 0)
{
QuantidadeSlotMochila[playerid][i] = 0;
PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][i+3], -10.000000, 0.000000, -20.000000, 111.000000);
}
PlayerTextDrawShow(playerid, TextInvP[playerid][i+3]);
new strquantidade[4];
if(QuantidadeSlotMochila[playerid][i] > 0) format(strquantidade, sizeof(strquantidade), "%d", QuantidadeSlotMochila[playerid][i]);
else strquantidade = "";
PlayerTextDrawSetString(playerid, TextInvP[playerid][i+28], strquantidade);
}
PaginaAtual[playerid] = 0;
if(SlotSelecionado[playerid] > -1 && PaginaAtual[playerid] == PaginaSelecionada[playerid])
{
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], 0xFA585855);
PlayerTextDrawShow(playerid, TextInvP[playerid][SlotSelecionado[playerid]]);
}
PlayerTextDrawColor(playerid, TextInvP[playerid][0], 0x6B54B6FF); PlayerTextDrawShow(playerid, TextInvP[playerid][0]);
PlayerTextDrawColor(playerid, TextInvP[playerid][1], -2071690138); PlayerTextDrawShow(playerid, TextInvP[playerid][1]);
PlayerTextDrawColor(playerid, TextInvP[playerid][2], -2071690206); PlayerTextDrawShow(playerid, TextInvP[playerid][2]);
}
else if(playertextid == TextInvP[playerid][1])
{
if(Mochila[playerid] < 1)
{
MsgAviso(playerid, 3, "~r~~h~PAGINA DE INVENTARIO BLOQUEADA");
return 1;
}
PlayerPlaySound(playerid, 6400, 0, 0, 0);
for(new i; i < 15; i++)
{
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][i+3], -196);
if(SlotMochila[playerid][i+15] > 0)
{
ItemPreviewRot(playerid, SlotMochila[playerid][i+15], TextInvP[playerid][i+3]);
if(QuantidadeSlotMochila[playerid][i] == 0)
{
QuantidadeSlotMochila[playerid][i] = 1;
}
}
else if(SlotMochila[playerid][i+15] == 0)
{
PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][i+3], -10.000000, 0.000000, -20.000000, 111.000000);
}
PlayerTextDrawShow(playerid, TextInvP[playerid][i+3]);
new strquantidade[4];
if(QuantidadeSlotMochila[playerid][i+15] > 0) format(strquantidade, sizeof(strquantidade), "%d", QuantidadeSlotMochila[playerid][i+15]);
else strquantidade = "";
PlayerTextDrawSetString(playerid, TextInvP[playerid][i+28], strquantidade);
}
PaginaAtual[playerid] = 1;
if(SlotSelecionado[playerid] > -1 && PaginaAtual[playerid] == PaginaSelecionada[playerid])
{
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], 0xFA585855);
PlayerTextDrawShow(playerid, TextInvP[playerid][SlotSelecionado[playerid]]);
}
PlayerTextDrawColor(playerid, TextInvP[playerid][0], -2071689985); PlayerTextDrawShow(playerid, TextInvP[playerid][0]);
PlayerTextDrawColor(playerid, TextInvP[playerid][1], 0x6B54B6FF); PlayerTextDrawShow(playerid, TextInvP[playerid][1]);
PlayerTextDrawColor(playerid, TextInvP[playerid][2], -2071690206); PlayerTextDrawShow(playerid, TextInvP[playerid][2]);
}
else if(playertextid == TextInvP[playerid][2])
{
if(Mochila[playerid] < 2)
{
MsgAviso(playerid, 3, "~r~~h~PAGINA DE INVENTARIO BLOQUEADA");
return 1;
}
PlayerPlaySound(playerid, 6400, 0, 0, 0);
for(new i; i < 15; i++)
{
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][i+3], -196);
if(SlotMochila[playerid][i+30] > 0)
{
ItemPreviewRot(playerid, SlotMochila[playerid][i+30], TextInvP[playerid][i+3]);
if(QuantidadeSlotMochila[playerid][i] == 0)
{
QuantidadeSlotMochila[playerid][i] = 1;
}
}
else if(SlotMochila[playerid][i+30] == 0)
{
PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][i+3], -10.000000, 0.000000, -20.000000, 111.000000);
}
PlayerTextDrawShow(playerid, TextInvP[playerid][i+3]);
new strquantidade[4];
if(QuantidadeSlotMochila[playerid][i+30] > 0) format(strquantidade, sizeof(strquantidade), "%d", QuantidadeSlotMochila[playerid][i+30]);
else strquantidade = "";
PlayerTextDrawSetString(playerid, TextInvP[playerid][i+28], strquantidade);
}
PaginaAtual[playerid] = 2;
if(SlotSelecionado[playerid] > -1 && PaginaAtual[playerid] == PaginaSelecionada[playerid])
{
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], 0xFA585855);
PlayerTextDrawShow(playerid, TextInvP[playerid][SlotSelecionado[playerid]]);
}
PlayerTextDrawColor(playerid, TextInvP[playerid][0], -2071689985); PlayerTextDrawShow(playerid, TextInvP[playerid][0]);
PlayerTextDrawColor(playerid, TextInvP[playerid][1], -2071690138); PlayerTextDrawShow(playerid, TextInvP[playerid][1]);
PlayerTextDrawColor(playerid, TextInvP[playerid][2], 0x6B54B6FF); PlayerTextDrawShow(playerid, TextInvP[playerid][2]);
}
else if(playertextid == TextLojaItens[playerid][7])
{
if(ComprandoItem[playerid] > 0)
{
if(TipoLoja[playerid] == 0)
{
CancelSelectTextDraw(playerid);
new mensagem[170]; format(mensagem, sizeof(mensagem), "\n{FFFFFF}Voce esta comprando esse Item Comum por {6C28BE}5000 Coins\n\n{FFFFFF}Coins Atual: {6C28BE}%d C\n\n{FFFFFF}Deseja confirmar sua compra?", COINS[playerid]);
ShowPlayerDialog(playerid, D_CONFIRMARCOMPRAITEM, DIALOG_STYLE_MSGBOX, "{FFFFFF}Confirme sua compra", mensagem, "Comprar", "Cancelar");
}
else if(TipoLoja[playerid] == 1)
{
if(ComprandoItem[playerid] == 18693)
{
CancelSelectTextDraw(playerid);
new mensagem[170]; format(mensagem, sizeof(mensagem), "\n{FFFFFF}Voce esta comprando esse Item Semi-Raro ( FOGO ) por {6C28BE}%d Coins\n\n{FFFFFF}Coins Atual: {6C28BE}%d C\n\n{FFFFFF}Deseja confirmar sua compra?", strval(GetValorItem(ComprandoItem[playerid])), COINS[playerid]);
ShowPlayerDialog(playerid, D_CONFIRMARCOMPRAITEM, DIALOG_STYLE_MSGBOX, "{FFFFFF}Confirme sua compra", mensagem, "Comprar", "Cancelar");
}
else if(ComprandoItem[playerid] == 18728)
{
CancelSelectTextDraw(playerid);
new mensagem[170]; format(mensagem, sizeof(mensagem), "\n{FFFFFF}Voce esta comprando esse Item Semi-Raro ( LUZ VERMELHA ) por {6C28BE}%d Coins\n\n{FFFFFF}Coins Atual: {6C28BE}%d C\n\n{FFFFFF}Deseja confirmar sua compra?", strval(GetValorItem(ComprandoItem[playerid])), COINS[playerid]);
ShowPlayerDialog(playerid, D_CONFIRMARCOMPRAITEM, DIALOG_STYLE_MSGBOX, "{FFFFFF}Confirme sua compra", mensagem, "Comprar", "Cancelar");
}
else if(ComprandoItem[playerid] == 18729)
{
CancelSelectTextDraw(playerid);
new mensagem[170]; format(mensagem, sizeof(mensagem), "\n{FFFFFF}Voce esta comprando esse Item Semi-Raro ( LUZ VERDE ) por {6C28BE}%d Coins\n\n{FFFFFF}Coins Atual: {6C28BE}%d C\n\n{FFFFFF}Deseja confirmar sua compra?", strval(GetValorItem(ComprandoItem[playerid])), COINS[playerid]);
ShowPlayerDialog(playerid, D_CONFIRMARCOMPRAITEM, DIALOG_STYLE_MSGBOX, "{FFFFFF}Confirme sua compra", mensagem, "Comprar", "Cancelar");
}
else
{
CancelSelectTextDraw(playerid);
new mensagem[170]; format(mensagem, sizeof(mensagem), "\n{FFFFFF}Voce esta comprando esse Item Semi-Raro por {6C28BE}%d Coins\n\n{FFFFFF}Coins Atual: {6C28BE}%d C\n\n{FFFFFF}Deseja confirmar sua compra?", strval(GetValorItem(ComprandoItem[playerid])), COINS[playerid]);
ShowPlayerDialog(playerid, D_CONFIRMARCOMPRAITEM, DIALOG_STYLE_MSGBOX, "{FFFFFF}Confirme sua compra", mensagem, "Comprar", "Cancelar");
}
}
if(TipoLoja[playerid] == 2)
{
CancelSelectTextDraw(playerid);
new mensagem[170]; format(mensagem, sizeof(mensagem), "\n{FFFFFF}Voce esta comprando esse Item Raro {6C28BE}30000 Coins\n\n{FFFFFF}Coins Atual: {6C28BE}%d C\n\n{FFFFFF}Deseja confirmar sua compra?", COINS[playerid]);
ShowPlayerDialog(playerid, D_CONFIRMARCOMPRAITEM, DIALOG_STYLE_MSGBOX, "{FFFFFF}Confirme sua compra", mensagem, "Comprar", "Cancelar");
}
}
}
else if(playertextid == TextLojaItens[playerid][8])
{
for(new t; t < 46; t++)
{
PlayerTextDrawHide(playerid, TextLojaItens[playerid][t]);
}
CancelSelectTextDraw(playerid);
CallLocalFunction("OnPlayerCommandText", "is", playerid, "/Loja");
}
else if(playertextid == TextLojaItens[playerid][11])
{
if(TipoLoja[playerid] == 0)
{
if(PaginaLoja[playerid] < 9)
{
ComprandoItem[playerid] = 0;
SlotLojaSelecionado[playerid] = 0;
PaginaLoja[playerid] ++;
MinItensList[playerid] += 15;
new StrPag[11];
format(StrPag, sizeof(StrPag), "PAG: %d/10", PaginaLoja[playerid]+1);
PlayerTextDrawSetString(playerid, TextLojaItens[playerid][4], StrPag);
for(new t; t < 15; t++)
{
PlayerTextDrawSetPreviewRot(playerid, TextLojaItens[playerid][t+16], 0.000000, 0.000000, 0.000000, 111.000000);
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][t+16], 1296911871);
PlayerTextDrawSetString(playerid, TextLojaItens[playerid][t+31], "");
if(t+MinItensList[playerid] <= 140)
{
PlayerTextDrawSetPreviewModel(playerid, TextLojaItens[playerid][t+16], ItensGeral[t+MinItensList[playerid]]);
ItemPreviewRot(playerid, ItensGeral[t+MinItensList[playerid]], TextLojaItens[playerid][t+16]);
PlayerTextDrawSetString(playerid, TextLojaItens[playerid][t+31], "5000 C");
}
PlayerTextDrawShow(playerid, TextLojaItens[playerid][t+16]);
}
}
}
else if(TipoLoja[playerid] == 1)
{
if(PaginaLoja[playerid] < 1)
{
ComprandoItem[playerid] = 0;
SlotLojaSelecionado[playerid] = 0;
PaginaLoja[playerid] ++;
MinItensList[playerid] += 15;
new StrPag[11];
format(StrPag, sizeof(StrPag), "PAG: %d/2", PaginaLoja[playerid]+1);
PlayerTextDrawSetString(playerid, TextLojaItens[playerid][4], StrPag);
for(new t; t < 15; t++)
{
PlayerTextDrawSetPreviewRot(playerid, TextLojaItens[playerid][t+16], 0.000000, 0.000000, 0.000000, 111.000000);
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][t+16], 1296911871);
PlayerTextDrawSetString(playerid, TextLojaItens[playerid][t+31], "");
if(t+MinItensList[playerid] <= 20)
{
PlayerTextDrawSetPreviewModel(playerid, TextLojaItens[playerid][t+16], ItensSemiRaros[t+MinItensList[playerid]]);
ItemPreviewRot(playerid, ItensSemiRaros[t+MinItensList[playerid]], TextLojaItens[playerid][t+16]);
PlayerTextDrawSetString(playerid, TextLojaItens[playerid][t+31], GetValorItem(ItensSemiRaros[t+MinItensList[playerid]]));
}
PlayerTextDrawShow(playerid, TextLojaItens[playerid][t+16]);
}
}
}
else if(TipoLoja[playerid] == 2)
{
}
}
else if(playertextid == TextLojaItens[playerid][12])
{
if(TipoLoja[playerid] == 0)
{
if(PaginaLoja[playerid] > 0)
{
ComprandoItem[playerid] = 0;
SlotLojaSelecionado[playerid] = 0;
PaginaLoja[playerid] --;
MinItensList[playerid] -= 15;
new StrPag[11];
format(StrPag, sizeof(StrPag), "PAG: %d/10", PaginaLoja[playerid]+1);
PlayerTextDrawSetString(playerid, TextLojaItens[playerid][4], StrPag);
for(new t; t < 15; t++)
{
PlayerTextDrawSetPreviewRot(playerid, TextLojaItens[playerid][t+16], 0.000000, 0.000000, 0.000000, 111.000000);
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][t+16], 1296911871);
PlayerTextDrawSetString(playerid, TextLojaItens[playerid][t+31], "");
if(t+MinItensList[playerid] <= 140)
{
PlayerTextDrawSetPreviewModel(playerid, TextLojaItens[playerid][t+16], ItensGeral[t+MinItensList[playerid]]);
ItemPreviewRot(playerid, ItensGeral[t+MinItensList[playerid]], TextLojaItens[playerid][t+16]);
PlayerTextDrawSetString(playerid, TextLojaItens[playerid][t+31], "5000 C");
}
PlayerTextDrawShow(playerid, TextLojaItens[playerid][t+16]);
}
}
}
else if(TipoLoja[playerid] == 1)
{
if(PaginaLoja[playerid] > 0)
{
ComprandoItem[playerid] = 0;
SlotLojaSelecionado[playerid] = 0;
PaginaLoja[playerid] --;
MinItensList[playerid] -= 15;
new StrPag[11];
format(StrPag, sizeof(StrPag), "PAG: %d/2", PaginaLoja[playerid]+1);
PlayerTextDrawSetString(playerid, TextLojaItens[playerid][4], StrPag);
for(new t; t < 15; t++)
{
PlayerTextDrawSetPreviewRot(playerid, TextLojaItens[playerid][t+16], 0.000000, 0.000000, 0.000000, 111.000000);
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][t+16], 1296911871);
PlayerTextDrawSetString(playerid, TextLojaItens[playerid][t+31], "");
if(t+MinItensList[playerid] <= 20)
{
PlayerTextDrawSetPreviewModel(playerid, TextLojaItens[playerid][t+16], ItensSemiRaros[t+MinItensList[playerid]]);
ItemPreviewRot(playerid, ItensSemiRaros[t+MinItensList[playerid]], TextLojaItens[playerid][t+16]);
PlayerTextDrawSetString(playerid, TextLojaItens[playerid][t+31], GetValorItem(ItensSemiRaros[t+MinItensList[playerid]]));
}
PlayerTextDrawShow(playerid, TextLojaItens[playerid][t+16]);
}
}
}
else if(TipoLoja[playerid] == 2)
{
}
}
else
{
if(MenuSelecionado[playerid] == 0)
{
for(new t; t < 15; t++)
{
if(playertextid == TextInvP[playerid][t+3])
{
if(SlotSelecionado[playerid] > -1 && SlotSelecionado[playerid] != t+3 || SlotSelecionado[playerid] == t+3 && PaginaAtual[playerid] != PaginaSelecionada[playerid])
{
new item;
if(PaginaAtual[playerid] == 0) item = t;
else if(PaginaAtual[playerid] == 1) item = t+15;
else if(PaginaAtual[playerid] == 2) item = t+30;
if(SlotMochila[playerid][item] == SlotMochila[playerid][ItemSelecionado[playerid]])
{
if(CheckLimite(SlotMochila[playerid][item], QuantidadeSlotMochila[playerid][item], QuantidadeSlotMochila[playerid][ItemSelecionado[playerid]]))
{
SlotMochila[playerid][ItemSelecionado[playerid]] = 0;
QuantidadeSlotMochila[playerid][item] += QuantidadeSlotMochila[playerid][ItemSelecionado[playerid]];
QuantidadeSlotMochila[playerid][ItemSelecionado[playerid]] = 0;
}
else
{
MsgAviso(playerid, 3, "~r~~h~LIMITE DE ITENS EXCEDIDO");
return 1;
}
}
else
{
new itemnovo = SlotMochila[playerid][item]; new qtditemnovo = QuantidadeSlotMochila[playerid][item];
SlotMochila[playerid][item] = SlotMochila[playerid][ItemSelecionado[playerid]];
SlotMochila[playerid][ItemSelecionado[playerid]] = itemnovo;
QuantidadeSlotMochila[playerid][item] = QuantidadeSlotMochila[playerid][ItemSelecionado[playerid]];
QuantidadeSlotMochila[playerid][ItemSelecionado[playerid]] = qtditemnovo;
}
new strquantidade[4];
if(QuantidadeSlotMochila[playerid][item] > 0) format(strquantidade, sizeof(strquantidade), "%d", QuantidadeSlotMochila[playerid][item]);
else strquantidade = "";
PlayerTextDrawSetString(playerid, TextInvP[playerid][t+28], strquantidade);
PlayerTextDrawShow(playerid, TextInvP[playerid][t+28]);
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][t+3], -196);
ItemPreviewRot(playerid, SlotMochila[playerid][item], TextInvP[playerid][t+3]);
PlayerTextDrawShow(playerid, TextInvP[playerid][t+3]);
if(PaginaAtual[playerid] == PaginaSelecionada[playerid])
{
if(QuantidadeSlotMochila[playerid][ItemSelecionado[playerid]] > 0) format(strquantidade, sizeof(strquantidade), "%d", QuantidadeSlotMochila[playerid][ItemSelecionado[playerid]]);
else strquantidade = "";
PlayerTextDrawSetString(playerid, TextInvP[playerid][SlotSelecionado[playerid]+25], strquantidade);
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], -196);
ItemPreviewRot(playerid, SlotMochila[playerid][ItemSelecionado[playerid]], TextInvP[playerid][SlotSelecionado[playerid]]);
PlayerTextDrawShow(playerid, TextInvP[playerid][SlotSelecionado[playerid]]);
}
SlotSelecionado[playerid] = -1;
ItemSelecionado[playerid] = -1;
PaginaSelecionada[playerid] = -1;
}
else if(VisualSelecionado[playerid] > -1)
{
new item;
if(PaginaAtual[playerid] == 0) item = t;
else if(PaginaAtual[playerid] == 1) item = t+15;
else if(PaginaAtual[playerid] == 2) item = t+30;
if(SlotMochila[playerid][item] == VisualSelecionado[playerid])
{
if(CheckLimite(SlotMochila[playerid][item], QuantidadeSlotMochila[playerid][item], 1))
{
QuantidadeSlotMochila[playerid][item] ++;
}
else
{
MsgAviso(playerid, 3, "~r~~h~LIMITE DE ITENS EXCEDIDO");
return 1;
}
}
else if(SlotMochila[playerid][item] == 0)
{
SlotMochila[playerid][item] = VisualSelecionado[playerid];
QuantidadeSlotMochila[playerid][item] = 1;
ItemPreviewRot(playerid, SlotMochila[playerid][item], TextInvP[playerid][t+3]);
PlayerTextDrawShow(playerid, TextInvP[playerid][t+3]);
}
else
{
MsgAviso(playerid, 3, "~r~~h~ESSE SLOT JA POSSUI UM ITEM");
return 1;
}
new strquantidade[4];
format(strquantidade, sizeof(strquantidade), "%d", QuantidadeSlotMochila[playerid][item]);
PlayerTextDrawSetString(playerid, TextInvP[playerid][t+28], strquantidade);
ModeloItem[playerid][SlotVisualSelecionado[playerid]-20] = 0;
if(IsPlayerAttachedObjectSlotUsed(playerid, SlotVisualSelecionado[playerid]-20)) RemovePlayerAttachedObject(playerid, SlotVisualSelecionado[playerid]-20);
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotVisualSelecionado[playerid]], -196);
ItemPreviewRot(playerid, ModeloItem[playerid][SlotVisualSelecionado[playerid]-20], TextInvP[playerid][SlotVisualSelecionado[playerid]]);
PlayerTextDrawShow(playerid, TextInvP[playerid][SlotVisualSelecionado[playerid]]);
VisualSelecionado[playerid] = -1;
SlotVisualSelecionado[playerid] = -1;
SlotSelecionado[playerid] = -1;
ItemSelecionado[playerid] = -1;
PaginaSelecionada[playerid] = -1;
}
else if(SlotSelecionado[playerid] == -1)
{
if(PaginaAtual[playerid] == 0) ItemSelecionado[playerid] = t;
else if(PaginaAtual[playerid] == 1) ItemSelecionado[playerid] = t+15;
else if(PaginaAtual[playerid] == 2) ItemSelecionado[playerid] = t+30;
if(SlotMochila[playerid][ItemSelecionado[playerid]] > 0)
{
SlotSelecionado[playerid] = t+3;
PaginaSelecionada[playerid] = PaginaAtual[playerid];
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], 0xFA585855);
PlayerTextDrawShow(playerid, TextInvP[playerid][SlotSelecionado[playerid]]);
}
else
{
ItemSelecionado[playerid] = -1;
}
}
else if(SlotSelecionado[playerid] > -1 && PaginaAtual[playerid] == PaginaSelecionada[playerid])
{
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], -196);
ItemPreviewRot(playerid, SlotMochila[playerid][ItemSelecionado[playerid]], TextInvP[playerid][SlotSelecionado[playerid]]);
PlayerTextDrawShow(playerid,TextInvP[playerid][SlotSelecionado[playerid]]);
if(SlotSelecionado[playerid] == t+3)
{
SlotSelecionado[playerid] = -1;
ItemSelecionado[playerid] = -1;
PaginaSelecionada[playerid] = -1;
}
}
return 1;
}
}
}
else if(MenuSelecionado[playerid] == 1)
{
if(playertextid == TextInvP[playerid][3])
{
new PastaVeiculos[40]; format(PastaVeiculos, sizeof(PastaVeiculos), "Veiculos/%s.ini", PlayerName(playerid));
new Str[50]; format(Str, sizeof(Str), "{FFFFFF}Veiculo {6C28BE}%s", DOF2_GetString(PastaVeiculos, "VeiculoNome0"));
if(ModeloVeiculoInv[playerid][0] == 510 || ModeloVeiculoInv[playerid][0] == 462)
{
return ShowPlayerDialog(playerid, D_SPAWNARVEICULO0, DIALOG_STYLE_LIST, Str, "{FFFFFF}Conectar\nDesconectar\nRespawnar\nLocalizar\nDeslocalizar\nPuxar", "Selecionar", "Cancelar");
}
else if(ModeloVeiculoInv[playerid][0] > 0)
{
return ShowPlayerDialog(playerid, D_SPAWNARVEICULO0, DIALOG_STYLE_LIST, Str, "{FFFFFF}Conectar\nDesconectar\nRespawnar\nLocalizar\nDeslocalizar", "Selecionar", "Cancelar");
}
}
else if(playertextid == TextInvP[playerid][4])
{
new PastaVeiculos[40]; format(PastaVeiculos, sizeof(PastaVeiculos), "Veiculos/%s.ini", PlayerName(playerid));
new Str[50]; format(Str, sizeof(Str), "{FFFFFF}Veiculo {6C28BE}%s", DOF2_GetString(PastaVeiculos, "VeiculoNome1"));
if(ModeloVeiculoInv[playerid][1] == 510 || ModeloVeiculoInv[playerid][1] == 462)
{
return ShowPlayerDialog(playerid, D_SPAWNARVEICULO1, DIALOG_STYLE_LIST, Str, "{FFFFFF}Conectar\nDesconectar\nRespawnar\nLocalizar\nDeslocalizar\nPuxar", "Selecionar", "Cancelar");
}
else if(ModeloVeiculoInv[playerid][1] > 0)
{
return ShowPlayerDialog(playerid, D_SPAWNARVEICULO1, DIALOG_STYLE_LIST, Str, "{FFFFFF}Conectar\nDesconectar\nRespawnar\nLocalizar\nDeslocalizar", "Selecionar", "Cancelar");
}
}
else if(playertextid == TextInvP[playerid][5])
{
new PastaVeiculos[40]; format(PastaVeiculos, sizeof(PastaVeiculos), "Veiculos/%s.ini", PlayerName(playerid));
new Str[50]; format(Str, sizeof(Str), "{FFFFFF}Veiculo {6C28BE}%s", DOF2_GetString(PastaVeiculos, "VeiculoNome2"));
if(ModeloVeiculoInv[playerid][2] == 510 || ModeloVeiculoInv[playerid][2] == 462)
{
return ShowPlayerDialog(playerid, D_SPAWNARVEICULO2, DIALOG_STYLE_LIST, Str, "{FFFFFF}Conectar\nDesconectar\nRespawnar\nLocalizar\nDeslocalizar\nPuxar", "Selecionar", "Cancelar");
}
else if(ModeloVeiculoInv[playerid][2] > 0)
{
return ShowPlayerDialog(playerid, D_SPAWNARVEICULO2, DIALOG_STYLE_LIST, Str, "{FFFFFF}Conectar\nDesconectar\nRespawnar\nLocalizar\nDeslocalizar", "Selecionar", "Cancelar");
}
}
else if(playertextid == TextInvP[playerid][6])
{
new PastaVeiculos[40]; format(PastaVeiculos, sizeof(PastaVeiculos), "Veiculos/%s.ini", PlayerName(playerid));
new Str[50]; format(Str, sizeof(Str), "{FFFFFF}Veiculo {6C28BE}%s", DOF2_GetString(PastaVeiculos, "VeiculoNome3"));
if(ModeloVeiculoInv[playerid][3] == 510 || ModeloVeiculoInv[playerid][3] == 462)
{
return ShowPlayerDialog(playerid, D_SPAWNARVEICULO3, DIALOG_STYLE_LIST, Str, "{FFFFFF}Conectar\nDesconectar\nRespawnar\nLocalizar\nDeslocalizar\nPuxar", "Selecionar", "Cancelar");
}
else if(ModeloVeiculoInv[playerid][3] > 0)
{
return ShowPlayerDialog(playerid, D_SPAWNARVEICULO3, DIALOG_STYLE_LIST, Str, "{FFFFFF}Conectar\nDesconectar\nRespawnar\nLocalizar\nDeslocalizar", "Selecionar", "Cancelar");
}
}
else if(playertextid == TextInvP[playerid][7])
{
new PastaVeiculos[40]; format(PastaVeiculos, sizeof(PastaVeiculos), "Veiculos/%s.ini", PlayerName(playerid));
new Str[50]; format(Str, sizeof(Str), "{FFFFFF}Veiculo {6C28BE}%s", DOF2_GetString(PastaVeiculos, "VeiculoNome4"));
if(ModeloVeiculoInv[playerid][4] == 510 || ModeloVeiculoInv[playerid][4] == 462)
{
return ShowPlayerDialog(playerid, D_SPAWNARVEICULO4, DIALOG_STYLE_LIST, Str, "{FFFFFF}Conectar\nDesconectar\nRespawnar\nLocalizar\nDeslocalizar\nPuxar", "Selecionar", "Cancelar");
}
else if(ModeloVeiculoInv[playerid][4] > 0)
{
return ShowPlayerDialog(playerid, D_SPAWNARVEICULO4, DIALOG_STYLE_LIST, Str, "{FFFFFF}Conectar\nDesconectar\nRespawnar\nLocalizar\nDeslocalizar", "Selecionar", "Cancelar");
}
}
}
for(new t; t < 15; t++)
{
if(playertextid == TextLojaItens[playerid][t+16])
{
if(TipoLoja[playerid] == 0)
{
if(t+MinItensList[playerid] <= 140)
{
if(SlotLojaSelecionado[playerid] == 0)
{
ComprandoItem[playerid] = ItensGeral[t+MinItensList[playerid]];
SlotLojaSelecionado[playerid] = t+16;
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][t+16], 0xFF0000FF);
PlayerTextDrawShow(playerid, TextLojaItens[playerid][t+16]);
}
else if(TextLojaItens[playerid][t+16] != TextLojaItens[playerid][SlotLojaSelecionado[playerid]])
{
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][SlotLojaSelecionado[playerid]], 1296911871);
PlayerTextDrawShow(playerid, TextLojaItens[playerid][SlotLojaSelecionado[playerid]]);
ComprandoItem[playerid] = ItensGeral[t+MinItensList[playerid]];
SlotLojaSelecionado[playerid] = t+16;
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][t+16], 0xFF0000FF);
PlayerTextDrawShow(playerid, TextLojaItens[playerid][t+16]);
}
else
{
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][SlotLojaSelecionado[playerid]], 1296911871);
PlayerTextDrawShow(playerid, TextLojaItens[playerid][SlotLojaSelecionado[playerid]]);
ComprandoItem[playerid] = 0;
SlotLojaSelecionado[playerid] = 0;
}
}
}
if(TipoLoja[playerid] == 1)
{
if(t+MinItensList[playerid] <= 20)
{
if(SlotLojaSelecionado[playerid] == 0)
{
ComprandoItem[playerid] = ItensSemiRaros[t+MinItensList[playerid]];
ValorComprandoItem[playerid] = strval(GetValorItem(ItensSemiRaros[t+MinItensList[playerid]]));
SlotLojaSelecionado[playerid] = t+16;
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][t+16], 0xFF0000FF);
PlayerTextDrawShow(playerid, TextLojaItens[playerid][t+16]);
}
else if(TextLojaItens[playerid][t+16] != TextLojaItens[playerid][SlotLojaSelecionado[playerid]])
{
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][SlotLojaSelecionado[playerid]], 0xFF400077);
PlayerTextDrawShow(playerid, TextLojaItens[playerid][SlotLojaSelecionado[playerid]]);
ComprandoItem[playerid] = ItensSemiRaros[t+MinItensList[playerid]];
ValorComprandoItem[playerid] = strval(GetValorItem(ItensSemiRaros[t+MinItensList[playerid]]));
SlotLojaSelecionado[playerid] = t+16;
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][t+16], 0xFF0000FF);
PlayerTextDrawShow(playerid, TextLojaItens[playerid][t+16]);
}
else
{
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][SlotLojaSelecionado[playerid]], 0xFF400077);
PlayerTextDrawShow(playerid, TextLojaItens[playerid][SlotLojaSelecionado[playerid]]);
ComprandoItem[playerid] = 0;
SlotLojaSelecionado[playerid] = 0;
}
}
}
if(TipoLoja[playerid] == 2)
{
if(t+MinItensList[playerid] <= 14)
{
if(SlotLojaSelecionado[playerid] == 0)
{
ComprandoItem[playerid] = ItensRaros[t+MinItensList[playerid]];
SlotLojaSelecionado[playerid] = t+16;
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][t+16], 0xFF0000FF);
PlayerTextDrawShow(playerid, TextLojaItens[playerid][t+16]);
}
else if(TextLojaItens[playerid][t+16] != TextLojaItens[playerid][SlotLojaSelecionado[playerid]])
{
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][SlotLojaSelecionado[playerid]], 0x0000FF77);
PlayerTextDrawShow(playerid, TextLojaItens[playerid][SlotLojaSelecionado[playerid]]);
ComprandoItem[playerid] = ItensRaros[t+MinItensList[playerid]];
SlotLojaSelecionado[playerid] = t+16;
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][t+16], 0xFF0000FF);
PlayerTextDrawShow(playerid, TextLojaItens[playerid][t+16]);
}
else
{
PlayerTextDrawBackgroundColor(playerid, TextLojaItens[playerid][SlotLojaSelecionado[playerid]], 0x0000FF77);
PlayerTextDrawShow(playerid, TextLojaItens[playerid][SlotLojaSelecionado[playerid]]);
ComprandoItem[playerid] = 0;
SlotLojaSelecionado[playerid] = 0;
}
}
}
return 1;
}
}
for(new t = 1; t < 6; t++)
{
if(playertextid == TextBarraquinha[playerid][t])
{
new b = BarracaProxima(playerid);
if(b > -1 && ItemBarraquinha[b][t-1] > 0)
{
ItemDaBarraquinha[playerid] = t-1;
new Str[70];
if(CoinsItemBarraquinha[b][t-1] > 0)
{
format(Str, sizeof(Str), "\n{FFFFFF}Voce deseja comprar esse item por {6C28BE}%d Coins{FFFFFF}?", CoinsItemBarraquinha[b][t-1]);
}
else
{
format(Str, sizeof(Str), "\n{FFFFFF}Voce deseja comprar esse item por {00FF00}$%d{FFFFFF}?", ValorItemBarraquinha[b][t-1]);
}
return ShowPlayerDialog(playerid, D_COMPRARITEM, DIALOG_STYLE_MSGBOX, "{FFFFFF}Comprar Item", Str, "Comprar", "Cancelar");
}
}
}
if(playertextid == TextBarraquinha[playerid][11])
{
for(new t; t < 14; t++)
{
PlayerTextDrawHide(playerid, TextBarraquinha[playerid][t]);
}
CancelSelectTextDraw(playerid);
ApplyAnimation(playerid, "CARRY", "crry_prtial", 2.0, 0, 0, 0, 0, 0, 1);
}
for(new t = 20; t < 26; t++)
{
if(playertextid == TextInvP[playerid][t])
{
if(SlotSelecionado[playerid] > -1)
{
if(ModeloItem[playerid][t-20] == 0 || QuantidadeSlotMochila[playerid][ItemSelecionado[playerid]] <= 1)
{
if(SlotMochila[playerid][ItemSelecionado[playerid]] == MAGICBOX) return 0;
new item;
if(ModeloItem[playerid][t-20] > 0)
{
item = ModeloItem[playerid][t-20];
if(IsPlayerAttachedObjectSlotUsed(playerid, t-20)) RemovePlayerAttachedObject(playerid, t-20);
}
ModeloItem[playerid][t-20] = SlotMochila[playerid][ItemSelecionado[playerid]];
ItemPreviewRot(playerid, ModeloItem[playerid][t-20], TextInvP[playerid][t]);
PlayerTextDrawShow(playerid, TextInvP[playerid][t]);
QuantidadeSlotMochila[playerid][ItemSelecionado[playerid]] --;
new strquantidade[4];
format(strquantidade, sizeof(strquantidade), "%d", QuantidadeSlotMochila[playerid][ItemSelecionado[playerid]]);
if(QuantidadeSlotMochila[playerid][ItemSelecionado[playerid]] == 0)
{
if(item == 0)
{
SlotMochila[playerid][ItemSelecionado[playerid]] = 0;
strquantidade = "";
}
else
{
SlotMochila[playerid][ItemSelecionado[playerid]] = item;
QuantidadeSlotMochila[playerid][ItemSelecionado[playerid]] = 1;
strquantidade = "1";
}
}
if(PaginaAtual[playerid] == PaginaSelecionada[playerid])
{
PlayerTextDrawSetString(playerid, TextInvP[playerid][SlotSelecionado[playerid]+25], strquantidade);
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], -196);
ItemPreviewRot(playerid, SlotMochila[playerid][ItemSelecionado[playerid]], TextInvP[playerid][SlotSelecionado[playerid]]);
PlayerTextDrawShow(playerid, TextInvP[playerid][SlotSelecionado[playerid]]);
}
SlotSelecionado[playerid] = -1;
ItemSelecionado[playerid] = -1;
PaginaSelecionada[playerid] = -1;
SendClientMessage(playerid, -1, "| INFO | Voce se vestiu com um item, clique duas vezes nele para edita-lo");
MsgAviso(playerid, 3, "~w~Clique ~b~2 vezes ~w~para edita-lo");
return 1;
}
}
else if(ModeloItem[playerid][t-20] > 0 && VisualSelecionado[playerid] == -1)
{
VisualSelecionado[playerid] = ModeloItem[playerid][t-20];
SlotVisualSelecionado[playerid] = t;
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotVisualSelecionado[playerid]], 0xFA585855);
PlayerTextDrawShow(playerid, TextInvP[playerid][SlotVisualSelecionado[playerid]]);
Flooder[playerid] = gettime();
return 1;
}
else if(ModeloItem[playerid][t-20] > 0 && VisualSelecionado[playerid] > -1 && SlotVisualSelecionado[playerid] == t)
{
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotVisualSelecionado[playerid]], -196);
ItemPreviewRot(playerid, ModeloItem[playerid][t-20], TextInvP[playerid][t]);
PlayerTextDrawShow(playerid, TextInvP[playerid][SlotVisualSelecionado[playerid]]);
VisualSelecionado[playerid] = -1;
SlotVisualSelecionado[playerid] = -1;
if((gettime() - Flooder[playerid]) <= 1)
{
IndexEscolhido[playerid] = t-20;
CancelSelectTextDraw(playerid);
ShowPlayerDialog(playerid, D_ITEM, DIALOG_STYLE_LIST, "{FFFFFF}Escolha onde deseja usar esse item", "{FFFFFF}Tronco\nBra�o Esquerdo\nBra�o direito\nPerna Esquerda\nPerna Direita\nCabe�a", "Selecionar", "Cancelar");
}
return 1;
}
}
}
for(new t = 1; t < 10; t++)
{
if(playertextid == TextColetarItemP[playerid][t])
{
if(SlotEncontrado[playerid][t-1] > -1 && IsValidDynamicObject(Item[SlotEncontrado[playerid][t-1]]))
{
new Float:P[3]; GetDynamicObjectPos(Item[SlotEncontrado[playerid][t-1]], P[0], P[1], P[2]);
if(IsPlayerInRangeOfPoint(playerid, 2.0, P[0], P[1], P[2]))
{
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
switch(GetDynamicObjectModel(Item[SlotEncontrado[playerid][t-1]]))
{
case 339:
{
SlotMochila[playerid][m] = 8;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
case 341:
{
SlotMochila[playerid][m] = 9;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
case 346:
{
SlotMochila[playerid][m] = 22;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
case 347:
{
SlotMochila[playerid][m] = 23;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
case 348:
{
SlotMochila[playerid][m] = 24;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
case 349:
{
SlotMochila[playerid][m] = 25;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
case 350:
{
SlotMochila[playerid][m] = 26;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
case 351:
{
SlotMochila[playerid][m] = 27;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
case 352:
{
SlotMochila[playerid][m] = 28;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
case 353:
{
SlotMochila[playerid][m] = 29;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
case 355:
{
SlotMochila[playerid][m] = 30;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
case 356:
{
SlotMochila[playerid][m] = 31;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
case 358:
{
SlotMochila[playerid][m] = 34;
QuantidadeSlotMochila[playerid][m] = QuantidadeItem[SlotEncontrado[playerid][t-1]];
}
default:
{
SlotMochila[playerid][m] = GetDynamicObjectModel(Item[SlotEncontrado[playerid][t-1]]);
QuantidadeSlotMochila[playerid][m] = 1;
}
}
DestroyDynamicObject(Item[SlotEncontrado[playerid][t-1]]);
DestroyDynamic3DTextLabel(TextoItemEcontrado[playerid][t-1]);
Item[SlotEncontrado[playerid][t-1]] = 0;
SlotEncontrado[playerid][t-1] = -1;
PlayerTextDrawHide(playerid, TextColetarItemP[playerid][t]);
ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0, 1);
return 1;
}
}
MsgAviso(playerid, 3, "~r~Seu inventario esta cheio");
return 1;
}
}
}
}
for(new t; t < 15; t++)
{
if(playertextid == TextMegaSena[playerid][t+8])
{
for(new s; s < 3; s++)
{
if(NumeroSelecionado[playerid][s] == 0)
{
NumeroSelecionado[playerid][s] = t+1;
new strt[5]; format(strt, sizeof(strt), "%02d", NumeroSelecionado[playerid][s]);
PlayerTextDrawSetString(playerid, TextMegaSena[playerid][s+23], strt);
return 1;
}
else if(NumeroSelecionado[playerid][s] > 0 && playertextid == TextMegaSena[playerid][NumeroSelecionado[playerid][s]+7])
{
NumeroSelecionado[playerid][s] = 0;
PlayerTextDrawSetString(playerid, TextMegaSena[playerid][s+23], "");
return 1;
}
}
return 1;
}
}
}
}
return 1;
}
public OnPlayerClickTextDraw(playerid, Text:clickedid)
{
if(AstraModo[playerid] == ASTRA_MODO_PVP) return PVP_OnPlayerClickTextDraw(playerid, clickedid);
if(clickedid != Text:INVALID_TEXT_DRAW)
{
if(clickedid == TextCell[9])
{
for(new t; t < 54; t++)
{
TextDrawHideForPlayer(playerid, TextCell[t]);
}
for(new t; t < 6; t++)
{
TextDrawHideForPlayer(playerid, TextBTC[t]);
}
for(new t; t < 2; t++)
{
PlayerTextDrawHide(playerid, TextBTCP[playerid][t]);
}
CancelSelectTextDraw(playerid);
}
else if(clickedid == TextCell[38])
{
CallLocalFunction("OnPlayerCommandText", "is", playerid, "/Radioo");
}
else if(clickedid == TextCell[16])
{
CallLocalFunction("OnPlayerCommandText", "is", playerid, "/Btcc");
}
else if(clickedid == TextCell[30])
{
CallLocalFunction("OnPlayerCommandText", "is", playerid, "/Bancoo");
}
else if(clickedid == TextCell[36])
{
CallLocalFunction("OnPlayerCommandText", "is", playerid, "/Taxi");
}
else if(clickedid == TextCell[22])
{
CallLocalFunction("OnPlayerCommandText", "is", playerid, "/190");
}
else if(clickedid == TextCell[24])
{
CallLocalFunction("OnPlayerCommandText", "is", playerid, "/192");
}
else if(clickedid == TextCell[26])
{
CallLocalFunction("OnPlayerCommandText", "is", playerid, "/Mecanico");
}
else if(clickedid == TextCell[28])
{
CallLocalFunction("OnPlayerCommandText", "is", playerid, "/193");
}
else if(clickedid == TextCell[32])
{
CallLocalFunction("OnPlayerCommandText", "is", playerid, "/selfie");
ShowPlayerDialog(playerid, 555, DIALOG_STYLE_MSGBOX, "{FFFFFF}Info Camera", "\n{FFFFFF}Use /Selfie Para fechar A Camera e /HeadMove Para parar A Movimentacao Da Cabeca", "Fechar", "");
}
else if(clickedid == TextCell[40])
{
ShowPlayerDialog(playerid, D_ENVIARLOCALIZACAO, DIALOG_STYLE_INPUT, "{FFFFFF}Enviar Localiza�ao", "\n{FFFFFF}Digite o id do jogador para quem voce deseja enviar sua localiza�ao", "Enviar", "Cancelar");
}
else if(clickedid == TextCell[19])
{
CallLocalFunction("OnPlayerCommandText", "is", playerid, "/Discord");
}
else if(clickedid == TextCell[21])
{
new str[1000], str2[100];
strcat(str, "{ffff00}Adicionar Contato\n");
for(new i; i < 30; i++)
{
if(NumeroContatoPlayer[playerid][i] < 0) NumeroContatoPlayer[playerid][i] = 0;
if(!new_strcmp(NumeroContatoPlayer[playerid][i], "")) format(str2, sizeof(str2), "{FFFFFF}%02d  %s - %06d\n", i+1, ContatoPlayer[playerid][i], NumeroContatoPlayer[playerid][i]);
else format(str2, sizeof(str2), "{FFFFFF}%02d  Nenhum - %06d\n", i+1, ContatoPlayer[playerid][i], NumeroContatoPlayer[playerid][i]);
strcat(str, str2);
}
ShowPlayerDialog(playerid, D_ADDCTT, DIALOG_STYLE_LIST, "{6C28BE}Contato", str, "Proximo", "Cancelar");
}
else if(clickedid == TextBarraquinhaSpawn[1])
{
PickupStatus[playerid] = 1;
TextDrawShowForPlayer(playerid, TextBarraquinhaSpawn[1]);
}
else if(clickedid == TextBarraquinhaSpawn[2])
{
PickupStatus[playerid] = 2;
TextDrawShowForPlayer(playerid, TextBarraquinhaSpawn[2]);
}
else if(clickedid == TextBarraquinhaSpawn[7])
{
if(PickupStatus[playerid] == 1)
{
if(Money[playerid] >= 50)
{
ApplyAnimation(playerid, "DEALER", "shop_pay", 4.1, 0, 0, 0, 0, 0, 1);
if(!IsPlayerAttachedObjectSlotUsed(playerid, 5))
{
Money[playerid] -= 50;
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3);
SegurandoMao[playerid] = PIZZA;
SetPlayerAttachedObject(playerid, 5, 19580, 6, 0.0850, 0.0819, 0.0170, 132.8000, -79.3999, 50.9000, 0.4570, 0.4510, 0.9290, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce comprou uma Pizza, pressione F para comer ou digite /guardar para guarda-la no inventario");
}
else
{
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
Money[playerid] -= 50;
SlotMochila[playerid][m] = PIZZA;
QuantidadeSlotMochila[playerid][m] = 1;
SendClientMessage(playerid, -1, "| INFO | Voce comprou uma Pizza e guardou no inventario");
PickupStatus[playerid] = -8;
for(new t; t < 10; t++)
{
TextDrawHideForPlayer(playerid, TextBarraquinhaSpawn[t]);
}
CancelSelectTextDraw(playerid);
return 1;
}
}
PickupStatus[playerid] = -8;
for(new t; t < 10; t++)
{
TextDrawHideForPlayer(playerid, TextBarraquinhaSpawn[t]);
}
CancelSelectTextDraw(playerid);
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Seu inventario esta cheio");
}
}
else
{
SendClientMessage(playerid, COR_ERRO, "| ERRO | Voce nao tem dinheiro suficiente");
}
}
else if(PickupStatus[playerid] == 2)
{
if(Money[playerid] >= 30)
{
ApplyAnimation(playerid, "DEALER", "shop_pay", 4.1, 0, 0, 0, 0, 0, 1);
if(!IsPlayerAttachedObjectSlotUsed(playerid, 5))
{
Money[playerid] -= 30;
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3);
SegurandoMao[playerid] = COCA;
SetPlayerAttachedObject(playerid, 5, 19822, 5, 0.1480, 0.1519, 0.1319, 142.9002, -17.5999, 58.7000, 0.5250, 0.5659, 0.5980, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce comprou uma Coca-Cola, pressione F para beber ou digite /guardar para guarda-la no inventario");
}
else
{
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
Money[playerid] -= 30;
SlotMochila[playerid][m] = COCA;
QuantidadeSlotMochila[playerid][m] = 1;
SendClientMessage(playerid, -1, "| INFO | Voce comprou uma Coca-Cola e guardou no inventario");
PickupStatus[playerid] = -8;
for(new t; t < 10; t++)
{
TextDrawHideForPlayer(playerid, TextBarraquinhaSpawn[t]);
}
CancelSelectTextDraw(playerid);
return 1;
}
}
PickupStatus[playerid] = -8;
for(new t; t < 10; t++)
{
TextDrawHideForPlayer(playerid, TextBarraquinhaSpawn[t]);
}
CancelSelectTextDraw(playerid);
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Seu inventario esta cheio");
}
}
else
{
SendClientMessage(playerid, COR_ERRO, "| ERRO | Voce nao tem dinheiro suficiente");
}
}
PickupStatus[playerid] = -8;
for(new t; t < 10; t++)
{
TextDrawHideForPlayer(playerid, TextBarraquinhaSpawn[t]);
}
CancelSelectTextDraw(playerid);
return 1;
}
else if(clickedid == TextInv[7])
{
PlayerPlaySound(playerid, 6400, 0, 0, 0);
for(new t; t < 21; t++)
{
TextDrawHideForPlayer(playerid, TextInv[t]);
}
for(new t; t < 46; t++)
{
PlayerTextDrawHide(playerid, TextInvP[playerid][t]);
}
CancelSelectTextDraw(playerid);
}
else if(clickedid == TextInv[18])
{
PlayerPlaySound(playerid, 6400, 0, 0, 0);
SlotSelecionado[playerid] = -1; MenuSelecionado[playerid] = 1;
PlayerTextDrawShow(playerid, TextInvP[playerid][0]);
PlayerTextDrawShow(playerid, TextInvP[playerid][1]);
PlayerTextDrawShow(playerid, TextInvP[playerid][2]);
for(new t; t < 3; t++)
{
PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][t], 0); PlayerTextDrawShow(playerid, TextInvP[playerid][t]);
}
for(new t = 17; t > 7; t--)
{
PlayerTextDrawHide(playerid, TextInvP[playerid][t]);
}
for(new t = 28; t < 43; t++)
{
PlayerTextDrawHide(playerid, TextInvP[playerid][t]);
}
for(new i; i < 5; i++)
{
if(ModeloVeiculoInv[playerid][i] > 0)
{
PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][i+3], -10.000000, 0.000000, -20.000000, 1.000000);
}
else if(ModeloVeiculoInv[playerid][i] <= 0)
{
PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][i+3], -10.000000, 0.000000, -20.000000, 111.000000);
}
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][i+3], -196);
PlayerTextDrawSetPreviewModel(playerid, TextInvP[playerid][i+3], ModeloVeiculoInv[playerid][i]);
PlayerTextDrawShow(playerid, TextInvP[playerid][i+3]);
}
}
else if(clickedid == TextInv[17])
{
PlayerPlaySound(playerid, 6400, 0, 0, 0);
SlotSelecionado[playerid] = -1; MenuSelecionado[playerid] = 0; PaginaAtual[playerid] = 0;
for(new t; t < 3; t++)
{
PlayerTextDrawSetSelectable(playerid, TextInvP[playerid][t], 1); PlayerTextDrawShow(playerid, TextInvP[playerid][t]);
}
for(new i; i < 15; i++)
{
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][i+3], -196);
if(SlotMochila[playerid][i] > 0)
{
ItemPreviewRot(playerid, SlotMochila[playerid][i], TextInvP[playerid][i+3]);
if(QuantidadeSlotMochila[playerid][i] == 0)
{
QuantidadeSlotMochila[playerid][i] = 1;
}
}
else if(SlotMochila[playerid][i] == 0)
{
QuantidadeSlotMochila[playerid][i] = 0;
PlayerTextDrawSetPreviewRot(playerid, TextInvP[playerid][i+3], -10.000000, 0.000000, -20.000000, 111.000000);
}
PlayerTextDrawShow(playerid, TextInvP[playerid][i+3]);
new strquantidade[4];
if(QuantidadeSlotMochila[playerid][i] > 0) format(strquantidade, sizeof(strquantidade), "%d", QuantidadeSlotMochila[playerid][i]);
else strquantidade = "";
PlayerTextDrawSetString(playerid, TextInvP[playerid][i+28], strquantidade);
}
for(new t = 28; t < 43; t++)
{
PlayerTextDrawShow(playerid, TextInvP[playerid][t]);
}
}
else if(clickedid == TextColetarItem[2])
{
for(new t; t < 3; t++)
{
TextDrawHideForPlayer(playerid, TextColetarItem[t]);
}
for(new t; t < 10; t++)
{
PlayerTextDrawHide(playerid, TextColetarItemP[playerid][t]);
if(t <= 8) SlotEncontrado[playerid][t] = -1;
}
CancelSelectTextDraw(playerid);
}
else if(clickedid == TextInv[9])
{
if(MenuSelecionado[playerid] == 0 && ItemSelecionado[playerid] > -1)
{
PlayerPlaySound(playerid, 6400, 0, 0, 0);
UsarItem(playerid, ItemSelecionado[playerid]);
}
}
else if(clickedid == TextInv[10])
{
if(MenuSelecionado[playerid] == 0 && ItemSelecionado[playerid] > -1)
{
if(!IsPlayerInRangeOfPoint(playerid, 100.0, 1129.4084,-1463.0726,15.7919))
{
switch(SlotMochila[playerid][ItemSelecionado[playerid]])
{
case 22..34:
{
switch(PROF[playerid])
{
case PM,ROTA,CHOQUE,ROTAM,BOPE,PC,PF,EXERCITO: return SendClientMessage(playerid, COR_ERRO, "| ERRO | Seu comando para dropar armas esta bloqueado");
}
}
}
PlayerPlaySound(playerid, 6400, 0, 0, 0);
DroparItem(playerid, ItemSelecionado[playerid]);
}
else
{
MsgAviso(playerid, 3, "~r~Local bloqueado");
}
}
}
else if(clickedid == TextInv[11])
{
if(MenuSelecionado[playerid] == 0 && ItemSelecionado[playerid] > -1)
{
PlayerPlaySound(playerid, 6400, 0, 0, 0);
new b = BarracaProxima(playerid);
if(b > -1)
{
if(new_strcmp(DonoBarraquinha[b], PlayerName(playerid)))
{
for(new i; i < 5; i++)
{
if(ItemBarraquinha[b][i] == 0)
{
VenderItem(playerid, ItemSelecionado[playerid], b, i);
return 1;
}
}
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], -196);
ItemPreviewRot(playerid, SlotMochila[playerid][ItemSelecionado[playerid]], TextInvP[playerid][SlotSelecionado[playerid]]);
PlayerTextDrawShow(playerid, TextInvP[playerid][SlotSelecionado[playerid]]);
SlotSelecionado[playerid] = -1;
ItemSelecionado[playerid] = -1;
MsgAviso(playerid, 3, "~r~Sua barraquinha esta cheia");
return 1;
}
else
{
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], -196);
ItemPreviewRot(playerid, SlotMochila[playerid][ItemSelecionado[playerid]], TextInvP[playerid][SlotSelecionado[playerid]]);
PlayerTextDrawShow(playerid, TextInvP[playerid][SlotSelecionado[playerid]]);
SlotSelecionado[playerid] = -1;
ItemSelecionado[playerid] = -1;
MsgAviso(playerid, 3, "~r~Essa barraquinha nao e sua");
return 1;
}
}
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], -196);
ItemPreviewRot(playerid, SlotMochila[playerid][ItemSelecionado[playerid]], TextInvP[playerid][SlotSelecionado[playerid]]);
PlayerTextDrawShow(playerid, TextInvP[playerid][SlotSelecionado[playerid]]);
SlotSelecionado[playerid] = -1;
ItemSelecionado[playerid] = -1;
MsgAviso(playerid, 3, "~r~Voce nao esta proximo de nenhuma barraquinha");
return 1;
}
}
else if(clickedid == TextInv[12])
{
if(MenuSelecionado[playerid] == 0 && ItemSelecionado[playerid] > -1)
{
PlayerPlaySound(playerid, 6400, 0, 0, 0);
switch(SlotMochila[playerid][ItemSelecionado[playerid]])
{
case MAGICBOX:
{
MsgAviso(playerid, 3, "~r~Esse item nao pode ser excluido");
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], -196);
ItemPreviewRot(playerid, SlotMochila[playerid][ItemSelecionado[playerid]], TextInvP[playerid][SlotSelecionado[playerid]]);
PlayerTextDrawShow(playerid,TextInvP[playerid][SlotSelecionado[playerid]]);
SlotSelecionado[playerid] = -1;
ItemSelecionado[playerid] = -1;
PaginaSelecionada[playerid] = -1;
}
default:
{
PlayerPlaySound(playerid, 6400, 0, 0, 0);
ShowPlayerDialog(playerid, D_REMOVERITEMINV, DIALOG_STYLE_INPUT, "{FFFFFF}Excluir Item", "{FFFFFF}Voce deseja descartar de vez esse item do seu invantario?\nSe sim, insira o email da sua conta abaixo para confirmar.\nOBS: Apos confirmar, essa a�ao nao podera ser desfeita!", "Excluir", "Cancelar");
CancelSelectTextDraw(playerid);
}
}
}
}
else if(clickedid == TextSkin[4])
{
SetPlayerSkin(playerid, SkinPlayer[playerid]);
CancelSelectTextDraw(playerid);
SetPlayerVirtualWorld(playerid, 0);
}
else if(clickedid == TextSkin[2])
{
for(new s; s < 16; s++)
{
if(FardaList[playerid] == FardaSkin[s])
{
FardaList[playerid] = FardaSkin[s+1];
SetPlayerSkin(playerid, FardaList[playerid]);
ApplyAnimation(playerid, "CLOTHES", "CLO_POSE_LOOP", 4.1, 1, 0, 0, 0, 0, 1);
new NomeSkin[25];
format(NomeSkin, sizeof(NomeSkin), "SKIN_POLICIAL_ID_%d", FardaList[playerid]);
PlayerTextDrawSetString(playerid, TextSkinP[playerid][1], NomeSkin);
return 1;
}
}
PlayerPlaySound(playerid, 1054, 0.0, 0.0, 10.0);
}
else if(clickedid == TextSkin[3])
{
for(new s; s < 16; s++)
{
if(FardaList[playerid] == FardaSkin[s])
{
FardaList[playerid] = FardaSkin[s-1];
SetPlayerSkin(playerid, FardaList[playerid]);
ApplyAnimation(playerid, "CLOTHES", "CLO_POSE_LOOP", 4.1, 1, 0, 0, 0, 0, 1);
new NomeSkin[25];
format(NomeSkin, sizeof(NomeSkin), "SKIN_POLICIAL_ID_%d", FardaList[playerid]);
PlayerTextDrawSetString(playerid, TextSkinP[playerid][1], NomeSkin);
return 1;
}
}
PlayerPlaySound(playerid, 1054, 0.0, 0.0, 10.0);
}
else if(clickedid == TextConce[8])
{
for(new t; t < 12; t++)
{
TextDrawHideForPlayer(playerid, TextConce[t]);
}
PlayerTextDrawHide(playerid, TextConceP[playerid][0]);
PlayerTextDrawHide(playerid, TextConceP[playerid][1]);
PlayerTextDrawHide(playerid, TextConceP[playerid][2]);
CancelSelectTextDraw(playerid);
new StrG[256]; format(StrG, sizeof(StrG), "\n{FFFFFF}Voce esta comprando um veiculo: {0040FF}%s\n\n{FFFFFF}Valor: {228B22}$%d\n\n{FFFFFF}Velocidade Max: {C8FE2E}%d Km/h\n{FFFFFF}IPVA Diario: {228B22}$%d", NomeVeiculo(VeiculoConce[playerid]), ValorVeiculo(VeiculoConce[playerid]), VelocidadeVeiculo(VeiculoConce[playerid]), ValorVeiculo(VeiculoConce[playerid]) * 1 / 100);
ShowPlayerDialog(playerid, D_CONFIRMARCOMPRAV, DIALOG_STYLE_MSGBOX, "{FFFF00}Confirmacao de Compra", StrG, "Comprar", "Cancelar");
}
else if(clickedid == TextConce[9])
{
for(new t; t < 12; t++)
{
TextDrawHideForPlayer(playerid, TextConce[t]);
}
PlayerTextDrawHide(playerid, TextConceP[playerid][0]);
PlayerTextDrawHide(playerid, TextConceP[playerid][1]);
PlayerTextDrawHide(playerid, TextConceP[playerid][2]);
CancelSelectTextDraw(playerid);
if(VeiculoConce[playerid] > 0)
{
DestroyVehicleC(VeiculoConce[playerid]);
VeiculoConce[playerid] = 0;
}
if(EntrouConce[playerid] <= 0)
{
SetPlayerInterior(playerid, 1);
SetPlayerVirtualWorld(playerid, 333);
}
else if(EntrouConce[playerid] == 1 || EntrouConce[playerid] == 2 || EntrouConce[playerid] == 3 || EntrouConce[playerid] == 4)
{
SetPlayerInterior(playerid, 0);
SetPlayerVirtualWorld(playerid, 0);
}
SetCameraBehindPlayer(playerid);
}
else if(clickedid == TextConce[10])
{
VModel[playerid] ++; BotaoConce[playerid] = true;
if(VeiculoConce[playerid] > 0)
{
DestroyVehicleC(VeiculoConce[playerid]);
}
if(EntrouConce[playerid] <= 0)
{
VerificarVeiculoT(playerid, VModel[playerid]);
VeiculoConce[playerid] = CreateVehicleC(VModel[playerid], 1406.327, -33.054, 1001.610, 66.324, 6, 6, -1);
InterpolateCameraPos(playerid, 1402.870605, -25.381933, 1003.503173, 1403.598266, -27.425102, 1003.061950, 10000);
InterpolateCameraLookAt(playerid, 1404.516723, -29.996837, 1002.506652, 1405.244384, -32.040008, 1002.065429, 10000);
LinkVehicleToInterior(VeiculoConce[playerid], 1);
}
else if(EntrouConce[playerid] == 1)
{
VerificarVeiculoT(playerid, VModel[playerid]);
VeiculoConce[playerid] = CreateVehicleC(VModel[playerid], -1949.4346, 270.0574, 35.4081, 90.00, 6, 6, -1);
InterpolateCameraPos(playerid, -1955.038330, 264.198638, 36.778102, -1953.804565, 265.989959, 36.500186, 10000);
InterpolateCameraLookAt(playerid, -1951.341552, 267.454528, 35.922122, -1949.960571, 269.039459, 35.538669, 10000);
}
else if(EntrouConce[playerid] == 2)
{
VerificarVeiculoT(playerid, VModel[playerid]);
VeiculoConce[playerid] = CreateVehicleC(VModel[playerid], 1943.6202, 2053.2905, 10.5373, 41.8410, 6, 6, -1);
InterpolateCameraPos(playerid, 1936.401855, 2054.596191, 12.171038, 1937.901123, 2054.205078, 11.767107, 10000);
InterpolateCameraLookAt(playerid, 1941.083129, 2053.373046, 10.910345, 1942.582397, 2052.981933, 10.506414, 10000);
}
else if(EntrouConce[playerid] == 3)
{
ValorVeiculoModelAE(playerid, VModel[playerid]);
VeiculoConce[playerid] = CreateVehicleC(VModel[playerid], 2373.1462,-146.9521,32.1453,271.0441, 6, 6, -1);
InterpolateCameraPos(playerid, 2390.682861, -160.366043, 34.482639, 2387.030761, -155.994171, 33.889457, 10000);
InterpolateCameraLookAt(playerid, 2387.708251, -156.376495, 33.997791, 2383.552734, -152.447525, 33.319408, 10000);
}
else if(EntrouConce[playerid] == 4)
{
ValorVeiculoModelAQ(playerid, VModel[playerid]);
VeiculoConce[playerid] = CreateVehicleC(VModel[playerid], -2217.0432, 2406.4370, 0.1869, 47.0884, 6, 6, -1);
InterpolateCameraPos(playerid, -2245.669189, 2411.214355, 9.490036, -2241.890380, 2410.719482, 8.494400, 10000);
InterpolateCameraLookAt(playerid, -2240.873046, 2410.583740, 8.225782, -2237.094238, 2410.088867, 7.230146, 10000);
}
SetPlayerVirtualWorld(playerid, -playerid);
SetVehicleVirtualWorld(VeiculoConce[playerid], -playerid);
new NomeV[20]; format(NomeV, sizeof(NomeV), "%s", NomeVeiculo(VeiculoConce[playerid]));
PlayerTextDrawSetString(playerid, TextConceP[playerid][0], NomeV);
format(NomeV, sizeof(NomeV), "%d KM/H", VelocidadeVeiculo(VeiculoConce[playerid]));
PlayerTextDrawSetString(playerid, TextConceP[playerid][1], NomeV);
format(NomeV, sizeof(NomeV), "%d", ValorVeiculo(VeiculoConce[playerid])); format(NomeV, sizeof(NomeV), "$%s", AttNumeroDecimal(NomeV));
PlayerTextDrawSetString(playerid, TextConceP[playerid][2], NomeV);
}
else if(clickedid == TextConce[11])
{
VModel[playerid] --; BotaoConce[playerid] = false;
if(VeiculoConce[playerid] > 0)
{
DestroyVehicleC(VeiculoConce[playerid]);
}
if(EntrouConce[playerid] <= 0)
{
VerificarVeiculoT(playerid, VModel[playerid]);
VeiculoConce[playerid] = CreateVehicleC(VModel[playerid], 1406.327, -33.054, 1001.610, 66.324, 6, 6, -1);
InterpolateCameraPos(playerid, 1402.870605, -25.381933, 1003.503173, 1403.598266, -27.425102, 1003.061950, 10000);
InterpolateCameraLookAt(playerid, 1404.516723, -29.996837, 1002.506652, 1405.244384, -32.040008, 1002.065429, 10000);
LinkVehicleToInterior(VeiculoConce[playerid], 1);
}
else if(EntrouConce[playerid] == 1)
{
VerificarVeiculoT(playerid, VModel[playerid]);
VeiculoConce[playerid] = CreateVehicleC(VModel[playerid], -1949.4346, 270.0574, 35.4081, 90.00, 6, 6, -1);
InterpolateCameraPos(playerid, -1955.038330, 264.198638, 36.778102, -1953.804565, 265.989959, 36.500186, 10000);
InterpolateCameraLookAt(playerid, -1951.341552, 267.454528, 35.922122, -1949.960571, 269.039459, 35.538669, 10000);
}
else if(EntrouConce[playerid] == 2)
{
VerificarVeiculoT(playerid, VModel[playerid]);
VeiculoConce[playerid] = CreateVehicleC(VModel[playerid], 1943.6202, 2053.2905, 10.5373, 41.8410, 6, 6, -1);
InterpolateCameraPos(playerid, 1936.401855, 2054.596191, 12.171038, 1937.901123, 2054.205078, 11.767107, 10000);
InterpolateCameraLookAt(playerid, 1941.083129, 2053.373046, 10.910345, 1942.582397, 2052.981933, 10.506414, 10000);
}
else if(EntrouConce[playerid] == 3)
{
ValorVeiculoModelAE(playerid, VModel[playerid]);
VeiculoConce[playerid] = CreateVehicleC(VModel[playerid], 2373.1462,-146.9521,32.1453,271.0441, 6, 6, -1);
InterpolateCameraPos(playerid, 2390.682861, -160.366043, 34.482639, 2387.030761, -155.994171, 33.889457, 10000);
InterpolateCameraLookAt(playerid, 2387.708251, -156.376495, 33.997791, 2383.552734, -152.447525, 33.319408, 10000);
}
else if(EntrouConce[playerid] == 4)
{
ValorVeiculoModelAQ(playerid, VModel[playerid]);
VeiculoConce[playerid] = CreateVehicleC(VModel[playerid], -2217.0432, 2406.4370, 0.1869, 47.0884, 6, 6, -1);
InterpolateCameraPos(playerid, -2245.669189, 2411.214355, 9.490036, -2241.890380, 2410.719482, 8.494400, 10000);
InterpolateCameraLookAt(playerid, -2240.873046, 2410.583740, 8.225782, -2237.094238, 2410.088867, 7.230146, 10000);
}
SetPlayerVirtualWorld(playerid, -playerid);
SetVehicleVirtualWorld(VeiculoConce[playerid], -playerid);
new NomeV[20]; format(NomeV, sizeof(NomeV), "%s", NomeVeiculo(VeiculoConce[playerid]));
PlayerTextDrawSetString(playerid, TextConceP[playerid][0], NomeV);
format(NomeV, sizeof(NomeV), "%d KM/H", VelocidadeVeiculo(VeiculoConce[playerid]));
PlayerTextDrawSetString(playerid, TextConceP[playerid][1], NomeV);
format(NomeV, sizeof(NomeV), "%d", ValorVeiculo(VeiculoConce[playerid])); format(NomeV, sizeof(NomeV), "$%s", AttNumeroDecimal(NomeV));
PlayerTextDrawSetString(playerid, TextConceP[playerid][2], NomeV);
}
else if(clickedid == TextSkinMenu[8])
{
EfectCamSkin(playerid);
switch(ModelSelectSkin[playerid])
{
case 0:
{
if(SlotSS[playerid] >= sizeof(SkinsComuns))
{
SlotSS[playerid] = 0;
}
else
{
SlotSS[playerid] ++;
}
SkinSelecionada[playerid] = SkinsComuns[SlotSS[playerid]];
}
case 1:
{
if(SlotSS[playerid] >= sizeof(SkinsExclusivas))
{
SlotSS[playerid] = 0;
}
else
{
SlotSS[playerid] ++;
}
SkinSelecionada[playerid] = SkinsExclusivas[SlotSS[playerid]];
}
case 2:
{
if(SlotSS[playerid] >= sizeof(SkinsSemiRaras))
{
SlotSS[playerid] = 0;
}
else
{
SlotSS[playerid] ++;
}
SkinSelecionada[playerid] = SkinsSemiRaras[SlotSS[playerid]];
}
case 3:
{
if(SlotSS[playerid] >= sizeof(SkinsRaras))
{
SlotSS[playerid] = 0;
}
else
{
SlotSS[playerid] ++;
}
SkinSelecionada[playerid] = SkinsRaras[SlotSS[playerid]];
}
case 4:
{
if(SlotSS[playerid] >= sizeof(SkinsEpicas))
{
SlotSS[playerid] = 0;
}
else
{
SlotSS[playerid] ++;
}
SkinSelecionada[playerid] = SkinsEpicas[SlotSS[playerid]];
}
}
SetPlayerSkin(playerid, SkinSelecionada[playerid]);
new txtidskin[12]; format(txtidskin, sizeof(txtidskin), "%d", SkinSelecionada[playerid]);
PlayerTextDrawSetString(playerid, TextSkinMenuP[playerid][0], txtidskin);
PlayerTextDrawSetPreviewModel(playerid, TextSkinMenuP[playerid][2], SkinSelecionada[playerid]);
PlayerTextDrawShow(playerid, TextSkinMenuP[playerid][2]);
if(!ValorSS[playerid])
{
format(txtidskin, sizeof(txtidskin), "~g~$%d", ValorSkinComum(SkinSelecionada[playerid]));
PlayerTextDrawSetString(playerid, TextSkinMenuP[playerid][1], txtidskin);
}
}
else if(clickedid == TextSkinMenu[9])
{
EfectCamSkin(playerid);
switch(ModelSelectSkin[playerid])
{
case 0:
{
if(SlotSS[playerid] <= 0)
{
SlotSS[playerid] = sizeof(SkinsComuns);
}
else
{
SlotSS[playerid] --;
}
SkinSelecionada[playerid] = SkinsComuns[SlotSS[playerid]];
}
case 1:
{
if(SlotSS[playerid] <= 0)
{
SlotSS[playerid] = sizeof(SkinsExclusivas);
}
else
{
SlotSS[playerid] --;
}
SkinSelecionada[playerid] = SkinsExclusivas[SlotSS[playerid]];
}
case 2:
{
if(SlotSS[playerid] <= 0)
{
SlotSS[playerid] = sizeof(SkinsSemiRaras);
}
else
{
SlotSS[playerid] --;
}
SkinSelecionada[playerid] = SkinsSemiRaras[SlotSS[playerid]];
}
case 3:
{
if(SlotSS[playerid] <= 0)
{
SlotSS[playerid] = sizeof(SkinsRaras);
}
else
{
SlotSS[playerid] --;
}
SkinSelecionada[playerid] = SkinsRaras[SlotSS[playerid]];
}
case 4:
{
if(SlotSS[playerid] <= 0)
{
SlotSS[playerid] = sizeof(SkinsEpicas);
}
else
{
SlotSS[playerid] --;
}
SkinSelecionada[playerid] = SkinsEpicas[SlotSS[playerid]];
}
}
SetPlayerSkin(playerid, SkinSelecionada[playerid]);
new txtidskin[12]; format(txtidskin, sizeof(txtidskin), "%d", SkinSelecionada[playerid]);
PlayerTextDrawSetString(playerid, TextSkinMenuP[playerid][0], txtidskin);
PlayerTextDrawSetPreviewModel(playerid, TextSkinMenuP[playerid][2], SkinSelecionada[playerid]);
PlayerTextDrawShow(playerid, TextSkinMenuP[playerid][2]);
if(!ValorSS[playerid])
{
format(txtidskin, sizeof(txtidskin), "~g~$%d", ValorSkinComum(SkinSelecionada[playerid]));
PlayerTextDrawSetString(playerid, TextSkinMenuP[playerid][1], txtidskin);
}
}
else if(clickedid == TextSkinMenu[6])
{
for(new t; t < 10; t++)
{
TextDrawHideForPlayer(playerid, TextSkinMenu[t]);
}
for(new t; t < 3; t++)
{
PlayerTextDrawHide(playerid, TextSkinMenuP[playerid][t]);
}
if(ValorSS[playerid])
{
format(String, sizeof(String), "\n{FFFFFF}Skin id {4000FF}%d\n\n{FFFFFF}Valor: {FFFF00}%d Coins", SkinSelecionada[playerid], ValorSS[playerid]);
ShowPlayerDialog(playerid, D_ESCOLHERSKIN, DIALOG_STYLE_MSGBOX, "{FFFF00}Skin", String, "Comprar", "Cancelar");
}
else
{
format(String, sizeof(String), "\n{FFFFFF}Skin id {4000FF}%d\n\n{FFFFFF}Valor: {00FF00}$%d", SkinSelecionada[playerid], ValorSkinComum(SkinSelecionada[playerid]));
ShowPlayerDialog(playerid, D_ESCOLHERSKIN, DIALOG_STYLE_MSGBOX, "{FFFF00}Skin", String, "Comprar", "Cancelar");
}
CancelSelectTextDraw(playerid);
}
else if(clickedid == TextSkinMenu[7])
{
SetPlayerSkin(playerid, SkinPlayer[playerid]);
ClearAnimations(playerid, 1);
SetPlayerFacingAngle(playerid, 90.0);
SetCameraBehindPlayer(playerid);
for(new t; t < 10; t++)
{
TextDrawHideForPlayer(playerid, TextSkinMenu[t]);
}
for(new t; t < 3; t++)
{
PlayerTextDrawHide(playerid, TextSkinMenuP[playerid][t]);
}
CancelSelectTextDraw(playerid);
}
else if(clickedid == TextCam[2])
{
new Float:P[3][3]; GetPlayerCameraPos(playerid, P[0][0], P[0][1], P[0][2]); GetPlayerCameraFrontVector(playerid, P[1][0], P[1][1], P[1][2]);
P[2][0] = P[0][0] + floatmul(P[1][0], -0.5);
P[2][1] = P[0][1] + floatmul(P[1][1], -0.5);
P[2][2] = P[0][2] + floatmul(P[1][2], -0.5);
if(IsPlayerInRangeOfPoint(playerid, 5.0, P[2][0], P[2][1], P[2][2])) InterpolateCameraPos(playerid, P[0][0], P[0][1], P[0][2], P[2][0], P[2][1], P[2][2], 500, CAMERA_MOVE);
}
else if(clickedid == TextCam[3])
{
new Float:P[3][3]; GetPlayerCameraPos(playerid, P[0][0], P[0][1], P[0][2]); GetPlayerCameraFrontVector(playerid, P[1][0], P[1][1], P[1][2]);
P[2][0] = P[0][0] + floatmul(P[1][0], 0.5);
P[2][1] = P[0][1] + floatmul(P[1][1], 0.5);
P[2][2] = P[0][2] + floatmul(P[1][2], 0.5);
if(IsPlayerInRangeOfPoint(playerid, 5.0, P[2][0], P[2][1], P[2][2])) InterpolateCameraPos(playerid, P[0][0], P[0][1], P[0][2], P[2][0], P[2][1], P[2][2], 500, CAMERA_MOVE);
}
else if(clickedid == TextCam[4])
{
new Float:P[1][3]; GetPlayerCameraPos(playerid, P[0][0], P[0][1], P[0][2]);
if(IsPlayerInRangeOfPoint(playerid, 5.0, P[0][0], P[0][1], P[0][2])) InterpolateCameraPos(playerid, P[0][0], P[0][1], P[0][2], P[0][0], P[0][1], P[0][2]+0.2, 500, CAMERA_MOVE);
}
else if(clickedid == TextCam[5])
{
new Float:P[1][3]; GetPlayerCameraPos(playerid, P[0][0], P[0][1], P[0][2]);
if(IsPlayerInRangeOfPoint(playerid, 5.0, P[0][0], P[0][1], P[0][2])) InterpolateCameraPos(playerid, P[0][0], P[0][1], P[0][2], P[0][0], P[0][1], P[0][2]-0.2, 500, CAMERA_MOVE);
}
else if(clickedid == TextCam[6])
{
new Float:R; GetPlayerFacingAngle(playerid, R); SetPlayerFacingAngle(playerid, R-5.0);
}
else if(clickedid == TextCam[7])
{
new Float:R; GetPlayerFacingAngle(playerid, R); SetPlayerFacingAngle(playerid, R+5.0);
}
else if(clickedid == TextCam[9])
{
PosItem[playerid][IndexEscolhido[playerid]][0] = floatsub(PosItem[playerid][IndexEscolhido[playerid]][0], 0.01);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[10])
{
PosItem[playerid][IndexEscolhido[playerid]][0] = floatadd(PosItem[playerid][IndexEscolhido[playerid]][0], 0.01);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[11])
{
PosItem[playerid][IndexEscolhido[playerid]][1] = floatsub(PosItem[playerid][IndexEscolhido[playerid]][1], 0.01);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[12])
{
PosItem[playerid][IndexEscolhido[playerid]][1] = floatadd(PosItem[playerid][IndexEscolhido[playerid]][1], 0.01);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[13])
{
PosItem[playerid][IndexEscolhido[playerid]][2] = floatsub(PosItem[playerid][IndexEscolhido[playerid]][2], 0.01);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[14])
{
PosItem[playerid][IndexEscolhido[playerid]][2] = floatadd(PosItem[playerid][IndexEscolhido[playerid]][2], 0.01);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[16])
{
PosItem[playerid][IndexEscolhido[playerid]][3] = floatsub(PosItem[playerid][IndexEscolhido[playerid]][3], 2.0);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[17])
{
PosItem[playerid][IndexEscolhido[playerid]][3] = floatadd(PosItem[playerid][IndexEscolhido[playerid]][3], 2.0);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[18])
{
PosItem[playerid][IndexEscolhido[playerid]][4] = floatsub(PosItem[playerid][IndexEscolhido[playerid]][4], 2.0);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[19])
{
PosItem[playerid][IndexEscolhido[playerid]][4] = floatadd(PosItem[playerid][IndexEscolhido[playerid]][4], 2.0);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[20])
{
PosItem[playerid][IndexEscolhido[playerid]][5] = floatsub(PosItem[playerid][IndexEscolhido[playerid]][5], 2.0);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[21])
{
PosItem[playerid][IndexEscolhido[playerid]][5] = floatadd(PosItem[playerid][IndexEscolhido[playerid]][5], 2.0);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[23])
{
PosItem[playerid][IndexEscolhido[playerid]][6] = floatsub(PosItem[playerid][IndexEscolhido[playerid]][6], 0.2);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[24])
{
PosItem[playerid][IndexEscolhido[playerid]][6] = floatadd(PosItem[playerid][IndexEscolhido[playerid]][6], 0.2);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[25])
{
PosItem[playerid][IndexEscolhido[playerid]][7] = floatsub(PosItem[playerid][IndexEscolhido[playerid]][7], 0.2);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[26])
{
PosItem[playerid][IndexEscolhido[playerid]][7] = floatadd(PosItem[playerid][IndexEscolhido[playerid]][7], 0.2);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[27])
{
PosItem[playerid][IndexEscolhido[playerid]][8] = floatsub(PosItem[playerid][IndexEscolhido[playerid]][8], 0.2);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[28])
{
PosItem[playerid][IndexEscolhido[playerid]][8] = floatadd(PosItem[playerid][IndexEscolhido[playerid]][8], 0.2);
AtacharItem(playerid, IndexEscolhido[playerid], 0, -1);
}
else if(clickedid == TextCam[29])
{
for(new t; t < 30; t++)
{
TextDrawHideForPlayer(playerid, TextCam[t]);
}
CancelSelectTextDraw(playerid);
SetCameraBehindPlayer(playerid);
}
else if(clickedid == TextEleicao[21])
{
for(new t; t < 22; t++)
{
TextDrawHideForPlayer(playerid, TextEleicao[t]);
}
CancelSelectTextDraw(playerid);
}
else
{
for(new t = 1; t < 11; t++)
{
if(clickedid == TextEleicao[t])
{
if(!new_strcmp(Candidato[t-1], "Ninguem"))
{
new StrV[128]; format(StrV, sizeof(StrV), "\n{FFFF00}Voce esta votando em:\n\n{FFFFFF}Prefeito: %s\n\nDeseja confirmar seu voto?", Candidato[t-1]);
ShowPlayerDialog(playerid, D_CONFIRMARVOTO, DIALOG_STYLE_MSGBOX, "{FF0000}Votacao", StrV, "Confirmar", "Cancelar");
SelecionouCandidato[playerid] = t - 1;
CancelSelectTextDraw(playerid);
}
return 1;
}
}
}
}
else
{
if(FardaList[playerid] > -1)
{
for(new t; t < 5; t++)
{
TextDrawHideForPlayer(playerid, TextSkin[t]);
}
PlayerTextDrawHide(playerid, TextSkinP[playerid][0]);
PlayerTextDrawHide(playerid, TextSkinP[playerid][1]);
ClearAnimations(playerid, 1);
SetPlayerFacingAngle(playerid, 180.5226);
SetCameraBehindPlayer(playerid);
SetPlayerVirtualWorld(playerid, 0);
FardaList[playerid] = -1;
}
}
return 1;
}forward Cr_RepCofre(xCofre);
public Cr_RepCofre(xCofre){
new string[128];
Cr_StCofres[xCofre] = 0;
DestroyDynamicObject(Cr_pObjCofre[xCofre]);
Cr_pObjCofre[xCofre] = CreateDynamicObject(2332, Cr_PosCofres[xCofre][0], Cr_PosCofres[xCofre][1], Cr_PosCofres[xCofre][2]-0.55, 0.0, 0.0, Cr_PosCofres[xCofre][3]-180.0);
format(string, sizeof(string), "Cofre\n{FFFFFF}/cofre");
UpdateDynamic3DTextLabelText(Cr_TxtLbcofre[xCofre], 0xFF0000FF, string);
return 1;
}
public OnPlayerEditObject(playerid, playerobject, objectid, response, Float:fX, Float:fY, Float:fZ, Float:fRotX, Float:fRotY, Float:fRotZ)
{
if(AstraModo[playerid] == ASTRA_MODO_PVP) return 1;
if(response == 1)
{
for(new i; i < 40; i++)
{
format(String, sizeof(String), "CaixasEletronicos/%d.ini", i);
if(!DOF2_FileExists(String))
{
DOF2_CreateFile(String);
DOF2_SetFloat(String, "X", fX);
DOF2_SetFloat(String, "Y", fY);
DOF2_SetFloat(String, "Z", fZ);
DOF2_SetFloat(String, "RX", fRotX);
DOF2_SetFloat(String, "RY", fRotY);
DOF2_SetFloat(String, "RZ", fRotZ);
DOF2_SetInt(String, "Valor", 1000);
DOF2_SaveFile();
SendClientMessage(playerid, -1, "| CAIXA | Caixa Eletronico criado com sucesso!");
return 1;
}
}
}
return 1;
}
public OnPlayerClickMap(playerid, Float:fX, Float:fY, Float:fZ)
{
if(AstraModo[playerid] == ASTRA_MODO_PVP) return 1;
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(GetPlayerState(playerid) == PLAYER_STATE_DRIVER)
{
new veh = GetPlayerVehicleID(playerid);
SetVehiclePos(veh, fX, fY, fZ);
}
else
{
SetPlayerPosFindZ(playerid, fX, fY, fZ);
SetPlayerInterior(playerid, 0);
SetPlayerVirtualWorld(playerid, 0);
}
}
return 1;
}
stock ResetPlayerWeaponsExC(playerid){
for(new s=0; s<50; s++) uQBSWeaponID[playerid][s] = 0;
ResetPlayerWeapons(playerid);
return 1;
}
public OnPlayerShootDynamicObject(playerid, weaponid, objectid, Float:x, Float:y, Float:z)
{
if(AstraModo[playerid] == ASTRA_MODO_PVP) return 1;
new bool:VerificationPorte;
for(new m = 1; m < 8; m++)
{
if(ObjetoAlvo[playerid][m] > 0 && objectid == ObjetoAlvo[playerid][m])
{
DestroyDynamicObject(ObjetoAlvo[playerid][m]);
ObjetoAlvo[playerid][m] = 0;
PlayerPlaySound(playerid,17802,0.0,0.0,0.0);
VerificationPorte = true;
break;
}
}
if(VerificationPorte == true)
{
new obj;
for(new m; m < 8; m++)
{
if(ObjetoAlvo[playerid][m] == 0)
{
obj ++;
}
}
if(obj >= 7)
{
DestroyDynamicObject(ObjetoAlvo[playerid][0]);
ObjetoAlvo[playerid][0] = CreateDynamicObject(3025, 330.00000, -64.27800, 1004.34003,   0.00000, 0.00000, -90.00000);
ObjetoAlvo[playerid][1] = CreateDynamicObject(3024, 330.00000, -64.24420, 1004.29999,   0.00000, 0.00000, -90.00000);
ObjetoAlvo[playerid][2] = CreateDynamicObject(3023, 330.00000, -64.23360, 1004.29999,   0.00000, 0.00000, -90.00000);
ObjetoAlvo[playerid][3] = CreateDynamicObject(3022, 330.00000, -64.25360, 1004.29999,   0.00000, 0.00000, -90.00000);
ObjetoAlvo[playerid][4] = CreateDynamicObject(3021, 330.00000, -64.23730, 1004.29999,   0.00000, 0.00000, -90.00000);
ObjetoAlvo[playerid][5] = CreateDynamicObject(3020, 330.00000, -64.23100, 1004.32001,   0.00000, 0.00000, -90.00000);
ObjetoAlvo[playerid][6] = CreateDynamicObject(3019, 330.00000, -64.23000, 1004.32001,   0.00000, 0.00000, -90.00000);
ObjetoAlvo[playerid][7] = CreateDynamicObject(3018, 330.00000, -64.24000, 1004.32001,   0.00000, 0.00000, -90.00000);
new Float:X, Float:Y, Float:Z, xx = 15 + random(3), yy = random(5), lado = random(2);
if(lado == 0)
{
for(new m; m < 8; m++)
{
GetDynamicObjectPos(ObjetoAlvo[playerid][m], X, Y, Z);
MoveDynamicObject(ObjetoAlvo[playerid][m], X - xx, Y + yy, Z, 1.5, 0.0, 0.0, -90.0);
}
}
else if(lado == 1)
{
for(new m; m < 8; m++)
{
GetDynamicObjectPos(ObjetoAlvo[playerid][m], X, Y, Z);
MoveDynamicObject(ObjetoAlvo[playerid][m], X - xx, Y - yy, Z, 1.5, 0.0, 0.0, -90.0);
}
}
Streamer_Update(playerid);
ArmaAlvo[playerid] ++;
if(ArmaAlvo[playerid] == 1)
{
GameTextForPlayer(playerid, "~w~Acerte o Alvo!", 2000, 3);
SetTimerEx("CarregarInterior", 1500, false, "i", playerid);
TogglePlayerControllable(playerid, 0);
}
else if(ArmaAlvo[playerid] == 2)
{
GameTextForPlayer(playerid, "~w~Acerte o Alvo!", 2000, 3);
SetTimerEx("CarregarInterior", 1500, false, "i", playerid);
TogglePlayerControllable(playerid, 0);
}
else if(ArmaAlvo[playerid] == 3)
{
GameTextForPlayer(playerid, "~w~Acerte o Alvo!", 2000, 3);
SetTimerEx("CarregarInterior", 1500, false, "i", playerid);
TogglePlayerControllable(playerid, 0);
}
else if(ArmaAlvo[playerid] >= 4)
{
ResetPlayerWeaponsExC(playerid);
ArmaAlvo[playerid] = -1;
if(Money[playerid] >= 20000)
{
Porte[playerid] = 10;
Money[playerid] -= 20000;
PlayerPlaySound(playerid, 1139, 0.0, 0.0, 0.0);
GameTextForPlayer(playerid, "~b~~h~TESTE CONCLUIDO", 3000, 0);
SendClientMessage(playerid, -1, "| INFO | Voce passou no teste de tiro ao alvo e adquiriu seu porte de armas com sucesso!");
}
else
{
GameTextForPlayer(playerid, "~r~~h~TESTE FRACASSADO", 3000, 0);
SendClientMessage(playerid, COR_ERRO, "| ERRO | Voce passou no teste porem nao tem dinheiro suficiente para comprar o porte de armas");
}
for(new m; m < 8; m++)
{
if(ObjetoAlvo[playerid][m] > 0)
{
DestroyDynamicObject(ObjetoAlvo[playerid][m]);
ObjetoAlvo[playerid][m] = 0;
}
}
return 1;
}
}
}
if(GetDynamicObjectModel(objectid) == 19315)
{
if(StatusAnimal[objectid] == 0 && GetPlayerWeapon(playerid) == 25 && PROF[playerid] == CACADOR && !IsPlayerInAnyVehicle(playerid))
{
new Float:X, Float:Y, Float:Z;
GetDynamicObjectPos(objectid, X, Y, Z);
MoveDynamicObject(objectid, X, Y, Z-0.3, 0.7, 90.0000, 0.0000, 0.0000);
DestroyDynamic3DTextLabel(TextAniamal[objectid]);
TextAniamal[objectid] = CreateDynamic3DTextLabel("{58FA58}Veado\n{FFFFFF}Digite /PegarCaca", -1, X, Y, Z-0.1, 2.0);
StatusAnimal[objectid] = 1;
new som = random(3);
if(som == 0)
{
foreach(Player, i)
{
if(IsPlayerInRangeOfPoint(i, 100.0, X, Y, Z))
{
PlayAudioStreamForPlayer(i, "https://bit.ly/SomVeado1", X, Y, Z, 100.0, 1);
}
}
}
else if(som == 1)
{
foreach(Player, i)
{
if(IsPlayerInRangeOfPoint(i, 100.0, X, Y, Z))
{
PlayAudioStreamForPlayer(i, "https://bit.ly/SomVeado2", X, Y, Z, 100.0, 1);
}
}
}
else if(som == 2)
{
foreach(Player, i)
{
if(IsPlayerInRangeOfPoint(i, 100.0, X, Y, Z))
{
PlayAudioStreamForPlayer(i, "https://bit.ly/SomVeado3", X, Y, Z, 100.0, 1);
}
}
}
}
}
return 1;
}
forward ChamadaUmSegundo();
public ChamadaUmSegundo()
{
new mess[12], hora, minuto, segundo, dia, mes, ano; gettime(hora, minuto, segundo); getdate(ano, mes, dia);
format(mess, sizeof(mess), "%d", JogadoresConectados);
TextDrawSetString(TextLogin[0], mess);
format(mess, sizeof(mess), "%d", AccRegistrada);
TextDrawSetString(TextLogin[1], mess);
format(mess, sizeof(mess), "%d", LoginsHoje);
TextDrawSetString(TextLogin[2], mess);
if(hora == 5 && minuto == 59 && segundo == 0)
{
SendClientMessageToAll(0x8FBC8FFF, "| SERVER | O servidor esta programado para reiniciar as 06:00");
GameTextForAll("~r~O SERVIDOR SERA REINICIADO", 5000, 3);
}
else if(hora == 6 && minuto == 0 && segundo == 0)
{
for(new p; p < MAX_PLAYERS; p++)
{
Kick(p);
}
SetTimer("ReiniciarServer", 1000, false);
}
else if(hora == 17 && minuto == 59 && segundo == 0)
{
SendClientMessageToAll(0x8FBC8FFF, "| SERVER | O servidor esta programado para reiniciar as 18:00");
GameTextForAll("~r~O SERVIDOR SERA REINICIADO", 5000, 3);
}
else if(hora == 18 && minuto == 0 && segundo == 0)
{
for(new p; p < MAX_PLAYERS; p++)
{
Kick(p);
}
SetTimer("ReiniciarServer", 1000, false);
}
new animactor = random(200), animactor1 = random(1000);
if(animactor < 10)
{
ApplyDynamicActorAnimation(ActorDrogas[0], "RAPPING", "RAP_A_LOOP", 4.1, 1, 0, 0, 0, 0);
}
else if(animactor >= 10 && animactor < 20)
{
ApplyDynamicActorAnimation(ActorDrogas[0], "COP_AMBIENT", "COPLOOK_LOOP", 4.1, 1, 0, 0, 0, 0);
}
if(animactor1 < 50)
{
ApplyDynamicActorAnimation(ActorArmas[0], "WEAPONS", "SHP_TRAY_POSE", 4.1, 1, 0, 0, 0, 0);
}
else if(animactor1 >= 50 && animactor1 < 100)
{
ApplyDynamicActorAnimation(ActorArmas[0], "COP_AMBIENT", "COPLOOK_LOOP", 4.1, 1, 0, 0, 0, 0);
}
else if(animactor1 >= 100 && animactor1 < 200)
{
ApplyDynamicActorAnimation(ActorArmas[0], "RAPPING", "RAP_A_LOOP", 4.1, 1, 0, 0, 0, 0);
}
if(BlokSequestro > 0)
{
BlokSequestro --;
}
if(BlokFaq > 0)
{
BlokFaq --;
}
if(TimerReiniciar > 0)
{
TimerReiniciar --;
if(TimerReiniciar == 1)
{
SendClientMessageToAll(0x8FBC8FFF, "| SERVIDOR | Reiniciando servidor... Voltamos ja!");
}
if(TimerReiniciar == 0)
{
for(new p; p < MAX_PLAYERS; p++)
{
Kick(p);
}
SetTimer("ReiniciarServerComando", 1000, false);
}
}
if(TimerRc > 0)
{
TimerRc --;
if(TimerRc > 0 && TimerRc <= 5)
{
new timerstrr[20]; format(timerstrr, sizeof(timerstrr), "~y~] ~r~%d ~y~]", TimerRc);
GameTextForAll(timerstrr, 1500, 3);
}
else if(TimerRc == 0)
{
for(new v = GetVehiclePoolSize(); v > 0; v--)
{
if(!IsVehicleOccupied(v) && NotTrailerAtached(v)) SetVehicleToRespawn(v);
}
GameTextForAll("~w~Veiculos Respawnados!", 2000, 3);
}
}
if(ContagemEvento > 0)
{
ContagemEvento --;
if(ContagemEvento > 0)
{
new timerstrr[20]; format(timerstrr, sizeof(timerstrr), "~b~] ~r~%d ~b~]", ContagemEvento);
GameTextForAll(timerstrr, 1500, 3);
}
else
{
foreach(Player, i)
{
if(IsPlayerConnected(i) && Spawnado[i] == true && NoEvento[i] > 0)
{
TogglePlayerControllable(i, 1);
GameTextForPlayer(i, "~b~] ~r~VAI! ~b~]", 1500, 3);
}
}
}
}
if(SegundosAvisoTela > 0)
{
SegundosAvisoTela --;
if(SegundosAvisoTela <= 0)
{
TextDrawHideForAll(AvisoTela);
}
}
for(new f; f < 2; f++)
{
if(SegMateriaisFav[f] >= 0 && DonoFavela[f] < 30)
{
SegMateriaisFav[f] --;
if(SegMateriaisFav[f] <= -1)
{
SegMateriaisFav[f] = 59;
MinMateriaisFav[f] --;
if(MinMateriaisFav[f] <= -1)
{
MinMateriaisFav[f] = 29;
new Strcor[15], nomefavela[20];
switch(f)
{
case 0: nomefavela = "Sao Paulo";
case 1: nomefavela = "Rio De Janeiro";
case 2: nomefavela = "Bahia";
}
format(Strcor, sizeof(Strcor), "0x%sFF", gCor[DonoFavela[f]]);
format(String, sizeof(String), "| INFO | Sua Organizacao ficou 30 minutos com a favela de %s dominada e recebeu +30 materiais", nomefavela);
gMateriais[DonoFavela[f]] += 30;
foreach(Player, i)
{
if(Spawnado[i] && ORG[i] == DonoFavela[f])
{
SendClientMessage(i, HexToInt(Strcor), String);
}
}
}
}
}
}
for(new px; px < 21; px++)
{
if(!IsDynamicObjectMoving(Peixe[px]))
{
new rand = random(sizeof(SpawnPeixes));
MoveDynamicObject(Peixe[px], SpawnPeixes[rand][0], SpawnPeixes[rand][1], SpawnPeixes[rand][2], random(5), 0.0, 0.0, SpawnPeixes[rand][1] - SpawnPeixes[rand][0]);
}
}
foreach(Player, i)
{
if(IsPlayerInLS(i))
{
if(GetPlayerDrunkLevel(i) > 5000 && GetPlayerDrunkLevel(i) <= 7000 && SONO[i] >= 0)
{
SetPlayerWeather(i, -66);
}
else if(GetPlayerDrunkLevel(i) > 7000 && SONO[i] >= 0)
{
SetPlayerWeather(i, -11111111);
}
else
{
SetPlayerWeather(i,ClimaCidades[0]);
}
}
else if(IsPlayerInLV(i))
{
if(GetPlayerDrunkLevel(i) > 5000 && GetPlayerDrunkLevel(i) <= 7000 && SONO[i] >= 0)
{
SetPlayerWeather(i, -66);
}
else if(GetPlayerDrunkLevel(i) > 7000 && SONO[i] >= 0)
{
SetPlayerWeather(i, -11111111);
}
else
{
SetPlayerWeather(i,ClimaCidades[1]);
}
}
else if(IsPlayerInSF(i))
{
if(GetPlayerDrunkLevel(i) > 5000 && GetPlayerDrunkLevel(i) <= 7000 && SONO[i] >= 0)
{
SetPlayerWeather(i, -66);
}
else if(GetPlayerDrunkLevel(i) > 7000 && SONO[i] >= 0)
{
SetPlayerWeather(i, -11111111);
}
else
{
SetPlayerWeather(i,ClimaCidades[2]);
}
}
if(Spawnado[i] == true)
{
if(pVoip[i] == 0)
{
new strID[255];
new StringConta[40]; format(StringConta, sizeof(StringConta), "Contas/%s.ini", PlayerName(i));
format(strID, sizeof(strID), "ID: %d VOIP: [OFF]\nRG: %d",i,DOF2_GetInt(StringConta, "IDs"));
SetPlayerChatBubble(i, strID, 0xFFFFFFFF, 30.0, 2000);
}
if(pVoip[i] == 1)
{
new strID[255];
new StringConta[40]; format(StringConta, sizeof(StringConta), "Contas/%s.ini", PlayerName(i));
format(strID, sizeof(strID), "ID: %d VOIP: [ON]\nRG: %d",i,DOF2_GetInt(StringConta, "IDs"));
SetPlayerChatBubble(i, strID, 0xFFFFFFFF, 30.0, 2000);
}
if(VIP[i] > 0 && VerifyExpiredDays(VIP[i]))
{
VIP[i] = 0;
SendClientMessage(i, 0xFFFF00FF, "| VIP | Seu VIP expirou... Ative outro agora mesmo com o comando /Loja");
}
if(MinerandoBTC[i] > 0 && AttAfk[i] < 1001)
{
new msg[45]; MinerandoBTC[i] ++;
if(MinerandoBTC[i] < 60)
{
format(msg, sizeof(msg), "~h~Minerando BTC ~y~%d/60", MinerandoBTC[i]);
GameTextForPlayer(i, msg, 2000, 4);
}
else
{
MinerandoBTC[i] = 0;
format(msg, sizeof(msg), "0.0%d", JogadoresConectados);
BTC[i] += floatstr(msg); Demanda += floatstr(msg);
ValorBTC[0] = floatround(floatsub(Demanda, Oferta), floatround_round);
if(ValorBTC[0] <= 0) ValorBTC[0] = 1;
format(msg, sizeof(msg), "~w~+ ~r~%0.6f BTC", floatstr(msg));
GameTextForPlayer(i, msg, 2000, 4);
ShowPlayerDialog(i, D_BTCMINERAR, DIALOG_STYLE_MSGBOX, "{e0c600}Mineracao de Bitcoin", "\n{FFFFFF}Mineracao Concluida!\n", "Ok", "Fechar");
AtualizarBTC(i);
}
}
if(PROF[i] == PESCADOR && Pescando[i] == true)
{
if(IsPlayerInDynamicCP(i, CheckPesca[i]) && IsPlayerAttachedObjectSlotUsed(i, 6))
{
MsgAviso(i, 2, "~b~~h~Pescaria: ~g~~h~Ativa");
new peixesorteado = random(100);
if(peixesorteado == 5)
{
PescouPeixe[i] = 1599;
SetPlayerAttachedObject(i, 8, 1599, 1, -0.1549, 1.3790, -0.4170, -5.6999, -2.0000, -90.9999, 1.0000, 1.5289, 1.1549, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(i, GetPlayerColor(i), "| PESCA | Voce pescou um Dourado, digite /guardar para guarda-lo no inventario");
}
else if(peixesorteado == 10)
{
PescouPeixe[i] = 1604;
SetPlayerAttachedObject(i, 8, 1604, 1, -0.1549, 1.3790, -0.4170, -5.6999, -2.0000, -90.9999, 1.0000, 1.8060, 1.3999, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(i, GetPlayerColor(i), "| PESCA | Voce pescou um Pacu, digite /guardar para guarda-lo no inventario");
}
else if(peixesorteado == 15)
{
PescouPeixe[i] = 19630;
SetPlayerAttachedObject(i, 8, 19630, 1, -0.1549, 1.3790, -0.4170, -5.7999, 1.0999, 176.3999, 2.2499, 1.8060, 1.6619, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(i, GetPlayerColor(i), "| PESCA | Voce pescou uma Tilapia, digite /guardar para guarda-la no inventario");
}
else if(peixesorteado == 20)
{
PescouPeixe[i] = 1600;
SetPlayerAttachedObject(i, 8, 1600, 1, -0.1549, 1.3790, -0.4170, 8.4000, -2.0000, -94.2002, 2.2499, 1.6000, 1.2849, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(i, GetPlayerColor(i), "| PESCA | Voce pescou um Tucunara Azul, digite /guardar para guarda-lo no inventario");
}
else if(peixesorteado == 25)
{
PescouPeixe[i] = 1608;
SetPlayerAttachedObject(i, 8, 1608, 5, 2.0629, -0.6680, -0.0150, -36.5000, 131.4000, -63.9000, 0.3699, 0.3439, 0.4710, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(i, GetPlayerColor(i), "| PESCA | Voce pescou um Tubarao, digite /guardar para guarda-lo no inventario");
}
}
else
{
MsgAviso(i, 2, "~b~~h~Pescaria: ~r~~h~Inativa");
if(IsPlayerAttachedObjectSlotUsed(i, 8))
{
RemovePlayerAttachedObject(i, 8);
}
if(IsPlayerAttachedObjectSlotUsed(i, 6))
{
RemovePlayerAttachedObject(i, 6);
}
PescouPeixe[i] = -1;
}
}
if(hidetext[i] == true)
{
for(new t; t < 6; t++)
{
TextDrawHideForPlayer(i, TextSniperInfo[t]);
}
for(new t; t < 4; t++)
{
PlayerTextDrawHide(i, TextSniperInfoP[i][t]);
}
hidetext[i] = false;
}
new Keys, ud, lr; GetPlayerKeys(i, Keys, ud, lr);
if(Keys == KEY_AIM && GetPlayerWeapon(i) == 34)
{
new
StrTarget[25],
Float:fPX, Float:fPY, Float:fPZ,
Float:fVX, Float:fVY, Float:fVZ,
Float:object_x, Float:object_y, Float:object_z;
GetPlayerCameraPos(i, fPX, fPY, fPZ);
GetPlayerCameraFrontVector(i, fVX, fVY, fVZ);
foreach(Player, ii)
{
new Float:X, Float:Y, Float:Z; GetPlayerPos(ii, X, Y, Z);
new Float:fDistance = GetPlayerDistanceFromPoint(i, X, Y, Z);
object_x = fPX + floatmul(fVX, fDistance);
object_y = fPY + floatmul(fVY, fDistance);
object_z = fPZ + floatmul(fVZ, fDistance);
if(fDistance <= 250.0 && i != ii && GetPlayerState(ii) != PLAYER_STATE_SPECTATING)
{
if(IsPlayerInRangeOfPoint(ii, 0.5, object_x, object_y, object_z) || IsPlayerInRangeOfPoint(ii, 0.5, object_x, object_y, object_z+0.5) || IsPlayerInRangeOfPoint(ii, 0.5, object_x, object_y, object_z-0.5))
{
format(StrTarget, sizeof(StrTarget), "%s", PlayerName(ii));
PlayerTextDrawSetString(i, TextSniperInfoP[i][0], StrTarget);
new Float:VidaTarget; GetPlayerHealth(ii, VidaTarget);
format(StrTarget, sizeof(StrTarget), "%0.1f", VidaTarget);
PlayerTextDrawSetString(i, TextSniperInfoP[i][1], StrTarget);
new Float:ColeteTarget; GetPlayerArmour(ii, ColeteTarget);
format(StrTarget, sizeof(StrTarget), "%0.1f", ColeteTarget);
PlayerTextDrawSetString(i, TextSniperInfoP[i][2], StrTarget);
format(StrTarget, sizeof(StrTarget), "%0.1fM", fDistance);
PlayerTextDrawSetString(i, TextSniperInfoP[i][3], StrTarget);
for(new t; t < 6; t++)
{
TextDrawShowForPlayer(i, TextSniperInfo[t]);
}
for(new t; t < 4; t++)
{
PlayerTextDrawShow(i, TextSniperInfoP[i][t]);
}
hidetext[i] = true;
}
}
}
}
if(IsPlayerInRangeOfPoint(i, 30.0, XATT[i], YATT[i], ZATT[i]))
{
if(AttAfk[i] < 600)
{
AttAfk[i] ++;
}
else if(AttAfk[i] <= 1000)
{
AttAfk[i] = 1001;
SendClientMessage(i, -1, "| AFK | Voce esta ausente!");
format(Captcha[i], 17, "%s %s", GerarCodigo(1 + random(4)), GerarCodigo(1 + random(4)));
new strcap[80]; format(strcap, sizeof(strcap), "\n{FFFFFF}Digite o codigo: {FF0000}%s\n{FFFFFF}para voltar ao jogo", Captcha[i]);
ShowPlayerDialog(i, D_AFK, DIALOG_STYLE_INPUT, "{FFFFFF}Resolva o {FF0000}CAPTCHA", strcap, "Ok", "");
}
}
else
{
if((gettime() - MudouInterior[i]) >= 10)
{
if(!IsPlayerInRangeOfPoint(i, 300.0, XATT[i], YATT[i], ZATT[i]) && NivelAdmin[i] <= 0 && Estagiario[i] <= 0 && !IsPlayerAdmin(i) && GetPlayerState(i) != PLAYER_STATE_PASSENGER)
{
if((gettime() - AntiFload[i]) > 10)
{
AntiFload[i] = gettime();
foreach(Player, admin)
{
if(IsPlayerConnected(admin) && Spawnado[admin] == true && NivelAdmin[admin] > 0 || IsPlayerAdmin(admin))
{
new StrAC[128]; format(StrAC, sizeof(StrAC), "| ANTI-CHEAT | O(A) Jogador(a) %s[%d] esta com suspeita de teleport, de olho nele!", PlayerName(i), i);
SendClientMessage(admin, 0xFF0000FF, StrAC);
}
}
}
}
}
if(AttAfk[i] < 1001)
{
AttAfk[i] = 0;
}
GetPlayerPos(i, XATT[i], YATT[i], ZATT[i]);
}
if(GetPlayerSpeed(i) > 160)
{
if((gettime() - AntiFload[i]) > 10)
{
AntiFload[i] = gettime();
foreach(Player, p)
{
if(IsPlayerConnected(p) && Spawnado[p] == true && NivelAdmin[p] > 0 || IsPlayerAdmin(p))
{
new StrAC[128]; format(StrAC, sizeof(StrAC), "| ANTI-CHEAT | O(A) Jogador(a) %s[%d] esta com suspeita de speed, de olho nele!", PlayerName(i), i);
SendClientMessage(p, 0xFF0000FF, StrAC);
}
}
}
}
if(SegundosPreso[i] <= 0 && MinutosPreso[i] <= 0 && HorasPreso[i] <= 0 && AttAfk[i] < 600)
{
if(SONO[i] > 0 && GetPlayerScore(i) > 10)
{
FOME[i] --; SEDE[i] --;
}
if(Dormindo[i] == false)
{
SONO[i] --;
if(SONO[i] < 0)
{
new drunklevel = SONO[i] * 30 * -1;
SetPlayerDrunkLevel(i, drunklevel);
if(SONO[i] == -1)
{
SendClientMessage(i, 0x848484FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SendClientMessage(i, 0x848484FF, "~> {FFFFFF}Seu personagem esta com sono, va ate um hotel ou uma casa dormir");
SendClientMessage(i, 0x848484FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
MsgAviso(i, 5, "~w~SEU PERSONAGEM ESTA COM SONO");
}
else if(SONO[i] == -120)
{
SendClientMessage(i, 0x848484FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SendClientMessage(i, 0x848484FF, "~> {FFFFFF}Seu personagem esta com muito sono, va ate um hotel ou uma casa dormir");
SendClientMessage(i, 0x848484FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
PlayerTextDrawBoxColor(i, TextTelaPreta[i], 0x00000066);
PlayerTextDrawShow(i, TextTelaPreta[i]);
MsgAviso(i, 5, "~w~SEU PERSONAGEM ESTA COM MUITO SONO");
}
else if(SONO[i] == -240)
{
SendClientMessage(i, 0x848484FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SendClientMessage(i, 0x848484FF, "~> {FFFFFF}Seu personagem esta morrendo de sono, va ate um hotel ou uma casa dormir");
SendClientMessage(i, 0x848484FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
PlayerTextDrawBoxColor(i, TextTelaPreta[i], 0x00000088);
PlayerTextDrawShow(i, TextTelaPreta[i]);
MsgAviso(i, 5, "~w~SEU PERSONAGEM ESTA MORRENDO DE SONO");
}
else if(SONO[i] <= -400)
{
SONO[i] = 0;
PlayerTextDrawBoxColor(i, TextTelaPreta[i], 255);
PlayerTextDrawShow(i, TextTelaPreta[i]);
SendClientMessage(i, 0x848484FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SendClientMessage(i, 0x848484FF, "~> {FFFFFF}Seu personagem nao aguentou e caiu no sono");
SendClientMessage(i, 0x848484FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
TogglePlayerControllable(i, 0);
GameTextForPlayer(i, "~w~Dormindo...", 3000, 3);
TextDrawShowForPlayer(i, TextConnect[2]);
ApplyAnimation(i, "CRACK", "crckdeth2", 4.0, 1, 0, 0, 0, 0, 1);
Dormindo[i] = true;
}
}
}
}
if(Dormindo[i] == true)
{
SONO[i] += 200;
if(SONO[i] >= 10800)
{
SONO[i] = 10800;
Dormindo[i] = false;
SendClientMessage(i, -1, "| INFO | Seu personagem acordou!");
PlayerTextDrawHide(i, TextTelaPreta[i]);
SetPlayerDrunkLevel(i, 0);
TogglePlayerControllable(i, 1);
ClearAnimations(i, 1);
}
else
{
TextDrawShowForPlayer(i, TextConnect[2]);
GameTextForPlayer(i, "~w~Dormindo...", 1200, 3);
}
}
if(FOME[i] == 432)
{
SendClientMessage(i, 0xDAA520FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SendClientMessage(i, 0xDAA520FF, "~> {FFFFFF}Seu personagem esta com fome, va ate um restaurante e coma algo!");
SendClientMessage(i, 0xDAA520FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
MsgAviso(i, 5, "~w~SEU PERSONAGEM ESTA COM FOME");
}
else if(FOME[i] == 216)
{
SendClientMessage(i, 0xDAA520FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SendClientMessage(i, 0xDAA520FF, "~> {FFFFFF}Seu personagem esta com muita fome, va ate um restaurante e coma algo!");
SendClientMessage(i, 0xDAA520FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
MsgAviso(i, 5, "~w~SEU PERSONAGEM ESTA COM MUITA FOME");
}
else if(FOME[i] < 0 && MinutosMorte[i] <= 0 && SegundosMorte[i] <= 0 && SegundosPreso[i] <= 0 && MinutosPreso[i] <= 0 && HorasPreso[i] <= 0)
{
new Float:Health; GetPlayerHealth(i, Health);
SetPlayerHealth(i, Health-1);
}
if(SEDE[i] == 360)
{
SendClientMessage(i, 0x528B8BFF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SendClientMessage(i, 0x528B8BFF, "~> {FFFFFF}Seu personagem esta com sede, va ate um restaurante e beba algo!");
SendClientMessage(i, 0x528B8BFF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
MsgAviso(i, 5, "~w~SEU PERSONAGEM ESTA COM SEDE");
}
else if(SEDE[i] == 180)
{
SendClientMessage(i, 0x528B8BFF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SendClientMessage(i, 0x528B8BFF, "~> {FFFFFF}Seu personagem esta com muita sede, va ate um restaurante e beba algo!");
SendClientMessage(i, 0x528B8BFF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
MsgAviso(i, 5, "~w~SEU PERSONAGEM ESTA COM MUITA SEDE");
}
else if(SEDE[i] < 0 && MinutosMorte[i] <= 0 && SegundosMorte[i] <= 0  && SegundosPreso[i] <= 0 && MinutosPreso[i] <= 0 && HorasPreso[i] <= 0)
{
new Float:Health; GetPlayerHealth(i, Health);
SetPlayerHealth(i, Health-1);
}
if(sUP[i] > -1 && AttAfk[i] < 1001 && SegundosPreso[i] <= 0 && MinutosPreso[i] <= 0 && HorasPreso[i] <= 0)
{
if(NivelAdmin[i] > 0 || Estagiario[i] > 0)
{
SegundosSalarioAdmin[i] ++;
if(SegundosSalarioAdmin[i] >= 126000)
{
new sadmin;
if(NivelAdmin[i] > 0)
{
switch(NivelAdmin[i])
{
case 1: sadmin = 120000;
case 2: sadmin = 150000;
case 3: sadmin = 250000;
case 4: sadmin = 350000;
}
}
else if(Estagiario[i] > 0)
{
sadmin = 100000;
}
SegundosSalarioAdmin[i] = 0;
SendClientMessage(i, GetPlayerColor(i), "~~~~~~~~~~~~~~~~~~~~~~~~~~~ Salario ADM ~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "~> {FFFFFF}Voce recebeu um salario ADM de $%d", sadmin);
SendClientMessage(i, GetPlayerColor(i), String);
SendClientMessage(i, GetPlayerColor(i), "~~~~~~~~~~~~~~~~~~~~~~~~~~~ Salario ADM ~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SaldoBancario[i] += sadmin;
}
}
sUP[i] --;
if(sUP[i] == 0 && mUP[i] == 0)
{
Level[i] ++;
SetPlayerScore(i, GetPlayerScore(i) + 1);
format(String, sizeof(String), "| UP | Parabens %s voce conquistou +1 level ( %d )", PlayerName(i), GetPlayerScore(i));
SendClientMessage(i, 0x00FF00FF, String);
if(VIP[i] > 0)
{
if(SaldoBancario[i] > -999999 && TIPOVIP[i] == 0)
{
SendClientMessage(i, HexToInt(CORTAGVIP[i]), "~~~~~~~~~~~~~~~~~~~~~~~~~~~ Salario VIP ~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SendClientMessage(i, HexToInt(CORTAGVIP[i]), "~> {FFFFFF}Voce recebeu um salario VIP COMUM de $3000 e foi adicionado na sua conta bancaria");
SendClientMessage(i, HexToInt(CORTAGVIP[i]), "~~~~~~~~~~~~~~~~~~~~~~~~~~~ Salario VIP ~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SaldoBancario[i] += 3000;
}
else if(SaldoBancario[i] > -999999 && TIPOVIP[i] == 1)
{
SendClientMessage(i, HexToInt(CORTAGVIP[i]), "~~~~~~~~~~~~~~~~~~~~~~~~~~~ Salario VIP ~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SendClientMessage(i, HexToInt(CORTAGVIP[i]), "~> {FFFFFF}Voce recebeu um salario VIP GOLD de $5000 e foi adicionado na sua conta bancaria");
SendClientMessage(i, HexToInt(CORTAGVIP[i]), "~~~~~~~~~~~~~~~~~~~~~~~~~~~ Salario VIP ~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SaldoBancario[i] += 5000;
}
else if(SaldoBancario[i] > -999999 && TIPOVIP[i] == 2)
{
SendClientMessage(i, HexToInt(CORTAGVIP[i]), "~~~~~~~~~~~~~~~~~~~~~~~~~~~ Salario VIP ~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SendClientMessage(i, HexToInt(CORTAGVIP[i]), "~> {FFFFFF}Voce recebeu um salario VIP DIAMANTE de $10000 e foi adicionado na sua conta bancaria");
SendClientMessage(i, HexToInt(CORTAGVIP[i]), "~~~~~~~~~~~~~~~~~~~~~~~~~~~ Salario VIP ~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SaldoBancario[i] += 10000;
}
}
if(GetPlayerScore(i) == 20)
{
if(NivelAdmin[i] == 0 && VIP[i] == 0)
{
VIP[i] = ConvertDays(5);
SendClientMessage(i, 0x00FF00FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~ Recompensa ~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "~> {FFFFFF}Parabens {1E90FF}%s[%d]{FFFFFF}, voce atingiu o level 20 e recebeu 5 dias de VIP!", PlayerName(i), i);
SendClientMessage(i, 0x00FF00FF, String);
SendClientMessage(i, 0x00FF00FF, "~> {FFFFFF}Para ver seus comandos digite /ComandosVip. Aproveite!");
SendClientMessage(i, 0x00FF00FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~ Recompensa ~~~~~~~~~~~~~~~~~~~~~~~~~~~");
PlayerPlaySound(i, 1137,0.0,0.0,0.0);
format(CORTAGVIP[i], 11, "0xFFFFFFFF");
}
}
GameTextForPlayer(i, "~w~+UP", 2000, 6);
PlayerPlaySound(i,1139,0.0,0.0,0.0);
if(PegouMercadoria[i] == 1)
{
SendClientMessage(i, -1, "| INFO | Voce perdeu sua mercadoria de Bayside");
for(new m; m < GetPlayerVoltas(i); m++)
{
if(SlotMochila[i][m] == 10)
{
SlotMochila[i][m] = 0;
QuantidadeSlotMochila[i][m] = 0;
}
}
}
PegouMercadoria[i] = 0;
RecebeuSalario[i] = 0;
}
if(sUP[i] < 0)
{
mUP[i] --;
sUP[i] = 59;
if(mUP[i] < 0)
{
if(VIP[i] > 0 && TIPOVIP[i] == 0)
{
mUP[i] = 49;
}
else if(VIP[i] > 0 && TIPOVIP[i] == 1)
{
mUP[i] = 39;
}
else if(VIP[i] > 0 && TIPOVIP[i] == 2)
{
mUP[i] = 29;
}
else
{
mUP[i] = 59;
}
}
}
new Str[23]; format(Str, sizeof(Str), "+~b~~h~~h~UP_~w~%02d:%02d", mUP[i], sUP[i]);
PlayerTextDrawSetString(i, StatusP[i][0], Str);
}
else
{
new Str[23]; format(Str, sizeof(Str), "+~b~~h~~h~UP_~w~PAUSADO");
PlayerTextDrawSetString(i, StatusP[i][0], Str);
}
SetPlayerProgressBarValue(i, barfome[i], FOME[i]);
SetPlayerProgressBarValue(i, barsede[i], SEDE[i]);
SetPlayerProgressBarValue(i, barsono[i], SONO[i]);
ShowPlayerProgressBar(i, barfome[i]);
ShowPlayerProgressBar(i, barsede[i]);
ShowPlayerProgressBar(i, barsono[i]);
if(InPedagioSP[i] > 0 && InPedagioSP[i] < 9)
{
InPedagioSP[i] ++;
if(InPedagioSP[i] == 9)
{
InPedagioSP[i] = 0;
}
}
else
{
for(new p; p < 20; p++)
{
if(IsPlayerInRangeOfPoint(i, PosPedagio[p][3], PosPedagio[p][0], PosPedagio[p][1], PosPedagio[p][2]) && GetPlayerState(i) == PLAYER_STATE_DRIVER)
{
if(SemParar[i] == 1)
{
new idpedagio = floatround(PosPedagio[p][4], floatround_round), Float:P[3];
if(IsValidDynamicObject(pedagio[idpedagio]) && !IsDynamicObjectMoving(pedagio[idpedagio]))
{
GetDynamicObjectRot(pedagio[idpedagio], P[0], P[1], P[2]);
if(P[1] == 90.0 || P[1] == -90.0)
{
InPedagioSP[i] = 1;
SendClientMessage(i, COR_BRANCO, "| PEDAGIO | Sem Parar ativado, passagem liberada! Boa Viagem!");
MoveDynamicObject(pedagio[idpedagio], PosOriginalPedagio[idpedagio][0], PosOriginalPedagio[idpedagio][1], PosOriginalPedagio[idpedagio][2]-0.2, 0.1, PosOriginalPedagio[idpedagio][3], PosOriginalPedagio[idpedagio][4]+85.0, PosOriginalPedagio[idpedagio][5]);
SetTimerEx("FecharPedagio", 6000, false, "ii", pedagio[idpedagio], idpedagio);
}
}
}
else
{
if(InPedagioSP[i] == 0)
{
InPedagioSP[i] = 3;
GameTextForPlayer(i, "~g~~h~PEDAGIO ~w~/PAGARPEDAGIO", 2000, 3);
}
}
break;
}
}
}
if(GetPlayerMoney(i) != Money[i])
{
if(Money[i] <= GetPlayerMoney(i) && (GetPlayerMoney(i) - Money[i]) >= 10)
{
new Strm[11]; format(Strm, sizeof(Strm), "~r~$%d", GetPlayerMoney(i) - Money[i]); GameTextForPlayer(i, Strm, 3000, 1);
}
else if(Money[i] > GetPlayerMoney(i) && (Money[i] - GetPlayerMoney(i)) >= 10)
{
new Strm[11]; format(Strm, sizeof(Strm), "~g~$%d", Money[i] - GetPlayerMoney(i)); GameTextForPlayer(i, Strm, 3000, 1);
}
ResetPlayerMoney(i);
GivePlayerMoney(i, Money[i]);
}
if(SegundosMorte[i] > 0)
{
SegundosMorte[i] --;
ApplyAnimation(i, "CRACK", "CRCKIDLE4", 4.1, 1, 0, 0, 0, 0, 1);
new AparacerSangue = random(3);
if(AparacerSangue == 1)
{
new Float:XP, Float:YP, Float:ZP;
GetPlayerPos(i, XP, YP, ZP);
if(SangueObjeto[i] > -1)
{
DestroyObject(SangueObjeto[i]);
}
SangueObjeto[i] = CreateObject(18668, XP, YP, ZP-3.5, 0.0, 0.0, 0.0);
}
TextDrawShowForPlayer(i, TextConnect[2]);
new StrM[30]; format(StrM, sizeof(StrM), "~b~Resistencia: ~w~%02d:%02d", MinutosMorte[i], SegundosMorte[i]);
MsgAviso(i, 2, StrM);
if(SegundosMorte[i] <= 0)
{
if(MinutosMorte[i] > 0)
{
MinutosMorte[i] --;
SegundosMorte[i] = 60;
}
else
{
SendClientMessage(i, 0x3CB371FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Hospital ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
SendClientMessage(i, 0x3CB371FF, "{FFFFFF}~> Voce nao resistiu ao ferimento e foi levado para um hospital mais proximo");
if(PlanoSaude[i] <= 0)
{
format(String, sizeof(String), "{FFFFFF}~> Suas despesas teve um custo de {088A08}$%d{FFFFFF}, o valor foi descontado da conta bancaria", GetPlayerScore(i) * 50);
SendClientMessage(i, 0x3CB371FF, String);
SendClientMessage(i, 0x3CB371FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Hospital ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
if(SaldoBancario[i] > -999999)
{
SaldoBancario[i] -= GetPlayerScore(i) * 50;
}
}
else
{
PlanoSaude[i] --;
format(String, sizeof(String), "{FFFFFF}~> Seu plano de saude pagou todas suas {088A08}despesas{FFFFFF}, seu contrato agora esta em %d / 10", PlanoSaude[i]);
SendClientMessage(i, 0x3CB371FF, String);
SendClientMessage(i, 0x3CB371FF, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Hospital ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
TogglePlayerControllable(i, 0);
XMorte[i] = -1; YMorte[i] = -1; ZMorte[i] = -1;
new Random = random(sizeof(RandomHosp));
SetPlayerPos(i, RandomHosp[Random][0], RandomHosp[Random][1], RandomHosp[Random][2]);
SetPlayerFacingAngle(i, RandomHosp[Random][3]);
SetPlayerInterior(i, 2);
SetCameraBehindPlayer(i);
SetTimerEx("CarregarInterior", 3000, false, "i", i);
if(SEDE[i] <= 0)
{
SEDE[i] = 759;
}
if(FOME[i] <= 0)
{
FOME[i] = 831;
}
SetPlayerHealth(i, 100.0);
TextDrawHideForPlayer(i, TextConnect[i]);
}
}
}
if(SegundosPreso[i] > 0)
{
SegundosPreso[i] --;
if(SegundosPreso[i] <= 0 && MinutosPreso[i] > 0)
{
SegundosPreso[i] = 59;
MinutosPreso[i] --;
}
else if(SegundosPreso[i] <= 0 && MinutosPreso[i] <= 0 && HorasPreso[i] > 0)
{
SegundosPreso[i] = 59;
MinutosPreso[i] = 59;
HorasPreso[i] --;
}
else if(SegundosPreso[i] <= 0 && MinutosPreso[i] <= 0 && HorasPreso[i] <= 0)
{
if(EntrouDP[i] < 8)
{
SetPlayerPos(i, 246.3471,70.8166,1003.6406);
SetPlayerFacingAngle(i, 182.0656);
SetPlayerInterior(i, 6);
SetPlayerVirtualWorld(i, 0);
}
else
{
SetPlayerPos(i, 1350.3654,-1715.1946,1170.0687);
SetPlayerFacingAngle(i, 288.8180);
SetPlayerInterior(i, 1);
SetPlayerVirtualWorld(i, 1);
TogglePlayerControllable(i, 0);
SetTimerEx("CarregarInterior", 3000, false, "i", i);
}
SetCameraBehindPlayer(i);
SetPlayerHealth(i, 100);
PlayerTextDrawHide(i, TextPresoP[i]);
TextDrawHideForPlayer(i, TextPreso);
SegundosServicos[i] = 0;
GameTextForPlayer(i, "~w~Solto!", 1500, 0);
AttTag(i);
SendClientMessage(i, -1, "| INFO | Voce foi solto(a) por cumprir sua pena!");
}
new StrPreso[35]; format(StrPreso, sizeof(StrPreso), "~g~~h~PRESO: ~w~%02d:%02d:%02d", HorasPreso[i], MinutosPreso[i], SegundosPreso[i]);
PlayerTextDrawSetString(i, TextPresoP[i], StrPreso);
}
if(SegundosContinuar[i] > 0)
{
SegundosContinuar[i] --;
if(SegundosContinuar[i] == 0)
{
SendClientMessage(i, -1, "| INFO | Seu tempo para usar o comando /Continuar expirou!");
}
}
if(MUV[i] > 0)
{
MUV[i] --;
if(MUV[i] == 0)
{
SendClientMessage(i, -1, "| INFO | Voce foi liberado para usar o VOIP, faca bom uso dele para nao ser punido(a) novamente!");
}
}
if(SegundosPerseguidoCorp[i] > 0)
{
SegundosPerseguidoCorp[i] --;
if(SegundosPerseguidoCorp[i] == 0)
{
format(String, sizeof(String), "| PERSEGUICAO | O(A) Jogador(a) %s[%d] nao esta mais sendo perseguido(a) pela policia", PlayerName(i), i);
SendClientMessageToAll(0x1E90FFFF, String);
TimerAbordo[i] = -1;
}
}
if(SegundosPerseguidoOrg[i] > 0)
{
SegundosPerseguidoOrg[i] --;
if(SegundosPerseguidoOrg[i] == 0)
{
TimerAbordoAb[i] = -1;
SendClientMessage(i, -1, "| INFO | Voce nao esta mais sendo perseguido pelos assaltantes");
}
}
if(PlayerContagemCorrida[i] > 0)
{
PlayerContagemCorrida[i] --;
new StrC[30]; format(StrC, sizeof(StrC), "~y~] ~r~LARGADA: ~w~%d ~y~]", PlayerContagemCorrida[i]);
GameTextForPlayer(i, StrC, 1500, 3);
if(PlayerContagemCorrida[i] == 0)
{
TogglePlayerControllable(i, 1);
GameTextForPlayer(i, "~w~[[[ ~g~~h~GO! ~w~[[[", 1500, 3);
PlayerPontoCorrida[i] = 0;
PlayerPlaySound(i, 3200, 0, 0, 0);
}
else
{
PlayerPlaySound(i, 1056, 0.0, 0.0, 10.0);
}
}
if(ChamouPolicia[i] > 0)
{
ChamouPolicia[i] --;
}
if(PediuTaxi[i] > 0)
{
PediuTaxi[i] --;
}
if(PediuMecanico[i] > 0)
{
PediuMecanico[i] --;
}
if(SegundosServicos[i] > 0)
{
SegundosServicos[i] --;
if(SegundosServicos[i] == 0)
{
SendClientMessage(i, 0xDCDCDCFF, "| INFO | Voce demorou muito tempo para aceitar/recusar os servicos do advogado");
}
}
if(GetPlayerAmmo(i) > 999)
{
SetPlayerAmmo(i, GetPlayerWeapon(i), 999);
}
else if(GetPlayerWeapon(i) > 0 && GetPlayerAmmo(i) < 0)
{
SetPlayerAmmo(i, GetPlayerWeapon(i), 0);
}
if(Carregado[i] == true)
{
if(PROF[i] == PETROLEIRO)
{
if(GetVehicleModel(GetPlayerVehicleID(i)) == 514)
{
new strg[256], Float:fDistance = GetPlayerDistanceFromPoint(i, XD[i], YD[i], ZD[i]);
format(strg, sizeof(strg), "~b~~h~Transportando_para:_~w~%s~n~~b~~h~Distancia:_~w~%0.2fM~n~~b~~h~Frete:_~g~$%d_~w~+_~g~$%d_~w~Bonus~n~~b~~h~Comboio:_~w~%d_pessoas~n~~b~~h~Total_a_receber:_~g~$%d", LocalCarga[i], fDistance, Frete[i], BonusFrete[i], ComboioPetroleiroList[ComboioPetroleiro[i]], Frete[i] + BonusFrete[i] + (ComboioPetroleiroList[ComboioPetroleiro[i]] * 200));
PlayerTextDrawSetString(i, TextCargaP[i][0], strg);
}
}
else if(PROF[i] == CAMINHONEIRO)
{
if(GetVehicleModel(GetPlayerVehicleID(i)) == 456)
{
new strg[256], Float:fDistance = GetPlayerDistanceFromPoint(i, XD[i], YD[i], ZD[i]);
format(strg, sizeof(strg), "~b~~h~Transportando_para:_~w~%s~n~~b~~h~Distancia:_~w~%0.2fM~n~~b~~h~Frete:_~g~$%d_~w~+_~g~$%d_~w~Bonus~n~~b~~h~Comboio:_~w~%d_pessoas~n~~b~~h~Total_a_receber:_~g~$%d", LocalCarga[i], fDistance, Frete[i], BonusFrete[i], ComboioCaminhoneiroList[ComboioCaminhoneiro[i]], Frete[i] + BonusFrete[i] + (ComboioCaminhoneiroList[ComboioCaminhoneiro[i]] * 200));
PlayerTextDrawSetString(i, TextCargaP[i][0], strg);
}
}
else if(PROF[i] == MINERADOR)
{
if(GetVehicleModel(GetPlayerVehicleID(i)) == 515)
{
new strg[256], Float:fDistance = GetPlayerDistanceFromPoint(i, XD[i], YD[i], ZD[i]);
format(strg, sizeof(strg), "~b~~h~Transportando_para:_~w~%s~n~~b~~h~Distancia:_~w~%0.2fM~n~~b~~h~Frete:_~g~$%d_~w~+_~g~$%d_~w~Bonus~n~~b~~h~Comboio:_~w~%d_pessoas~n~~b~~h~Total_a_receber:_~g~$%d", LocalCarga[i], fDistance, Frete[i], BonusFrete[i], ComboioMineradorList[ComboioMinerador[i]], Frete[i] + BonusFrete[i] + (ComboioMineradorList[ComboioMinerador[i]] * 200));
PlayerTextDrawSetString(i, TextCargaP[i][0], strg);
}
}
else if(PROF[i] == CARROFORTE)
{
if(GetVehicleModel(GetPlayerVehicleID(i)) == 428)
{
new strg[256], Float:fDistance = GetPlayerDistanceFromPoint(i, XD[i], YD[i], ZD[i]);
format(strg, sizeof(strg), "~b~~h~Transportando_para:_~w~%s~n~~b~~h~Distancia:_~w~%0.2fM~n~~b~~h~Frete:_~g~$%d_~w~+_~g~$%d_~w~Bonus~n~~b~~h~Comboio:_~w~%d_pessoas~n~~b~~h~Total_a_receber:_~g~$%d", LocalCarga[i], fDistance, Frete[i], BonusFrete[i], ComboioCFList[ComboioCF[i]], Frete[i] + BonusFrete[i] + (ComboioCFList[ComboioCF[i]] * 200));
PlayerTextDrawSetString(i, TextCargaP[i][0], strg);
}
}
else
{
Carregado[i] = false;
PlayerTextDrawHide(i, TextCargaP[i][0]);
PlayerTextDrawHide(i, TextCargaP[i][1]);
TextDrawHideForPlayer(i, TextCarga);
DisablePlayerRaceCheckpoint(i);
if(ComboioPetroleiro[i] > -1)
{
ComboioPetroleiroList[ComboioPetroleiro[i]] --;
ComboioPetroleiro[i] = -1;
}
else if(ComboioCaminhoneiro[i] > -1)
{
ComboioCaminhoneiroList[ComboioCaminhoneiro[i]] --;
ComboioCaminhoneiro[i] = -1;
}
else if(ComboioMinerador[i] > -1)
{
ComboioMineradorList[ComboioMinerador[i]] --;
ComboioMinerador[i] = -1;
}
else if(ComboioCF[i] > -1)
{
ComboioCFList[ComboioCF[i]] --;
ComboioCF[i] = -1;
}
}
}
if(SegundosVoltarVeiculo[i] > 0)
{
SegundosVoltarVeiculo[i] --;
new strg[3]; format(strg, sizeof(strg), "%d", SegundosVoltarVeiculo[i]);
GameTextForPlayer(i, strg, 2000, 6);
if(SegundosVoltarVeiculo[i] <= 0)
{
if(RotaBus[i] > -1)
{
SendClientMessage(i, GetPlayerColor(i), "| INFO | Voce ficou muito tempo fora do Onibus e sua viagem foi cancelada!");
RotaBus[i] = -1;
}
else if(CargaTrem[i] > -1)
{
SendClientMessage(i, GetPlayerColor(i), "| INFO | Voce ficou muito tempo fora do trem e seu carregamento foi cancelado!");
CargaTrem[i] = -1;
DisablePlayerRaceCheckpoint(i);
}
else if(CargaPiloto[i] > 0)
{
SendClientMessage(i, GetPlayerColor(i), "| INFO | Voce ficou muito tempo fora do aviao e seu carregamento foi cancelado!");
CargaPiloto[i] = 0;
DisablePlayerRaceCheckpoint(i);
}
else if(CargaMoto[i] > -1)
{
SendClientMessage(i, GetPlayerColor(i), "| INFO | Voce ficou muito tempo fora da moto e seu carregamento foi cancelado!");
CargaMoto[i] = -1;
for(new c; c < 3; c++)
{
if(CheckC[i][c] > -1)
{
DestroyDynamicCP(CheckC[i][c]);
CheckC[i][c] = -1;
}
if(MapC[i][c] > -1)
{
DestroyDynamicMapIcon(MapC[i][c]);
MapC[i][c] = -1;
}
}
}
else
{
SendClientMessage(i, GetPlayerColor(i), "| INFO | Voce ficou muito tempo fora do veiculo carregado e sua carga foi cancelada!");
}
if(Carregado[i] == true)
{
Carregado[i] = false;
PlayerTextDrawHide(i, TextCargaP[i][0]);
PlayerTextDrawHide(i, TextCargaP[i][1]);
TextDrawHideForPlayer(i, TextCarga);
DisablePlayerRaceCheckpoint(i);
if(ComboioPetroleiro[i] > -1)
{
ComboioPetroleiroList[ComboioPetroleiro[i]] --;
ComboioPetroleiro[i] = -1;
}
else if(ComboioCaminhoneiro[i] > -1)
{
ComboioCaminhoneiroList[ComboioCaminhoneiro[i]] --;
ComboioCaminhoneiro[i] = -1;
}
else if(ComboioMinerador[i] > -1)
{
ComboioMineradorList[ComboioMinerador[i]] --;
ComboioMinerador[i] = -1;
}
else if(ComboioCF[i] > -1)
{
ComboioCFList[ComboioCF[i]] --;
ComboioCF[i] = -1;
}
}
}
}
if(SegundosImobiliaria[i] > 0)
{
SegundosImobiliaria[i] --;
new StrMsg[50]; format(StrMsg, sizeof(StrMsg), "TEMPO_RESTANTE:_00:%02d", SegundosImobiliaria[i]);
PlayerTextDrawSetString(i, TextImobiliaria[i][10], StrMsg);
if(SegundosImobiliaria[i] == 0)
{
SetPlayerPos(i, 1666.9398,-1345.3486,17.4959);
SetPlayerFacingAngle(i, 47.7825);
SetCameraBehindPlayer(i);
SetPlayerInterior(i, 11);
SetPlayerVirtualWorld(i, 1);
SetTimerEx("CarregarInterior", 3000, false, "i", i);
TogglePlayerControllable(i, 0);
for(new t; t < 11; t++)
{
PlayerTextDrawHide(i, TextImobiliaria[i][t]);
}
}
}
if(BlokPlayerSequestro[i] > 0)
{
BlokPlayerSequestro[i] --;
if(BlokPlayerSequestro[i] == 0)
{
SendClientMessage(i, -1, "| INFO | Seu comando para sequestrar foi desbloqueado");
}
}
if(BlockPlayerLocalizar[i] > 0)
{
BlockPlayerLocalizar[i] --;
if(BlockPlayerLocalizar[i] == 0)
{
SendClientMessage(i, -1, "| INFO | O seu comando de Localizar foi liberado novamente.");
}
}
if(BlockAssaltouCaixa[i] > -1)
{
BlockAssaltouCaixa[i] --;
if(BlockAssaltouCaixa[i] == -1)
{
SendClientMessage(i, -1, "| INFO | Seu comando para assaltar Caixa Eletronico foi desbloqueado");
}
}
if(BlockAssaltouBanco[i] < 0)
{
BlockAssaltouBanco[i] ++;
}
if(BlockAssaltoCX[i] > -1)
{
BlockAssaltoCX[i] --;
if(BlockAssaltoCX[i] == -1)
{
SendClientMessage(i, -1, "| INFO | Seu comando para assaltar Carro Forte foi desbloqueado");
}
}
if(BlockPlayerAssalto[i] > -1)
{
BlockPlayerAssalto[i] --;
if(BlockPlayerAssalto[i] == -1)
{
SendClientMessage(i, -1, "| INFO | Seu comando para assaltar um jogador foi desbloqueado");
}
}
if(SegundosSequestrado[i] > -1)
{
SegundosSequestrado[i] --;
if(SegundosSequestrado[i] < 2)
{
SendClientMessage(i, COR_SEQUESTRADOR, "| SEQUESTRO | Voce foi liberado(a)");
SegundosSequestrado[i] = -1;
TogglePlayerControllable(i, 1);
ClearAnimations(i, 1);
SetPlayerSpecialAction(i, SPECIAL_ACTION_NONE);
if(IsPlayerInAnyVehicle(i))
{
RemovePlayerFromVehicle(i);
}
}
}
if(SegundosAmarrado[i] > -1)
{
SegundosAmarrado[i] --;
if(SegundosAmarrado[i] < 2)
{
SendClientMessage(i, COR_SEQUESTRADOR, "| SEQUESTRO | Voce foi liberado(a)");
SegundosAmarrado[i] = -1;
TogglePlayerControllable(i, 1);
ClearAnimations(i, 1);
SetPlayerSpecialAction(i, SPECIAL_ACTION_NONE);
if(IsPlayerInAnyVehicle(i))
{
RemovePlayerFromVehicle(i);
}
}
}
if(Algemado[i] > 0)
{
Algemado[i] --;
if(GetPlayerSpeed(i) > 0)
{
TogglePlayerControllable(i, 0);
}
if(Algemado[i] == 0)
{
SendClientMessage(i, 0x1E90FFFF, "| ALGEMA | Voce foi desalgemado automaticamente");
SetPlayerSpecialAction(i, SPECIAL_ACTION_NONE);
RemovePlayerAttachedObject(i, 7);
TogglePlayerControllable(i, 1);
}
}
if(SegundosCone[i] > 0)
{
SegundosCone[i] --;
if(SegundosCone[i] <= 0)
{
for(new c; c < 5; c++)
{
if(Cone[i][c] > -1)
{
DestroyDynamicObject(Cone[i][c]);
Cone[i][c] = -1;
}
}
if(Barreira[i] == -1)
{
if(GzBlitz[i] > -1)
{
GangZoneDestroy(GzBlitz[i]);
GzBlitz[i] = -1;
}
}
}
}
if(SegundosBarreira[i] > 0)
{
SegundosBarreira[i] --;
if(SegundosBarreira[i] <= 0)
{
if(Barreira[i] > -1)
{
DestroyDynamicObject(Barreira[i]);
Barreira[i] = -1;
DestroyDynamic3DTextLabel(TextoBarreira[i]);
TextoBarreira[i] = CreateDynamic3DTextLabel(".", -1, 11.11,22.22,-999.123, 10.0);
}
if(GzBlitz[i] > -1)
{
GangZoneDestroy(GzBlitz[i]);
GzBlitz[i] = -1;
}
}
}
if(SegundosTapete[i] > 0)
{
SegundosTapete[i] --;
if(SegundosTapete[i] <= 0)
{
if(XTapete[i] > -1 || YTapete[i] > -1 || ZTapete[i] > -1)
{
DeleteClosestStrip(XTapete[i], YTapete[i], ZTapete[i]);
XTapete[i] = -1; YTapete[i] = -1; ZTapete[i] = -1;
DestroyDynamic3DTextLabel(TextoTapete[i]);
TextoTapete[i] = CreateDynamic3DTextLabel(".", -1, 11.11,22.22,-999.123, 10.0);
}
}
}
if(GzBlitz[i] > -1)
{
GangZoneFlashForAll(GzBlitz[i], 0x013ADF99);
}
if(SegundosPropostaArma[i] > -1)
{
SegundosPropostaArma[i] ++;
if(SegundosPropostaArma[i] == 3)
{
SendClientMessage(i, 0xE0FFFFFF, "| INFO | Para aceitar a arma digite /Aceitar ou /Recusar para recusar");
}
else if(SegundosPropostaArma[i] == 11)
{
SendClientMessage(i, 0xE0FFFFFF, "| INFO | Para aceitar a arma digite /Aceitar ou /Recusar para recusar");
}
else if(SegundosPropostaArma[i] == 22)
{
SendClientMessage(i, 0xE0FFFFFF, "| INFO | Para aceitar a arma digite /Aceitar ou /Recusar para recusar");
}
else if(SegundosPropostaArma[i] == 33)
{
ArmaOferecida[i] = -1;
MunicaoArmaOferecida[i] = -1;
ValorArmaOferecida[i] = -1;
TraficanteDoCliente[i] = -1;
SegundosPropostaArma[i] = -1;
SendClientMessage(i, 0xDCDCDCFF, "| INFO | Voce demorou muito tempo para aceitar/recusar a arma");
}
}
if(SegundosReparo[i] > 0)
{
SegundosReparo[i] --;
if(SegundosReparo[i] == 10)
{
SendClientMessage(i, 0xE0FFFFFF, "| INFO | Para aceitar o reparo digite /Aceitar ou /Recusar para recusar");
}
else if(SegundosReparo[i] == 0)
{
SendClientMessage(i, 0xDCDCDCFF, "| INFO | Voce demorou muito tempo para aceitar/recusar o reparo");
OfereceuReparo[i] = -1;
ValorReparo[i] = 0;
}
}
if(OfereceuMaconha[i] > -1)
{
OfereceuMaconha[i] ++;
if(OfereceuMaconha[i] == 2)
{
SendClientMessage(i, 0xE0FFFFFF, "| INFO | Para aceitar o(s) cigarro(s) de maconha digite /Aceitar ou /Recusar para recusar");
}
if(OfereceuMaconha[i] == 10)
{
SendClientMessage(i, 0xE0FFFFFF, "| INFO | Para aceitar o(s) cigarro(s) de maconha digite /Aceitar ou /Recusar para recusar");
}
if(OfereceuMaconha[i] == 20)
{
SendClientMessage(i, 0xE0FFFFFF, "| INFO | Para aceitar o(s) cigarro(s) de maconha digite /Aceitar ou /Recusar para recusar");
}
else if(OfereceuMaconha[i] > 30)
{
OfereceuMaconha[i] = -1;
QuantidadeMaconhaOferecida[i] = 0;
ValorMaconhaOferecido[i] = 0;
VendedorDaMaconha[i] = -1;
SendClientMessage(i, 0xDCDCDCFF, "| INFO | Voce demorou muito tempo para aceitar/recusar o(s) cigarro(a) de maconha");
}
}
if(TempoProduzindoMaterial[i] > -1)
{
TempoProduzindoMaterial[i] += random(5);
new strp[100]; format(strp, sizeof(strp), "{CD853F}Produzindo Materiais: %d / 50\n{FFFFFF}Jogador(a) Trabalhando: {CD853F}%s[%d]", TempoProduzindoMaterial[i], PlayerName(i), i);
UpdateDynamic3DTextLabelText(pMaterial[i], -1, strp);
if(TempoProduzindoMaterial[i] >= 50)
{
if(IsPlayerInRangeOfPoint(i, 3.0, XMaterial[i], YMaterial[i], ZMaterial[i]))
{
new bool:TemSlot = false;
for(new m; m < GetPlayerVoltas(i); m++)
{
if(SlotMochila[i][m] == 0)
{
TemSlot = true;
SlotMochila[i][m] = MATERIAISPRONTO;
QuantidadeSlotMochila[i][m] = 10;
SendClientMessage(i, COR_PRODUTORMATERIAIS, "| INFO | Voce produziu +10 material");
ClearAnimations(i, 1);
break;
}
}
if(TemSlot == false)
{
ClearAnimations(i, 1);
SendClientMessage(i, COR_ERRO, "| ERRO | Seu inventario esta cheio");
}
}
else
{
SendClientMessage(i, COR_ERRO, "| ERRO | Voce nao estava proximo da sua producao de materias e ela foi cancelada");
}
TempoProduzindoMaterial[i] = -1;
DestroyDynamicObject(Material[i]);
DestroyDynamicObject(Materiall[i]);
Material[i] = -1;
Materiall[i] = -1;
DestroyDynamic3DTextLabel(pMaterial[i]);
pMaterial[i] = CreateDynamic3DTextLabel(".", -1, 11.11,22.22,-999.123, 2.0);
}
}
if(PassouRadar[i] > 0)
{
PassouRadar[i] --;
}
if(Localizando[i] > -1 || InviteLocalizacao[i] > -1)
{
PlayerTextDrawShow(i, MsgText[i]);
}
else if(SegundosAviso[i] > 0)
{
SegundosAviso[i] --;
if(SegundosAviso[i] <= 0)
{
PlayerTextDrawHide(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 100.0, 2163.6772,-1010.0628,62.7966) && DonoFavela[0] < 30)
{
new StringMorro[90]; format(StringMorro, sizeof(StringMorro), "FAVELA DOMINADA PELA ORGANIZACAO ~r~%s ~w~- %02d:%02d", gNome[DonoFavela[0]], MinMateriaisFav[0], SegMateriaisFav[0]);
PlayerTextDrawSetString(i, MsgText[i], StringMorro);
PlayerTextDrawShow(i, MsgText[i]);
}
else if(IsPlayerInRangeOfPoint(i, 50.0, -2565.8472,855.6293,54.6728) && DonoFavela[1] < 30)
{
new StringMorro[90]; format(StringMorro, sizeof(StringMorro), "~w~FAVELA DOMINADA PELA ORGANIZACAO ~r~%s ~w~- %02d:%02d", gNome[DonoFavela[1]], MinMateriaisFav[1], SegMateriaisFav[1]);
PlayerTextDrawSetString(i, MsgText[i], StringMorro);
PlayerTextDrawShow(i, MsgText[i]);
}
else if(IsPlayerInRangeOfPoint(i, 82.0, 2818.5256,1149.0438,10.8895) && DonoFavela[2] < 30)
{
new StringMorro[90]; format(StringMorro, sizeof(StringMorro), "~w~FAVELA DOMINADA PELA ORGANIZACAO ~r~%s ~w~- %02d:%02d", gNome[DonoFavela[1]], MinMateriaisFav[1], SegMateriaisFav[1]);
PlayerTextDrawSetString(i, MsgText[i], StringMorro);
PlayerTextDrawShow(i, MsgText[i]);
}
else if(IsPlayerInRangeOfPoint(i, 50.0, 2163.6772,-1010.0628,62.7966) || IsPlayerInRangeOfPoint(i, 50.0, 2200.3455,-980.4317,62.6038))
{
new StringMorro[90]; format(StringMorro, sizeof(StringMorro), "~r~MORRO ~w~EXISTEM ~r~%d ~w~PLANTAS DE MACONHA E ~r~%d ~w~MATERIAIS", DOF2_GetInt("Cigarros.ini", "Quantidade"), DOF2_GetInt("Materiais.ini", "Quantidade"));
PlayerTextDrawSetString(i, MsgText[i], StringMorro);
PlayerTextDrawShow(i, MsgText[i]);
}
else if(IsPlayerInRangeOfPoint(i, 20.0, -2432.2068,2330.3176,4.8359))
{
new StringMorro[90]; format(StringMorro, sizeof(StringMorro), "~g~MERCADORIAS BAYSIDE ~w~EXISTEM ~g~~h~%d ~w~MERCADORIAS", DOF2_GetInt("Mercadorias.ini", "Quantidade"));
PlayerTextDrawSetString(i, MsgText[i], StringMorro);
PlayerTextDrawShow(i, MsgText[i]);
}
else if(IsPlayerInRangeOfPoint(i, 150.0, 2447.4167,-1970.0680,13.5469))
{
if(PROF[i] == PRODUTORMATERIAIS || PROF[i] == CHEFAO || ORG[i] >= 0)
{
PlayerTextDrawSetString(i, MsgText[i], "~r~~h~AREA DE PRODUCAO DE MATERIAIS");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 80.0, -1038.2094,-1648.4512,77.8549))
{
if(PROF[i] == FAZENDEIRO || PROF[i] == CHEFAO || ORG[i] >= 0)
{
PlayerTextDrawSetString(i, MsgText[i], "~w~FAZENDA DE ~y~~h~DROGAS");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 15.0, 2063.2549,-2079.8801,13.5469))
{
if(PROF[i] == GARI)
{
PlayerTextDrawSetString(i, MsgText[i], "~y~LIXAO DE Sao Paulo");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 20.0, 227.5544,1410.8477,10.5859))
{
if(PROF[i] == PETROLEIRO)
{
PlayerTextDrawSetString(i, MsgText[i], "~w~CARREGAMENTO DE ~b~~h~PETROLEO");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 20.0, 135.0934,-254.2857,1.5781))
{
if(PROF[i] == CAMINHONEIRO)
{
PlayerTextDrawSetString(i, MsgText[i], "~w~CARREGAMENTO DE ~g~~h~MERCADORIAS");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 10.0, 377.2151,848.1732,19.8472))
{
if(PROF[i] == MINERADOR)
{
PlayerTextDrawSetString(i, MsgText[i], "~w~CARREGAMENTO DE ~p~~h~MINERIO");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 20.0, 658.4877,1264.9663,11.4642) || IsPlayerInRangeOfPoint(i, 20.0, 2663.2732,846.9420,6.7454) || IsPlayerInRangeOfPoint(i, 20.0, -2096.5745,208.7500,35.3123) || IsPlayerInRangeOfPoint(i, 20.0, 1257.2205,-1251.7765,14.2026))
{
if(PROF[i] == MINERADOR)
{
PlayerTextDrawSetString(i, MsgText[i], "~w~AREA DE DESCARREGAMENTO DE ~p~~h~MINERIO");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 50.0, 2843.6189,1290.2775,11.3906) || IsPlayerInRangeOfPoint(i, 35.0, 2832.6868,1347.8795,10.7576) || IsPlayerInRangeOfPoint(i, 30.0, 2796.3408,1277.0142,10.7500))
{
if(PROF[i] == MOTORISTABUS)
{
PlayerTextDrawSetString(i, MsgText[i], "~y~RODOVIARIA DE Bahia");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 50.0, 1767.8788,-1955.8844,13.5469))
{
if(PROF[i] == FERROVIARIA)
{
PlayerTextDrawSetString(i, MsgText[i], "~y~Estacao Unity");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 110.0, 2000.1315,-2545.0225,13.5469))
{
if(PROF[i] == PILOTO)
{
PlayerTextDrawSetString(i, MsgText[i], "~g~~h~AEROPORTO ~w~DE Sao Paulo - CARREGAMENTO");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 20.0, 1462.7467,-1026.9771,23.8281))
{
if(PROF[i] == CARROFORTE)
{
PlayerTextDrawSetString(i, MsgText[i], "~w~CARREGAMENTO DE ~g~MALOTES");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 20.0, -544.6993,-502.2955,25.5234))
{
if(PROF[i] == MOTOBOY)
{
PlayerTextDrawSetString(i, MsgText[i], "~w~CARREGAMENTO DE ~g~MERCADORIAS");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 30.0, -75.4844,-1570.5881,2.6107))
{
if(PROF[i] > -1)
{
PlayerTextDrawSetString(i, MsgText[i], "~y~PATIO ~w~DO DETRAN");
PlayerTextDrawShow(i, MsgText[i]);
}
}
else if(IsPlayerInRangeOfPoint(i, 50.0, -154.6521,141.0004,3.9754))
{
if(PROF[i] == LENHADOR)
{
new StringArv[70]; format(StringArv, sizeof(StringArv), "~g~Florestamento ~w~Ja foram derrubadas ~g~%d ~w~arvores", DOF2_GetInt("Arvores.ini", "Quantidade"));
PlayerTextDrawSetString(i, MsgText[i], StringArv);
PlayerTextDrawShow(i, MsgText[i]);
}
}
else
{
new bool:HideText;
for(new po; po < 38; po++)
{
if(IsPlayerInRangeOfPoint(i, AreasPosto[po][3], AreasPosto[po][0], AreasPosto[po][1], AreasPosto[po][2]))
{
new zone[MAX_ZONE_NAME], nomeposto[70]; GetPlayer2DZone(i, zone, MAX_ZONE_NAME);
format(nomeposto, sizeof(nomeposto), "~b~POSTO ~w~DE ~y~%s ~w~- ~g~~h~/ABASTECER", zone);
PlayerTextDrawSetString(i, MsgText[i], nomeposto);
PlayerTextDrawShow(i, MsgText[i]);
HideText = true;
break;
}
}
if(HideText == false)
{
PlayerTextDrawHide(i, MsgText[i]);
}
}
}
if(SegundosComecar[i] > 0)
{
SegundosComecar[i] --;
if(SegundosComecar[i] <= 0)
{
MsgAviso(i, 120, "~w~Siga_o_ponto_vermelho_marcado_no_mapa_para_comecar");
SetCameraBehindPlayer(i);
CheckPrimeiroPasso[i] = CreateDynamicCP(481.0389,-1771.5531,18.7958, 1.5, -1, -1, i, 1000.0);
}
}
}
new HoraRoYal, MinutoRoYal, SegundoRoYal;
gettime(HoraRoYal, MinutoRoYal, SegundoRoYal);
switch(HoraRoYal)
{
case 0: SetWorldTime(0);
case 1: SetWorldTime(0);
case 2: SetWorldTime(1);
case 3: SetWorldTime(2);
case 4: SetWorldTime(4);
case 5: SetWorldTime(5);
case 6: SetWorldTime(6);
case 7: SetWorldTime(7);
case 8: SetWorldTime(8);
case 9: SetWorldTime(9);
case 10: SetWorldTime(10);
case 11: SetWorldTime(11);
case 12: SetWorldTime(12);
case 13: SetWorldTime(13);
case 14: SetWorldTime(14);
case 15: SetWorldTime(15);
case 16: SetWorldTime(16);
case 17: SetWorldTime(20);
case 18: SetWorldTime(21);
case 19: SetWorldTime(22);
case 20: SetWorldTime(22);
case 21: SetWorldTime(23);
case 22: SetWorldTime(23);
case 23: SetWorldTime(23);
}
return 1;
}
forward CarregarArvore(playerid);
public CarregarArvore(playerid)
{
if(GetVehicleModel(GetPlayerVehicleID(playerid)) == 478 && GetPlayerState(playerid) == PLAYER_STATE_DRIVER)
{
DestroyDynamicCP(CheckArvore[playerid]);
DestroyDynamicObject(Arvore[playerid]);
CheckArvore[playerid] = -1;
TogglePlayerControllable(playerid, 1);
Arvore[playerid] = CreateDynamicObject(837, -999.0, -826.0, -739.0, 0.0, 0.0, 0.0);
AttachDynamicObjectToVehicle(Arvore[playerid], GetPlayerVehicleID(playerid), 0.0000, -0.5000, 0.8500, -101.0000, 60.0000, 150.0000);
Streamer_Update(playerid);
SetPlayerRaceCheckpoint(playerid, 2, -510.9023,-84.5538,62.1558, -510.9023,-84.5538,62.1558, 5.0);
SendClientMessage(playerid, GetPlayerColor(playerid), "| LENHADOR | Um checkpoint vermelho foi marcado no seu mapa, siga-o para entregar essa lenha");
}
else
{
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Voce nao estava no veiculo de lenhador e seu carregamento foi cancelado");
}
return 1;
}
forward Socorrer(playerid);
public Socorrer(playerid)
{
if(SegurandoMao[playerid] == KITMEDICO)
{
SegurandoMao[playerid] = 0; RemovePlayerAttachedObject(playerid, 5);
if(CheckSAMU[playerid] > -1)
{
DestroyDynamicCP(CheckSAMU[playerid]);
CheckSAMU[playerid] = -1;
}
new valor1 = MinutosMorte[Localizando[playerid]] * 600;
new valor2 = SegundosMorte[Localizando[playerid]] * 10;
new valortotal = valor1 + valor2;
if(valortotal > 4000)
{
valortotal = 4000;
}
if(MatouPlayer[playerid] == Localizando[playerid] || (gettime() - FoiSocorrido[Localizando[playerid]]) <= 600)
{
valortotal = 0;
}
Money[playerid] += valortotal;
format(String, sizeof(String), "| SAMU | Voce socorreu o(a) jogador(a) {FF69B4}%s[%d] {FFFFFF}e recebeu {228B22}$%d", PlayerName(Localizando[playerid]), Localizando[playerid], valortotal);
SendClientMessage(playerid, -1, String);
SegundosMorte[Localizando[playerid]] = 0; MinutosMorte[Localizando[playerid]] = 0;
if(SangueObjeto[Localizando[playerid]] > -1)
{
DestroyObject(SangueObjeto[Localizando[playerid]]);
SangueObjeto[Localizando[playerid]] = -1;
}
ApplyAnimation(Localizando[playerid], "CARRY", "crry_prtial", 2.0, 0, 0, 0, 0, 0, 1);
format(String, sizeof(String), "| SAMU | O(A) Socorrista do SAMU %s[%d] te socorreu a tempo e voce ja esta bem!", PlayerName(playerid), playerid);
SendClientMessage(Localizando[playerid], GetPlayerColor(playerid), String);
if(SEDE[Localizando[playerid]] <= 0)
{
SEDE[Localizando[playerid]] = 759;
}
if(FOME[Localizando[playerid]] <= 0)
{
FOME[Localizando[playerid]] = 831;
}
TextDrawHideForPlayer(Localizando[playerid], TextConnect[2]);
SetPlayerHealth(Localizando[playerid], 10.0);
FoiSocorrido[Localizando[playerid]] = gettime();
Localizando[playerid] = -1;
}
else
{
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Voce nao esta segurando um Kit Medico");
}
return 1;
}
forward ReparandoRadar(playerid);
public ReparandoRadar(playerid)
{
PassouRadar[playerid] = 5;
if(RadarQuebrado[IndoRadar[playerid]] == true)
{
format(String, sizeof(String), "{FF0000}RADAR\n{FFFFFF}Velocidade maxima permitida: \n{FFFF00}%dKm/h", VelocidadeRadar[IndoRadar[playerid]]);
UpdateDynamic3DTextLabelText(InfoRadar[IndoRadar[playerid]], -1, String);
RadarQuebrado[IndoRadar[playerid]] = false;
new Valor = 800 + random(801); Money[playerid] += Valor;
format(String, sizeof(String), "| RADAR | Voce reparou esse radar e recebeu {228B22}$%d", Valor);
SendClientMessage(playerid, -1, String);
GameTextForPlayer(playerid, "~g~RADAR REPARADO!", 2500, 4);
}
else
{
SendClientMessage(playerid, COR_ERRO, "| ERRO | Esse radar ja foi reparado, siga para o proximo");
}
TogglePlayerControllable(playerid, 1);
new r = random(20);
if(RadarQuebrado[r] == false)
{
RadarQuebrado[r] = true;
}
IndoRadar[playerid] = r;
format(String, sizeof(String), "{FF0000}RADAR QUEBRADO\n{FFFFFF}Aguardando manutencao...");
UpdateDynamic3DTextLabelText(InfoRadar[IndoRadar[playerid]], -1, String);
SendClientMessage(playerid, GetPlayerColor(playerid), "| DNIT | Siga o proximo checkpoint para reparar o radar");
new Float:X, Float:Y, Float:Z; GetDynamicObjectPos(Radar[IndoRadar[playerid]], X, Y, Z);
SetPlayerRaceCheckpoint(playerid, 2, X, Y, Z, X, Y, Z, 3.0);
return 1;
}
forward Consertando(playerid);
public Consertando(playerid)
{
if(ConsertandoVeiculo[playerid] < 100)
{
ConsertandoVeiculo[playerid] ++;
new Float:Vida, Float:X, Float:Y, Float:Z; GetVehicleHealth(ConsertandoV[playerid], Vida); GetVehiclePos(ConsertandoV[playerid], X, Y, Z);
if(IsPlayerInRangeOfPoint(playerid, 10.0, X, Y, Z))
{
if(Vida < 1000.0)
{
Vida += Sub[playerid];
SetVehicleHealth(ConsertandoV[playerid], Vida);
}
new StrT[70]; format(StrT, sizeof(StrT), "~w~Consertando ~y~%s_~w~( %d%s )", NomeVeiculo(ConsertandoV[playerid]), ConsertandoVeiculo[playerid], "%");
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], ConsertandoVeiculo[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoConserto[playerid] = SetTimerEx("Consertando", random(100)+random(300), false, "i", playerid);
}
else
{
ConsertandoVeiculo[playerid] = -1;
ApplyAnimation(playerid, "CARRY", "crry_prtial", 2.0, 0, 0, 0, 0, 0, 1);
TogglePlayerControllable(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Voce nao esta proximo do veiculo que estava consertando");
}
}
else
{
ConsertandoVeiculo[playerid] = -1;
ApplyAnimation(playerid, "CARRY", "crry_prtial", 2.0, 0, 0, 0, 0, 0, 1);
TogglePlayerControllable(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
new Float:X, Float:Y, Float:Z; GetVehiclePos(ConsertandoV[playerid], X, Y, Z);
if(IsPlayerInRangeOfPoint(playerid, 10.0, X, Y, Z))
{
RepairVehicle(ConsertandoV[playerid]);
foreach(Player, i)
{
if(OfereceuReparo[i] == playerid && PROF[playerid] == MECANICO)
{
Money[playerid] += ValorReparo[i];
format(String, sizeof(String), "| MECANICO | Voce terminou o reparo e recebeu {228B22}$%d", ValorReparo[i]);
OfereceuReparo[i] = -1;
ValorReparo[i] = 0;
return SendClientMessage(playerid, -1, String);
}
}
if(PROF[playerid] == MECANICO)
{
new ReceberMoney = 500 + random(501);
Money[playerid] += ReceberMoney;
format(String, sizeof(String), "| MECANICO | Voce recebeu {228B22}$%d {FFFFFF}por reparar esse veiculo", ReceberMoney);
return SendClientMessage(playerid, -1, String);
}
}
else
{
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Voce nao esta proximo do veiculo que estava consertando");
}
}
return 1;
}
forward FinalizarAssalto(playerid);
public FinalizarAssalto(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "Roubando_dinheiro:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("FinalizarAssalto", 100, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
ApplyAnimation(playerid, "CARRY", "crry_prtial", 2.0, 0, 0, 0, 0, 0, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
new Float:C[3];
for(new a; a < 5; a++)
{
GetDynamicObjectPos(ObjetoCofre[a], C[0], C[1], C[2]);
if(IsPlayerInRangeOfPoint(playerid, 1.0, C[0], C[1], C[2]))
{
if(ValorCofre[a] > 0)
{
DinheiroSujo[playerid] += ValorCofre[a];
new StrA[15];
format(StrA, sizeof(StrA), "~w~DINHEIRO SUJO+ ~g~$%d", ValorCofre[a]);
GameTextForPlayer(playerid, StrA, 3000, 3);
format(String, sizeof(String), "| ASSALTO | Voce levou todo o dinheiro que tinha nesse cofre ( {088A08}$%d {FFFFFF})", ValorCofre[a]);
SendClientMessage(playerid, -1, String);
GameTextForPlayer(playerid, "~r~Assalto Efetuado!", 4000, 4);
CofreFavela += ValorCofre[a] * 10 / 100;
new ValorNaMsg[11]; format(ValorNaMsg, sizeof(ValorNaMsg), "%d", CofreFavela);
format(String, sizeof(String), "{FFFFFF}Dinheiro Sujo\n{00FF00}$%s\nUse /Sacar", AttNumeroDecimal(ValorNaMsg));
UpdateDynamic3DTextLabelText(TextFavela, -1, String);
ValorCofre[a] = -1;
UpdateDynamic3DTextLabelText(TextoCofre[a], -1, "{FFFFFF}Cofre");
DestroyDynamicObject(ObjetoCofre[a]);
ObjetoCofre[a] = CreateDynamicObject(2003, C[0], C[1]-0.5, C[2], 0.000000, 0.000000, 180.000000, -1, -1, -1, 300.00, 300.00);
Streamer_Update(playerid);
return 1;
}
else
{
SendClientMessage(playerid, COR_ERRO, "| ASSALTO | Esse cofre nao tem mais dinheiro");
GameTextForPlayer(playerid, "~r~Assalto Fracassado!", 4000, 4);
return 1;
}
}
}
SendClientMessage(playerid, COR_ERRO, "| ASSALTO | Voce ficou muito longe do cofre");
GameTextForPlayer(playerid, "~r~Assalto Fracassado!", 4000, 4);
return 1;
}
return 1;
}
forward FlashFotoSair(playerid);
public FlashFotoSair(playerid)
{
TextDrawHideForPlayer(playerid, Flash);
return 1;
}
forward FecharPedagio(gateid, idpedagio);
public FecharPedagio(gateid, idpedagio)
{
if(IsValidDynamicObject(gateid))
{
MoveDynamicObject(gateid, PosOriginalPedagio[idpedagio][0], PosOriginalPedagio[idpedagio][1], PosOriginalPedagio[idpedagio][2], 0.1, PosOriginalPedagio[idpedagio][3], PosOriginalPedagio[idpedagio][4], PosOriginalPedagio[idpedagio][5]);
}
return 1;
}
forward ReiniciarServerComando();
public ReiniciarServerComando()
{
FileLog("Reiniciamento", "O Servidor foi reiniciado pelo comando");
SendRconCommand("exit");
}
forward ProduzirPistola9mm(playerid);
public ProduzirPistola9mm(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "PRODUZINDO_ARMA:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ProduzirPistola9mm", 100, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
SlotMochila[playerid][m] = PISTOLA9MM;
QuantidadeSlotMochila[playerid][m] = 500;
SendClientMessage(playerid, GetPlayerColor(playerid), "| INFO | Arma produzida com sucesso");
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel produzir a arma pois seu inventario nao tem espaco");
}
return 1;
}
forward ProduzirPistolaSilenced(playerid);
public ProduzirPistolaSilenced(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "PRODUZINDO_ARMA:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ProduzirPistolaSilenced", 200, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
SlotMochila[playerid][m] = PISTOLASILENCED;
QuantidadeSlotMochila[playerid][m] = 500;
SendClientMessage(playerid, GetPlayerColor(playerid), "| INFO | Arma produzida com sucesso");
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel produzir a arma pois seu inventario nao tem espaco");
}
return 1;
}
forward BlindandoVeiculo(playerid);
public BlindandoVeiculo(playerid)
{
if(GetPlayerState(playerid) == PLAYER_STATE_DRIVER)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] += 2;
new StrT[35]; format(StrT, sizeof(StrT), "Blindando_%s:_%d%", NomeVeiculo(GetPlayerVehicleID(playerid)), PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("BlindandoVeiculo", 200, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
GameTextForPlayer(playerid, "~b~Veiculo Blindado!", 3000, 3);
PlayerPlaySound(playerid, 1133, 0.0, 0.0, 0.0);
RepairVehicle(GetPlayerVehicleID(playerid));
SetVehicleHealth(GetPlayerVehicleID(playerid), 100000);
}
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
}
return 1;
}
forward ReparandoCofre(playerid);
public ReparandoCofre(playerid)
{
if(IsPlayerInRangeOfPoint(playerid, 30.0, -31.381217, -26.194713, 1261.542236))
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] += 2;
new StrT[35]; format(StrT, sizeof(StrT), "Reparando_~y~cofre:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ReparandoCofre", 200, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
GameTextForPlayer(playerid, "~b~Cofre reparado!", 3000, 3);
SendClientMessage(playerid, -1, "| INFO | Cofre reparado com sucesso!");
new i = GetPlayerVirtualWorld(playerid);
if(f_info[i][f_cofre] < 0)
{
f_info[i][f_cofre] = 0;
new str[400]; format(str, sizeof(str), "{FFFFFF}Fazenda {6441A5}%s {FFFFFF}ID %d\n{FFFFFF}Dono: %s\n{FFFFFF}Funcionario 1: %s\n{FFFFFF}Funcionario 2: %s\n{FFFFFF}Funcionario 3: %s\n{FFFFFF}Valor: {00FF00}$500.000 {FFFFFF}e {FFFF00}50.000 Coins\n{FFFFFF}Fundos: {00FF00}$%d\n{FFFFFF}Produtos: {DF7401}%d und", f_info[i][f_nome], i, f_info[i][f_dono], f_info[i][f_funcionario0], f_info[i][f_funcionario1], f_info[i][f_funcionario2], f_info[i][f_cofre], f_info[i][f_produtos]);
UpdateDynamic3DTextLabelText( f_info[i][f_texto], -1, str);
}
}
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
}
return 1;
}
forward ProduzirDesertEagle(playerid);
public ProduzirDesertEagle(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "PRODUZINDO_ARMA:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ProduzirDesertEagle", 300, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
SlotMochila[playerid][m] = DESERTEAGLE;
QuantidadeSlotMochila[playerid][m] = 500;
SendClientMessage(playerid, GetPlayerColor(playerid), "| INFO | Arma produzida com sucesso");
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel produzir a arma pois seu inventario nao tem espaco");
}
return 1;
}
forward ProduzirShotGunNormal(playerid);
public ProduzirShotGunNormal(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "PRODUZINDO_ARMA:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ProduzirShotGunNormal", 200, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
SlotMochila[playerid][m] = SHOTGUN;
QuantidadeSlotMochila[playerid][m] = 500;
SendClientMessage(playerid, GetPlayerColor(playerid), "| INFO | Arma produzida com sucesso");
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel produzir a arma pois seu inventario nao tem espaco");
}
return 1;
}
stock MsgFrequencia(freq, color, msg[])
{
for(new i=0;i<MAX_PLAYERS;i++)
if(IsPlayerConnected(i))
if(FrequenciaConectada[i] > 0 && FrequenciaConectada[i] == freq)
SendClientMessage(i, color, msg);
return 1;
}
forward ProduzirSawnoffShotgun(playerid);
public ProduzirSawnoffShotgun(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "PRODUZINDO_ARMA:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ProduzirSawnoffShotgun", 400, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
SlotMochila[playerid][m] = SAWNOFF;
QuantidadeSlotMochila[playerid][m] = 500;
SendClientMessage(playerid, GetPlayerColor(playerid), "| INFO | Arma produzida com sucesso");
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel produzir a arma pois seu inventario nao tem espaco");
}
return 1;
}
forward ProduzirCombatShotgun(playerid);
public ProduzirCombatShotgun(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "PRODUZINDO_ARMA:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ProduzirCombatShotgun", 400, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
SlotMochila[playerid][m] = COMBATSHOTGUN;
QuantidadeSlotMochila[playerid][m] = 500;
SendClientMessage(playerid, GetPlayerColor(playerid), "| INFO | Arma produzida com sucesso");
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel produzir a arma pois seu inventario nao tem espaco");
}
return 1;
}
forward ProduzirMP5(playerid);
public ProduzirMP5(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "PRODUZINDO_ARMA:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ProduzirMP5", 300, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
SlotMochila[playerid][m] = MP5;
QuantidadeSlotMochila[playerid][m] = 500;
SendClientMessage(playerid, GetPlayerColor(playerid), "| INFO | Arma produzida com sucesso");
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel produzir a arma pois seu inventario nao tem espaco");
}
return 1;
}
forward ProduzirUzi(playerid);
public ProduzirUzi(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "PRODUZINDO_ARMA:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ProduzirUzi", 300, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
SlotMochila[playerid][m] = UZI;
QuantidadeSlotMochila[playerid][m] = 500;
SendClientMessage(playerid, GetPlayerColor(playerid), "| INFO | Arma produzida com sucesso");
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel produzir a arma pois seu inventario nao tem espaco");
}
return 1;
}
forward ProduzirAK(playerid);
public ProduzirAK(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "PRODUZINDO_ARMA:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ProduzirAK", 500, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
SlotMochila[playerid][m] = AK;
QuantidadeSlotMochila[playerid][m] = 500;
SendClientMessage(playerid, GetPlayerColor(playerid), "| INFO | Arma produzida com sucesso");
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel produzir a arma pois seu inventario nao tem espaco");
}
return 1;
}
forward ProduzirM4(playerid);
public ProduzirM4(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "PRODUZINDO_ARMA:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ProduzirM4", 500, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
SlotMochila[playerid][m] = M4;
QuantidadeSlotMochila[playerid][m] = 500;
SendClientMessage(playerid, GetPlayerColor(playerid), "| INFO | Arma produzida com sucesso");
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel produzir a arma pois seu inventario nao tem espaco");
}
return 1;
}
forward ProduzirSniper(playerid);
public ProduzirSniper(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "PRODUZINDO_ARMA:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ProduzirSniper", 600, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
SlotMochila[playerid][m] = SNIPER;
QuantidadeSlotMochila[playerid][m] = 500;
SendClientMessage(playerid, GetPlayerColor(playerid), "| INFO | Arma produzida com sucesso");
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel produzir a arma pois seu inventario nao tem espaco");
}
return 1;
}
forward ProduzirDinamite(playerid);
public ProduzirDinamite(playerid)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] ++;
new StrT[25]; format(StrT, sizeof(StrT), "PRODUZINDO_ARMA:_%d%", PRODUZINDOARMA[playerid]);
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], StrT);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("ProduzirDinamite", 900, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
SlotMochila[playerid][m] = DINAMITE;
QuantidadeSlotMochila[playerid][m] = 1;
SendClientMessage(playerid, GetPlayerColor(playerid), "| INFO | Arma produzida com sucesso");
return 1;
}
}
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel produzir a arma pois seu inventario nao tem espaco");
}
return 1;
}
forward AbrirPresente(playerid);
public AbrirPresente(playerid)
{
if(IsPlayerConnected(playerid) && Spawnado[playerid] == true)
{
if(PRODUZINDOARMA[playerid] < 100)
{
PRODUZINDOARMA[playerid] += 2;
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], PRODUZINDOARMA[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
TempoProducaoArma[playerid] = SetTimerEx("AbrirPresente", 100, false, "i", playerid);
}
else
{
PRODUZINDOARMA[playerid] = -1;
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
for(new m; m < GetPlayerVoltas(playerid); m++)
{
if(SlotMochila[playerid][m] == 0)
{
new Year, Month, Day, Days; Days = getdate(Year, Month, Day);
DiaPresente[playerid] = Days;
new numero = random(sizeof(ItensGeral));
if(ItensGeral[numero] == DINDIN)
{
new dimtexto[31], dim = 1000 + random(10000);
format(dimtexto, sizeof(dimtexto), "~n~Voce ganhou ~g~$%d~w~!", dim);
MsgAviso(playerid, 5, dimtexto);
Money[playerid] += dim;
}
else
{
SlotMochila[playerid][m] = ItensGeral[numero];
QuantidadeSlotMochila[playerid][m] = 1;
}
PlayerTextDrawSetPreviewModel(playerid, TextPresente[playerid][2], ItensGeral[numero]);
ItemPreviewRot(playerid, ItensGeral[numero], TextPresente[playerid][2]);
for(new t; t < 5; t++)
{
PlayerTextDrawShow(playerid, TextPresente[playerid][t]);
}
SelectTextDraw(playerid, 0xFFFFFF55);
return 1;
}
}
SetCameraBehindPlayer(playerid);
ApplyAnimation(playerid, "CARRY", "crry_prtial", 2.0, 0, 0, 0, 0, 0, 1);
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Nao foi possivel abrir o presente pois seu inventario nao tem espaco");
}
}
return 1;
}
forward Abordou(id);
public Abordou(id)
{
if(NivelProcurado[id] > 0)
{
format(String, sizeof(String), "| perseguicao | O(A) Policial %s[%d] iniciou uma perseguicao no(a) jogador(a) %s[%d] por ele(a) nao se render", PlayerName(PolicialQueAbordou[id]), PolicialQueAbordou[id], PlayerName(id), id);
SendClientMessageToAll(0x1E90FFFF, String);
SegundosPerseguidoCorp[id] = 300;
}
TimerAbordo[id] = -1;
TextDrawHideForPlayer(id, TextAbordagem[0]); TextDrawHideForPlayer(id, TextAbordagem[1]);
return 1;
}
forward AbordouAb(id);
public AbordouAb(id)
{
TimerAbordoAb[id] = -1;
TextDrawHideForPlayer(id, TextAbordagem[0]); TextDrawHideForPlayer(id, TextAbordagemAb);
return 1;
}
stock pMala_SalvarArmas(playerid,vehid,tipo,xPlayer){
if(tipo == 1){
PlayerNoVeiculo[vehid] = playerid+1;
TogglePlayerSpectating(playerid, 1);
PlayerSpectateVehicle(playerid, vehid);
Na_Mala[playerid] = vehid+1;
for(new i = 0; i < 13; i++) GetPlayerWeaponData(playerid,i,ArmasPlayer[0][i][playerid],ArmasPlayer[1][i][playerid]);
}else if(tipo == 2){
TogglePlayerSpectating(playerid, 0);
SetTimerEx("Mala_Car", 100, false,"ii",playerid,xPlayer);
ResetPlayerWeapons(playerid);
for(new i = 0; i < 13; i++) GivePlayerWeaponExC(playerid,ArmasPlayer[0][i][playerid],ArmasPlayer[1][i][playerid]);
}
return 1;
}
forward Localizador(playerid);
public Localizador(playerid)
{
if(IsPlayerConnected(playerid) && Spawnado[playerid] == true && IsPlayerConnected(Localizando[playerid]) && Spawnado[Localizando[playerid]] == true)
{
if(PROF[playerid] == PM || PROF[playerid] == ROTA  || PROF[playerid] == CHOQUE || PROF[playerid] == ROTAM || PROF[playerid] == BOPE || PROF[playerid] == PC || PROF[playerid] == PF || PROF[playerid] == EXERCITO)
{
if(SegundosPreso[Localizando[playerid]] <= 0 && MinutosPreso[Localizando[playerid]] <= 0 && HorasPreso[Localizando[playerid]] <= 0)
{
new zone[MAX_ZONE_NAME], MsgLocalize[128], Float:X, Float:Y, Float:Z;
GetPlayerPos(Localizando[playerid], X, Y, Z); GetPlayer2DZone(Localizando[playerid], zone, MAX_ZONE_NAME);
new Float:fDistance = GetPlayerDistanceFromPoint(playerid, X, Y, Z);
format(MsgLocalize, sizeof(MsgLocalize), "~w~Jogador: ~b~~h~%s~w~, Local: ~g~~h~%s~w~, Distancia: ~r~~h~%0.1fm", PlayerName(Localizando[playerid]), zone, fDistance);
if(MinutosMorte[playerid] <= 0 && SegundosMorte[playerid] <= 0) PlayerTextDrawSetString(playerid, MsgText[playerid], MsgLocalize);
SetTimerEx("Localizador", 2000, false, "i", playerid);
}
else
{
SendClientMessage(playerid, 0x228B22FF, "| GPS | O(A) Jogador(a) localizado foi preso");
Localizando[playerid] = -1;
DisablePlayerCheckpoint(playerid);
}
}
else if(PROF[playerid] == TAXISTA || PROF[playerid] == MECANICO)
{
new zone[MAX_ZONE_NAME], MsgLocalize[128], Float:X, Float:Y, Float:Z;
GetPlayerPos(Localizando[playerid], X, Y, Z); GetPlayer2DZone(Localizando[playerid], zone, MAX_ZONE_NAME);
new Float:fDistance = GetPlayerDistanceFromPoint(playerid, X, Y, Z);
format(MsgLocalize, sizeof(MsgLocalize), "~w~Jogador: ~b~~h~%s~w~, Local: ~g~~h~%s~w~, Distancia: ~r~~h~%0.1fm", PlayerName(Localizando[playerid]), zone, fDistance);
if(MinutosMorte[playerid] <= 0 && SegundosMorte[playerid] <= 0) PlayerTextDrawSetString(playerid, MsgText[playerid], MsgLocalize);
SetPlayerCheckpoint(playerid, X, Y, Z, 0.0);
SetTimerEx("Localizador", 2000, false, "i", playerid);
}
else if(ORG[playerid] >= 0)
{
if(EmContrato[Localizando[playerid]] > 0)
{
new zone[MAX_ZONE_NAME], MsgLocalize[128]; GetPlayer2DZone(Localizando[playerid], zone, MAX_ZONE_NAME);
format(MsgLocalize, sizeof(MsgLocalize), "~w~Jogador: ~b~~h~%s~w~, Local: ~g~~h~%s", PlayerName(Localizando[playerid]), zone);
if(MinutosMorte[playerid] <= 0 && SegundosMorte[playerid] <= 0) PlayerTextDrawSetString(playerid, MsgText[playerid], MsgLocalize);
SetTimerEx("Localizador", 2000, false, "i", playerid);
}
else
{
SendClientMessage(playerid, 0x228B22FF, "| GPS | O(A) Jogador(a) localizado nao esta mais em contrato de morte");
Localizando[playerid] = -1;
DisablePlayerCheckpoint(playerid);
}
}
else if(PROF[playerid] == PARAMEDICO)
{
if(IsPlayerConnected(Localizando[playerid]) && SegundosPreso[Localizando[playerid]] <= 0 && MinutosPreso[Localizando[playerid]] <= 0 && HorasPreso[Localizando[playerid]] <= 0 && SegundosMorte[Localizando[playerid]] > 0 || MinutosMorte[Localizando[playerid]] > 0)
{
new MsgLocalize[128], Float:X, Float:Y, Float:Z; GetPlayerPos(Localizando[playerid], X, Y, Z);
new Float:fDistance = GetPlayerDistanceFromPoint(playerid, X, Y, Z);
format(MsgLocalize, sizeof(MsgLocalize), "~w~O Jogador: ~b~~h~%s~w~ esta morrendo, ~r~CORRA~w~!~n~~g~~h~Resistencia: ~w~%02d:%02d ~g~~h~Distancia: ~w~%0.1fm", PlayerName(Localizando[playerid]), MinutosMorte[Localizando[playerid]], SegundosMorte[Localizando[playerid]], fDistance);
if(MinutosMorte[playerid] <= 0 && SegundosMorte[playerid] <= 0) PlayerTextDrawSetString(playerid, MsgText[playerid], MsgLocalize);
if(CheckSAMU[playerid] > -1)
{
DestroyDynamicCP(CheckSAMU[playerid]);
}
CheckSAMU[playerid] = CreateDynamicCP(X, Y, Z, 1.2, -1, -1, playerid, 10000.0);
SetTimerEx("Localizador", 2000, false, "i", playerid);
}
else
{
if(CheckSAMU[playerid] > -1)
{
DestroyDynamicCP(CheckSAMU[playerid]);
CheckSAMU[playerid] = -1;
}
if(SangueObjeto[Localizando[playerid]] > -1)
{
DestroyObject(SangueObjeto[Localizando[playerid]]);
SangueObjeto[Localizando[playerid]] = -1;
}
Localizando[playerid] = -1;
SendClientMessage(playerid, GetPlayerColor(playerid), "| SAMU | O(A) Jogador(a) localizado(a) nao precisa mais de socorro");
}
}
}
else
{
Localizando[playerid] = -1;
DisablePlayerCheckpoint(playerid);
if(CheckSAMU[playerid] > -1)
{
DestroyDynamicCP(CheckSAMU[playerid]);
CheckSAMU[playerid] = -1;
}
}
return 1;
}
stock VoipNomer(playerid){
new name[MAX_PLAYER_NAME+1];
GetPlayerName(playerid, name, MAX_PLAYER_NAME+1);
return name;
}
forward Localizadorr(playerid);
public Localizadorr(playerid)
{
if(IsPlayerConnected(playerid) && Spawnado[playerid] == true && IsPlayerConnected(InviteLocalizacao[playerid]) && Spawnado[InviteLocalizacao[playerid]] == true && Localizando[playerid] == -1)
{
new zone[MAX_ZONE_NAME], MsgLocalize[128], Float:X, Float:Y, Float:Z;
GetPlayerPos(InviteLocalizacao[playerid], X, Y, Z); GetPlayer2DZone(InviteLocalizacao[playerid], zone, MAX_ZONE_NAME);
new Float:fDistance = GetPlayerDistanceFromPoint(playerid, X, Y, Z);
format(MsgLocalize, sizeof(MsgLocalize), "~w~LOCALIZANDO: ~b~~h~%s~w~, Local: ~g~~h~%s~w~, Distancia: ~r~~h~%0.1fm", PlayerName(InviteLocalizacao[playerid]), zone, fDistance);
if(MinutosMorte[playerid] <= 0 && SegundosMorte[playerid] <= 0) PlayerTextDrawSetString(playerid, MsgText[playerid], MsgLocalize);
SetPlayerCheckpoint(playerid, X, Y, Z, 0.0);
SetTimerEx("Localizadorr", 2000, false, "i", playerid);
}
else
{
InviteLocalizacao[playerid] = -1;
DisablePlayerCheckpoint(playerid);
}
return 1;
}
forward ChamadaTrintaMin();
public ChamadaTrintaMin()
{
for(new i = 0; i < sizeof(ClimaCidades); i++)
{
ClimaCidades[i] = random(20) + 1;
if(ClimaCidades[i] == 8 || ClimaCidades[i] == 9 || ClimaCidades[i] == 16 || ClimaCidades[i] == 19)
{
ClimaCidades[i] = 18;
}
}
SetTimer("AutoMessage", 30000+random(31000), false);
new Float:C[3];
for(new a; a < 5; a++)
{
if(ValorCofre[a] == -1)
{
ValorCofre[a] = 0;
UpdateDynamic3DTextLabelText(TextoCofre[a], -1, "{FFFFFF}Cofre");
GetDynamicObjectPos(ObjetoCofre[a], C[0], C[1], C[2]);
DestroyDynamicObject(ObjetoCofre[a]);
ObjetoCofre[a] = CreateDynamicObject(2332, C[0], C[1], C[2], 0.000000, 0.000000, 180.000000, -1, -1, -1, 300.00, 300.00);
}
}
Sorteio ++;
if(Sorteio == 3)
{
sdados();
new NomeNaMsg[15]; format(NomeNaMsg, sizeof(NomeNaMsg), "%d", AcumuladosLotofacil);
format(String, sizeof(String), "| LOTOFACIL | O premio %s esta acumulado em $%s, va ate a loterica e faca sua aposta!", GetDia(), AttNumeroDecimal(NomeNaMsg));
SendClientMessageToAll(0x088A08FF, String);
}
else if(Sorteio == 4)
{
new hh, mm, ss; gettime(hh, mm, ss);
TempoSorteio[0][0] = hh+4; TempoSorteio[0][1] = mm;
if(TempoSorteio[0][0] >= 24)
{
TempoSorteio[0][0] -= 24;
}
TextDrawSetString(TextSorteio[1], "Lotofacil");
new n = 1 + random(100);
if(!new_strcmp(Lotofacil[n-1], "Ninguem"))
{
new bool:passou;
for(new t; t < 30; t++)
{
if(new_strcmp(GanhadoresLoteria[t], ""))
{
new dia, mes, ano, hora, minuto, segundo; getdate(ano, mes, dia); gettime(hora, minuto, segundo);
format(GanhadoresLoteria[t], 150, "O(A) Jogador(a) %s ganhou na Lotofacil dia %02d/%02d/%02d as %02d:%02d, premio: $%d, numero: %02d", Lotofacil[n-1], dia, mes, ano, hora, minuto, AcumuladosLotofacil, n);
passou = true;
break;
}
}
if(passou == false)
{
for(new t; t < 29; t++)
{
format(GanhadoresLoteria[t], 150, "%s", GanhadoresLoteria[t+1]);
}
new dia, mes, ano, hora, minuto, segundo; getdate(ano, mes, dia); gettime(hora, minuto, segundo);
format(GanhadoresLoteria[29], 150, "O(A) Jogador(a) %s ganhou na Lotofacil dia %02d/%02d/%02d as %02d:%02d, premio: $%d, numero: %02d", Lotofacil[n-1], dia, mes, ano, hora, minuto, AcumuladosLotofacil, n);
}
foreach(Player, i)
{
if(new_strcmp(Lotofacil[n-1], PlayerName(i)) && Spawnado[i] == true)
{
format(String, sizeof(String), "| INFO | Voce foi o(a) ganhador(a) da Lotofacil e recebeu $%d em sua conta bancaria!", AcumuladosLotofacil);
SendClientMessage(i, 0x00FF00FF, String);
GameTextForPlayer(i, "~g~Voce ganhou!", 5000, 0);
SaldoBancario[i] += AcumuladosLotofacil;
new NomeNaMsg[15]; format(NomeNaMsg, sizeof(NomeNaMsg), "%d", AcumuladosLotofacil);
format(String, sizeof(String), "Premio: ~g~$%s~n~~w~Numero Sorteado: ~y~%02d~n~~w~Ganhador: ~b~%s", AttNumeroDecimal(NomeNaMsg), n, Lotofacil[n-1]);
TextDrawSetString(TextSorteio[2], String);
AcumuladosLotofacil = 2501 + random(2500);
SetTimer("LimparSorteio", 6000, false);
for(new l; l < 100; l++)
{
format(Lotofacil[l], 25, "Ninguem");
}
for(new t; t < 4; t++)
{
TextDrawShowForAll(TextSorteio[t]);
}
return 1;
}
}
format(String, sizeof(String), "Contas/%s.ini", Lotofacil[n-1]);
if(DOF2_FileExists(String))
{
DOF2_SetInt(String, "SaldoBancario", DOF2_GetInt(String, "SaldoBancario") + AcumuladosLotofacil);
DOF2_SaveFile();
}
new NomeNaMsg[15]; format(NomeNaMsg, sizeof(NomeNaMsg), "%d", AcumuladosLotofacil);
format(String, sizeof(String), "Premio: ~g~$%s~n~~w~Numero Sorteado: ~y~%02d~n~~w~Ganhador: ~b~%s", AttNumeroDecimal(NomeNaMsg), n, Lotofacil[n-1]);
TextDrawSetString(TextSorteio[2], String);
AcumuladosLotofacil = 2501 + random(2500);
SetTimer("LimparSorteio", 6000, false);
for(new l; l < 100; l++)
{
format(Lotofacil[l], 25, "Ninguem");
}
for(new t; t < 4; t++)
{
TextDrawShowForAll(TextSorteio[t]);
}
}
else
{
new NomeNaMsg[15]; format(NomeNaMsg, sizeof(NomeNaMsg), "%d", AcumuladosLotofacil);
format(String, sizeof(String), "Premio: ~g~$%s~n~~w~Numero Sorteado: ~y~%02d~n~~w~Ganhador: ~r~%s", AttNumeroDecimal(NomeNaMsg), n, Lotofacil[n-1]);
TextDrawSetString(TextSorteio[2], String);
AcumuladosLotofacil += 8000+random(5001);
SetTimer("LimparSorteio", 6000, false);
for(new l; l < 100; l++)
{
format(Lotofacil[l], 25, "Ninguem");
}
for(new t; t < 4; t++)
{
TextDrawShowForAll(TextSorteio[t]);
}
}
}
else if(Sorteio == 7)
{
sdados();
new NomeNaMsg[15]; format(NomeNaMsg, sizeof(NomeNaMsg), "%d", AcumuladosMegasena);
format(String, sizeof(String), "| MEGA-SENA | O premio %s esta acumulado em $%s, va ate a loterica e faca sua aposta!", GetDia(), AttNumeroDecimal(NomeNaMsg));
SendClientMessageToAll(0x088A08FF, String);
}
else if(Sorteio == 8)
{
Sorteio = 0;
new hh, mm, ss; gettime(hh, mm, ss);
TempoSorteio[1][0] = hh+4; TempoSorteio[1][1] = mm;
if(TempoSorteio[1][0] >= 24)
{
TempoSorteio[1][0] -= 24;
}
TextDrawSetString(TextSorteio[1], "Mega-Sena");
new a = 1 + random(15), b = 1 + random(15), c = 1 + random(15);
while(a == b)
{
a = 1 + random(15);
}
while(c == b || c == a)
{
c = 1 + random(15);
}
new acertou;
for(new m; m < MAX_PLAYERS; m++)
{
if(!new_strcmp(NomeMegaSena[m], "Ninguem"))
{
for(new n; n < 3; n++)
{
if(NumeroMegaSena[m][n] == a || NumeroMegaSena[m][n] == b || NumeroMegaSena[m][n] == c)
{
acertou ++;
}
}
if(acertou >= 3)
{
new bool:passou;
for(new t; t < 30; t++)
{
if(new_strcmp(GanhadoresLoteria[t], ""))
{
new dia, mes, ano, hora, minuto, segundo; getdate(ano, mes, dia); gettime(hora, minuto, segundo);
format(GanhadoresLoteria[t], 150, "O(A) Jogador(a) %s ganhou na Mega-Sena dia %02d/%02d/%02d as %02d:%02d, premio: $%d, numeros: %02d-%02d-%02d", NomeMegaSena[m], dia, mes, ano, hora, minuto, AcumuladosMegasena, a, b, c);
passou = true;
break;
}
}
if(passou == false)
{
for(new t; t < 29; t++)
{
format(GanhadoresLoteria[t], 150, "%s", GanhadoresLoteria[t+1]);
}
new dia, mes, ano, hora, minuto, segundo; getdate(ano, mes, dia); gettime(hora, minuto, segundo);
format(GanhadoresLoteria[29], 150, "O(A) Jogador(a) %s ganhou na Mega-Sena dia %02d/%02d/%02d as %02d:%02d, premio: $%d, numeros: %02d-%02d-%02d", NomeMegaSena[m], dia, mes, ano, hora, minuto, AcumuladosMegasena, a, b, c);
}
foreach(Player, i)
{
if(new_strcmp(PlayerName(i), NomeMegaSena[m]) && Spawnado[i] == true)
{
format(String, sizeof(String), "| INFO | Voce foi o(a) ganhador(a) da Mega-Sena e recebeu $%d em sua conta bancaria!", AcumuladosMegasena);
SendClientMessage(i, 0x00FF00FF, String);
GameTextForPlayer(i, "~g~Voce ganhou!", 5000, 0);
SaldoBancario[i] += AcumuladosMegasena;
new NomeNaMsg[15]; format(NomeNaMsg, sizeof(NomeNaMsg), "%d", AcumuladosMegasena);
format(String, sizeof(String), "Premio: ~g~$%s~n~~w~Numero Sorteado: ~y~%02d-%02d-%02d~n~~w~Ganhador: ~b~%s", AttNumeroDecimal(NomeNaMsg), a, b, c, NomeMegaSena[m]);
TextDrawSetString(TextSorteio[2], String);
AcumuladosMegasena = 1000 + random(1001);
SetTimer("LimparSorteio", 6000, false);
for(new l; l < MAX_PLAYERS; l++)
{
format(NomeMegaSena[l], 25, "Ninguem");
NumeroMegaSena[l][0] = 0; NumeroMegaSena[l][1] = 0; NumeroMegaSena[l][2] = 0;
}
for(new t; t < 4; t++)
{
TextDrawShowForAll(TextSorteio[t]);
}
return 1;
}
}
format(String, sizeof(String), "Contas/%s.ini", NomeMegaSena[m]);
if(DOF2_FileExists(String))
{
DOF2_SetInt(String, "SaldoBancario", DOF2_GetInt(String, "SaldoBancario") + AcumuladosMegasena);
DOF2_SaveFile();
}
new NomeNaMsg[15]; format(NomeNaMsg, sizeof(NomeNaMsg), "%d", AcumuladosMegasena);
format(String, sizeof(String), "Premio: ~g~$%s~n~~w~Numero Sorteado: ~y~%02d-%02d-%02d~n~~w~Ganhador: ~b~%s", AttNumeroDecimal(NomeNaMsg), a, b, c, NomeMegaSena[m]);
TextDrawSetString(TextSorteio[2], String);
AcumuladosMegasena = 1000 + random(1001);
SetTimer("LimparSorteio", 6000, false);
for(new l; l < MAX_PLAYERS; l++)
{
format(NomeMegaSena[l], 25, "Ninguem");
NumeroMegaSena[l][0] = 0; NumeroMegaSena[l][1] = 0; NumeroMegaSena[l][2] = 0;
}
for(new t; t < 4; t++)
{
TextDrawShowForAll(TextSorteio[t]);
}
return 1;
}
else
{
acertou = 0;
format(NomeMegaSena[m], 25, "Ninguem");
NumeroMegaSena[m][0] = 0; NumeroMegaSena[m][1] = 0; NumeroMegaSena[m][2] = 0;
}
}
}
new NomeNaMsg[15]; format(NomeNaMsg, sizeof(NomeNaMsg), "%d", AcumuladosMegasena);
format(String, sizeof(String), "Premio: ~g~$%s~n~~w~Numero Sorteado: ~y~%02d-%02d-%02d~n~~w~Ganhador: ~r~Ninguem", AttNumeroDecimal(NomeNaMsg), a, b, c);
TextDrawSetString(TextSorteio[2], String);
AcumuladosMegasena += 8000+random(5001);
SetTimer("LimparSorteio", 6000, false);
for(new t; t < 4; t++)
{
TextDrawShowForAll(TextSorteio[t]);
}
}
return 1;
}
forward AutoMessage();
public AutoMessage()
{
new randMSG = random(sizeof(RandomMSG));
SendClientMessageToAll(0x00FF00FF, RandomMSG[randMSG]);
return 1;
}
forward LimparSorteio();
public LimparSorteio()
{
for(new t; t < 4; t++)
{
TextDrawHideForAll(TextSorteio[t]);
}
return 1;
}
forward CarregarHospital(playerid);
public CarregarHospital(playerid)
{
TogglePlayerControllable(playerid, 1);
MsgAviso(playerid, 5, "~w~Hospital");
return 1;
}
forward CarregarInterior(playerid);
public CarregarInterior(playerid)
{
TogglePlayerControllable(playerid, 1);
return 1;
}
forward ExplodirDinamite(playerid);
public ExplodirDinamite(playerid)
{
TimerAssalto[playerid][1] = -1;
CreateExplosion(XDinamite[playerid], YDinamite[playerid], ZDinamite[playerid], 0, 10.0);
DestroyDynamicObject(Explosivos[playerid][1]);
Explosivos[playerid][1] = -1;
if(ORG[playerid] >= 0 || NivelAdmin[playerid] > 0 || IsPlayerAdmin(playerid))
{
new Float:C[6];
GetDynamicObjectPos(PortaBanco, C[0], C[1], C[2]); GetDynamicObjectRot(PortaBanco, C[3], C[4], C[5]);
if(IsPointInRangeOfPoint(C[0], C[1], C[2], XDinamite[playerid], YDinamite[playerid], ZDinamite[playerid], 1.6) && !IsDynamicObjectMoving(PortaBanco))
{
if(PortaBancoAberta == false)
{
MoveDynamicObject(PortaBanco, C[0], C[1], C[2]+0.01, 0.01, C[3], C[4], C[5]+80);
PortaBancoAberta = true;
}
new NomeBanco[20];
if(PlayerIdBanco[playerid] == 0) NomeBanco = "Sao Paulo";
else if(PlayerIdBanco[playerid] == 1) NomeBanco = "Montgomery";
else if(PlayerIdBanco[playerid] == 2) NomeBanco = "Palomino Creek";
else if(PlayerIdBanco[playerid] == 3) NomeBanco = "Bahia";
else if(PlayerIdBanco[playerid] == 4) NomeBanco = "Fort Carson";
else if(PlayerIdBanco[playerid] == 5) NomeBanco = "El Quebrados";
else if(PlayerIdBanco[playerid] == 6) NomeBanco = "Las Barrancas";
else if(PlayerIdBanco[playerid] == 7) NomeBanco = "Rio De Janeiro";
else if(PlayerIdBanco[playerid] >= 8) NomeBanco = "Algel Pine";
format(String, sizeof(String), "| DP | O(A) Mafioso(a) %s[%d] esta assaltando o Banco de %s!", PlayerName(playerid), playerid, NomeBanco);
foreach(Player, ii)
{
if(IsPlayerConnected(ii) && Spawnado[ii] == true)
{
PlayerPlaySound(ii, 9200, C[0], C[1], C[2]);
if(PROF[ii] == PM || PROF[ii] == ROTA  || PROF[ii] == CHOQUE || PROF[ii] == ROTAM || PROF[ii] == BOPE || PROF[ii] == PC || PROF[ii] == PF || PROF[ii] == EXERCITO)
{
SendClientMessage(ii, GetPlayerColor(ii), String);
}
}
}
return 1;
}
else if(IsPlayerInRangeOfPoint(playerid, 30.0, -31.381217, -26.194713, 1261.542236))
{
new i = GetPlayerVirtualWorld(playerid);
if(f_info[i][f_cofre] > 0)
{
format(String, sizeof(String), "| INFO | Voce explodiu o cofre dessa fazenda e roubou {00FF00}$%d{FFFFFF}, fuja com o dinheiro!", f_info[i][f_cofre]);
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, -1, "| INFO | O dinheiro vira para sua mao apos 2 minutos");
TimerFuga[playerid] = SetTimerEx("EntregarDinFazenda", 120000, false, "dd", playerid, f_info[i][f_cofre]);
f_info[i][f_cofre] = -1;
new str[400]; format(str, sizeof(str), "{FFFFFF}Fazenda {6441A5}%s {FFFFFF}ID %d\n{FFFFFF}Dono: %s\n{FFFFFF}Funcionario 1: %s\n{FFFFFF}Funcionario 2: %s\n{FFFFFF}Funcionario 3: %s\n{FFFFFF}Valor: {00FF00}$500.000 {FFFFFF}e {FFFF00}50.000 Coins\n{FFFFFF}Fundos: {00FF00}$%d\n{FFFFFF}Produtos: {DF7401}%d und", f_info[i][f_nome], i, f_info[i][f_dono], f_info[i][f_funcionario0], f_info[i][f_funcionario1], f_info[i][f_funcionario2], f_info[i][f_cofre], f_info[i][f_produtos]);
UpdateDynamic3DTextLabelText( f_info[i][f_texto], -1, str);
return 1;
}
}
else
{
new abrir = random(2);
for(new a; a < 5; a++)
{
GetDynamicObjectPos(ObjetoCofre[a], C[0], C[1], C[2]);
if(IsPointInRangeOfPoint(C[0], C[1], C[2], XDinamite[playerid], YDinamite[playerid], ZDinamite[playerid], 1.0) && ValorCofre[a] == 0)
{
if(abrir == 1)
{
ValorCofre[a] = 10000 + random(10001);
new StrCofre[35]; format(StrCofre, sizeof(StrCofre), "{FFFFFF}Cofre\n{00FF00}%d", ValorCofre[a]);
UpdateDynamic3DTextLabelText(TextoCofre[a], -1, StrCofre);
DestroyDynamicObject(ObjetoCofre[a]);
ObjetoCofre[a] = CreateDynamicObject(1829, C[0], C[1]+0.5, C[2], 0.000000, 0.000000, 180.000000, -1, -1, -1, 300.00, 300.00);
return 1;
}
else
{
MsgAviso(playerid, 4, "~r~Nao foi possivel abrir o cofre, tente novamente");
return 1;
}
}
}
}
}
return 1;
}
forward AssaltarCaixa(playerid);
public AssaltarCaixa(playerid)
{
new Float:P[3];
for(new cx; cx < 40; cx++)
{
GetDynamicObjectPos(Caixa[cx], P[0], P[1], P[2]);
if(IsPlayerInRangeOfPoint(playerid, 50.0, P[0], P[1], P[2]))
{
new valorassalto;
if(CaixaMoney[cx] >= 50000)
{
valorassalto = CaixaMoney[cx] * 10 / 100;
CaixaMoney[cx] -= valorassalto;
}
else if(CaixaMoney[cx] >= 25000)
{
valorassalto = CaixaMoney[cx] * 11 / 100;
CaixaMoney[cx] -= valorassalto;
}
else if(CaixaMoney[cx] >= 10000)
{
valorassalto = CaixaMoney[cx] * 12 / 100;
CaixaMoney[cx] -= valorassalto;
}
else if(CaixaMoney[cx] >= 17)
{
valorassalto = CaixaMoney[cx] * 15 / 100;
CaixaMoney[cx] -= valorassalto;
}
else
{
return SendClientMessage(playerid, COR_ERRO, "| ERRO | O Caixa Eletronico que voce tentou assaltar ficou sem dinheiro");
}
TimerAssalto[playerid][0] = -1;
CreateExplosion(XAssalto[playerid], YAssalto[playerid], ZAssalto[playerid], 11, 5.0);
DestroyDynamicObject(Explosivos[playerid][0]);
Explosivos[playerid][0] = -1;
format(String, sizeof(String), "{00FF00}Caixa Eletronico {FFFFFF}[{00FF00}$%d{FFFFFF}]\n{FFFFFF}Pressione a tecla '{00FF00}F{FFFFFF}' para utilizar", CaixaMoney[cx]);
UpdateDynamic3DTextLabelText(TextCX[cx], -1, String);
new zone[MAX_ZONE_NAME]; GetPlayer2DZone(playerid, zone, MAX_ZONE_NAME);
format(String, sizeof(String), "| ASSALTO | Voce explodiu o caixa Eletronico de {FFFF00}%s {FFFFFF}e {00CD00}$%d {FFFFFF}foram espalhados", zone, valorassalto);
SendClientMessage(playerid, -1, String);
GameTextForPlayer(playerid, "~r~~h~Assalto Efetuado!", 3000, 3);
ValorAssaltoReceber[playerid] = valorassalto / 10;
PegouDinheiro[playerid] = 10;
for(new p; p < 10; p++)
{
if(PickAssalto[playerid][p] > -1)
{
DestroyDynamicPickup(PickAssalto[playerid][p]);
}
}
CofreFavela += valorassalto * 30 / 100;
new ValorNaMsg[11]; format(ValorNaMsg, sizeof(ValorNaMsg), "%d", CofreFavela);
format(String, sizeof(String), "{FFFFFF}Dinheiro Sujo\n{00FF00}$%s\nUse /Sacar", AttNumeroDecimal(ValorNaMsg));
UpdateDynamic3DTextLabelText(TextFavela, -1, String);
new rand[10];
for (new r; r < 10; r++)
{
rand[r] = random(sizeof(RandI));
}
PickAssalto[playerid][0] = CreateDynamicPickup(1212, 23, FrenteCaixa[cx][0] + RandI[rand[0]][0], FrenteCaixa[cx][1] + RandI[rand[1]][0], FrenteCaixa[cx][2]-0.5);
PickAssalto[playerid][1] = CreateDynamicPickup(1212, 23, FrenteCaixa[cx][0] - RandI[rand[0]][0], FrenteCaixa[cx][1] - RandI[rand[1]][0], FrenteCaixa[cx][2]-0.5);
PickAssalto[playerid][2] = CreateDynamicPickup(1212, 23, FrenteCaixa[cx][0] + RandI[rand[2]][0], FrenteCaixa[cx][1] - RandI[rand[3]][0], FrenteCaixa[cx][2]-0.5);
PickAssalto[playerid][3] = CreateDynamicPickup(1212, 23, FrenteCaixa[cx][0] - RandI[rand[2]][0], FrenteCaixa[cx][1] + RandI[rand[3]][0], FrenteCaixa[cx][2]-0.5);
PickAssalto[playerid][4] = CreateDynamicPickup(1212, 23, FrenteCaixa[cx][0] + RandI[rand[4]][0], FrenteCaixa[cx][1] - RandI[rand[5]][0], FrenteCaixa[cx][2]-0.5);
PickAssalto[playerid][5] = CreateDynamicPickup(1212, 23, FrenteCaixa[cx][0] - RandI[rand[4]][0], FrenteCaixa[cx][1] + RandI[rand[5]][0], FrenteCaixa[cx][2]-0.5);
PickAssalto[playerid][6] = CreateDynamicPickup(1212, 23, FrenteCaixa[cx][0] + RandI[rand[6]][0], FrenteCaixa[cx][1] - RandI[rand[7]][0], FrenteCaixa[cx][2]-0.5);
PickAssalto[playerid][7] = CreateDynamicPickup(1212, 23, FrenteCaixa[cx][0] - RandI[rand[6]][0], FrenteCaixa[cx][1] + RandI[rand[7]][0], FrenteCaixa[cx][2]-0.5);
PickAssalto[playerid][8] = CreateDynamicPickup(1212, 23, FrenteCaixa[cx][0] + RandI[rand[8]][0], FrenteCaixa[cx][1] - RandI[rand[9]][0], FrenteCaixa[cx][2]-0.5);
PickAssalto[playerid][9] = CreateDynamicPickup(1212, 23, FrenteCaixa[cx][0] - RandI[rand[8]][0], FrenteCaixa[cx][1] + RandI[rand[9]][0], FrenteCaixa[cx][2]-0.5);
Streamer_Update(playerid);
return 1;
}
}
TimerAssalto[playerid][0] = -1;
DestroyDynamicObject(Explosivos[playerid][0]);
Explosivos[playerid][0] = -1;
return SendClientMessage(playerid, COR_ERRO, "| ERRO | Seu assalto a caixa Eletronico falhou pois voce se afastou demais");
}
forward FecharPortaoDP(gateid);
public FecharPortaoDP(gateid)
{
if(gateid == PortaoDP)
{
MoveDynamicObject(PortaoDP, 1547.3000000,-1627.7000000,15.2000000, 2.0, 0.0000000,0.0000000,90.2500000);
}
return 1;
}
forward FecharCancelaTaxi();
public FecharCancelaTaxi()
{
MoveDynamicObject(CancelaTaxi, 1811.45654, -1893.04224, 13.43060, 0.1, 0.00000, 90.00000, 90.00000);
return 1;
}
forward FecharPorta1DP(gateid);
public FecharPorta1DP(gateid)
{
if(gateid == porta1dp)
{
MoveDynamicObject(porta1dp, 250.7000000,64.2000000,1005.3000000, 2.0, 0.0000000,0.0000000,0.0);
}
return 1;
}
forward FecharPortaoPref(gateid);
public FecharPortaoPref(gateid)
{
if(gateid == PortaoPref)
{
MoveDynamicObject(PortaoPref, 371.17859, 166.65210, 1010.01862, 2.0, 0.00000, 0.00000, 90.00000);
}
return 1;
}
forward FecharPorta2DP(gateid);
public FecharPorta2DP(gateid)
{
if(gateid == porta2dp)
{
MoveDynamicObject(porta2dp, 245.5399900,72.6000000,1005.3000000, 2.0, 0.0000000,0.0000000,90.2500000);
}
return 1;
}
forward FecharPorta3DP(gateid);
public FecharPorta3DP(gateid)
{
if(gateid == porta3dp)
{
MoveDynamicObject(porta3dp, 248.2000000,87.6900000,1005.3000000, 2.0, 0.0000000,0.0000000,0.0);
}
return 1;
}
forward FecharPorta1Prisao(gateid);
public FecharPorta1Prisao(gateid)
{
if(gateid == portapresidio[0])
{
MoveDynamicObject(portapresidio[0],1334.742919, -1708.641845, 1169.057495, 2.0, 0.000000, 0.000000, 90.0);
}
return 1;
}
forward Mala_Car(playerid,xplayerid);
public Mala_Car(playerid,xplayerid){
new Float:PosP[3];
if(xplayerid == -1){
GetVehiclePos(Na_Mala[playerid]-1,PosP[0],PosP[1],PosP[2]);
SetPlayerPos(playerid,PosP[0],PosP[1],PosP[2]+3.0);
}else{
GetPlayerPos(xplayerid,PosP[0],PosP[1],PosP[2]);
SetPlayerPos(playerid,PosP[0]+0.1,PosP[1]+0.1,PosP[2]);
}
PlayerNoVeiculo[Na_Mala[playerid]-1] = 0;
Na_Mala[playerid] = 0;
return 1;
}
forward FecharPorta2Prisao(gateid);
public FecharPorta2Prisao(gateid)
{
if(gateid == portapresidio[1])
{
MoveDynamicObject(portapresidio[1],1331.132446, -1708.641845, 1169.057495, 2.0, 0.000000, 0.000000, 90.0);
}
return 1;
}
forward DescarregarMoto(playerid);
public DescarregarMoto(playerid)
{
CargaMoto[playerid] ++;
GameTextForPlayer(playerid, "~w~Mercadorias Entregue!", 2500, 4);
TogglePlayerControllable(playerid, 1);
if(CargaMoto[playerid] >= 3)
{
format(String, sizeof(String), "| TRANSPORTES | Voce entregou as 3 mercadorias e recebeu {228B22}$%d", ReceberMotoboy[playerid]);
SendClientMessage(playerid, -1, String);
Money[playerid] += ReceberMotoboy[playerid];
ReceberMotoboy[playerid] = 0;
CargaMoto[playerid] = -1;
}
else
{
SendClientMessage(playerid, -1, "| TRANSPORTES | Voce entregou e recebeu {228B22}$500{FFFFFF}, siga para a proxima entrega!");
Money[playerid] += 500;
}
for(new e; e < MAX_EMPRESAS; e++)
{
if(IsPlayerInRangeOfPoint(playerid, 5.0, eX[e], eY[e], eZ[e]))
{
if(!new_strcmp(eDono[e], "Ninguem"))
{
new randomlucro = 20 + random(31);
eLucro[e] += randomlucro;
new StringG[160];
format(StringG, sizeof(StringG), "{6959CD}%s ID %d\n{FFFF00}Dono(a): {FFFFFF}%s\n{FFFF00}Producao: {FFFFFF}%d\n{FFFF00}Lucro: {00FF00}$%d\n{FFFFFF}Use /Info Empresa", eNome[e], e, eDono[e], eProducao[e], eLucro[e]);
UpdateDynamic3DTextLabelText(TextoEmpresa[e], -1, StringG);
return 1;
}
}
}
return 1;
}
forward DescarregarTrem(playerid);
public DescarregarTrem(playerid)
{
CargaTrem[playerid] ++;
GameTextForPlayer(playerid, "~w~Descarregado", 2500, 4);
TogglePlayerControllable(playerid, 1);
if(CargaTrem[playerid] == 1)
{
SetPlayerRaceCheckpoint(playerid, 2, 1439.0928,2632.2500,12.3495, 1439.0928,2632.2500,12.3495, 10.0);
SendClientMessage(playerid, GetPlayerColor(playerid), "| FERROVIARIA | Siga para a estacao Yellow Bell para descarregar");
}
else if(CargaTrem[playerid] == 2)
{
SetPlayerRaceCheckpoint(playerid, 2, -1944.0966,138.1126,25.7109, -1944.0966,138.1126,25.7109, 10.0);
SendClientMessage(playerid, GetPlayerColor(playerid), "| FERROVIARIA | Siga para a estacao Cramberry para descarregar");
}
else if(CargaTrem[playerid] == 3)
{
DisablePlayerRaceCheckpoint(playerid);
new valor = 1900 + random(200);
Money[playerid] += valor;
format(String, sizeof(String), "| FERROVIARIA | Seu trem foi descarregado e voce recebeu {228B22}$%d", valor);
SendClientMessage(playerid, -1, String);
CargaTrem[playerid] = -1;
}
return 1;
}
forward Estacionando(playerid);
public Estacionando(playerid)
{
if(RotaBus[playerid] < 10)
{
format(String, sizeof(String), "| VIAGEM | Voce completou +1 rota ( %d/10 ), siga para a proxima parada!", RotaBus[playerid]);
SendClientMessage(playerid, GetPlayerColor(playerid), String);
}
else
{
SendClientMessage(playerid, GetPlayerColor(playerid), "| VIAGEM | Voce completou as 10 rotas da sua viagem, volte para a Rodoviaria de Bahia e digite /FinalizarViagem");
}
GameTextForPlayer(playerid, "Passageiros Embarcados", 2500, 3);
TogglePlayerControllable(playerid, 1);
return 1;
}
forward EntregarDinFazenda(playerid, valor);
public EntregarDinFazenda(playerid, valor)
{
TimerFuga[playerid] = 0;
format(String, sizeof(String), "| INFO | Fuga realizada com sucesso, voce roubou $%d", valor);
SendClientMessage(playerid, 0x00FF00FF, String);
Money[playerid] += valor;
return 1;
}
forward Velocimetro(playerid);
public Velocimetro(playerid)
{
if(IsPlayerConnected(playerid) && GetPlayerState(playerid) == PLAYER_STATE_DRIVER)
{
AttVelocimetro(playerid);
if(PROF[playerid] == TAXISTA && Passageiro[playerid] > -1)
{
if(IsPlayerInVehicle(Passageiro[playerid], GetPlayerVehicleID(playerid)))
{
UpTaxi[playerid] ++;
if(UpTaxi[playerid] >= 5)
{
if(Money[Passageiro[playerid]] > 0)
{
UpTaxi[playerid] = 0;
ValorCorrida[playerid] ++;
Money[Passageiro[playerid]] --;
Money[playerid] ++;
new StrT[30]; format(StrT, sizeof(StrT), "Valor_da_Corrida:_~g~$%d", ValorCorrida[playerid]);
PlayerTextDrawSetString(playerid, TextTaximetroP[playerid][0], StrT);
PlayerTextDrawSetString(Passageiro[playerid], TextTaximetroP[Passageiro[playerid]][0], StrT);
}
else
{
format(String, sizeof(String), "| CORRIDA | Seu passageiro %s[%d] nao tem dinheiro para continuar a corrida", PlayerName(Passageiro[playerid]), Passageiro[playerid]);
SendClientMessage(playerid, 0xFFFF00FF, String);
SendClientMessage(Passageiro[playerid], 0xFFFF00FF, "| CORRIDA | Voce nao tem dinheiro para pagar o taxista e sua corrida foi cancelada");
TextDrawHideForPlayer(playerid, TextTaximetro[0]); TextDrawHideForPlayer(playerid, TextTaximetro[1]); TextDrawHideForPlayer(Passageiro[playerid], TextTaximetro[0]); TextDrawHideForPlayer(Passageiro[playerid], TextTaximetro[1]);
PlayerTextDrawHide(playerid, TextTaximetroP[playerid][0]); PlayerTextDrawHide(playerid, TextTaximetroP[playerid][1]); PlayerTextDrawHide(Passageiro[playerid], TextTaximetroP[playerid][0]); PlayerTextDrawHide(Passageiro[playerid], TextTaximetroP[playerid][1]);
Passageiro[playerid] = -1;
}
}
}
else
{
if(IsPlayerConnected(Passageiro[playerid]))
{
format(String, sizeof(String), "| CORRIDA | Seu passageiro %s[%d] terminou a corrida com voce no valor de $%d", PlayerName(Passageiro[playerid]), Passageiro[playerid], ValorCorrida[playerid]);
SendClientMessage(playerid, 0xFFFF00FF, String);
format(String, sizeof(String), "| CORRIDA | Voce terminou a corrida com o Taxista %s[%d] no valor de $%d", PlayerName(playerid), playerid, ValorCorrida[playerid]);
SendClientMessage(Passageiro[playerid], 0xFFFF00FF, String);
TextDrawHideForPlayer(Passageiro[playerid], TextTaximetro[0]); TextDrawHideForPlayer(Passageiro[playerid], TextTaximetro[1]);
PlayerTextDrawHide(Passageiro[playerid], TextTaximetroP[playerid][0]); PlayerTextDrawHide(Passageiro[playerid], TextTaximetroP[playerid][1]);
}
else
{
SendClientMessage(playerid, 0xFFFF00FF, "| CORRIDA | Seu passageiro saiu do servidor e sua corrida foi terminada");
}
TextDrawHideForPlayer(playerid, TextTaximetro[0]); TextDrawHideForPlayer(playerid, TextTaximetro[1]);
PlayerTextDrawHide(playerid, TextTaximetroP[playerid][0]); PlayerTextDrawHide(playerid, TextTaximetroP[playerid][1]);
Passageiro[playerid] = -1;
}
}
SetTimerEx("Velocimetro", 100, false, "i", playerid);
}
else
{
if(IsPlayerConnected(playerid))
{
for(new t; t < 16; t++)
{
PlayerTextDrawHide(playerid, TextVelo[playerid][t]);
}
for(new m; m < 6; m++)
{
if(ModeloItem[playerid][m] == CAPACETE1 || ModeloItem[playerid][m] == CAPACETE2 || ModeloItem[playerid][m] == CAPACETE3 || ModeloItem[playerid][m] == CAPACETE4 || ModeloItem[playerid][m] == CAPACETE5)
{
RemovePlayerAttachedObject(playerid, m);
break;
}
}
if(PROF[playerid] == TAXISTA && Passageiro[playerid] > -1)
{
format(String, sizeof(String), "| CORRIDA | O(A) Taxista %s[%d] terminou a corrida com voce no valor de $%d", PlayerName(playerid), playerid, ValorCorrida[playerid]);
SendClientMessage(Passageiro[playerid], 0xFFFF00FF, String);
format(String, sizeof(String), "| CORRIDA | Voce terminou a corrida com o passageiro %s[%d] no valor de $%d", PlayerName(Passageiro[playerid]), Passageiro[playerid], ValorCorrida[playerid]);
SendClientMessage(playerid, 0xFFFF00FF, String);
TextDrawHideForPlayer(Passageiro[playerid], TextTaximetro[0]); TextDrawHideForPlayer(Passageiro[playerid], TextTaximetro[1]);
PlayerTextDrawHide(Passageiro[playerid], TextTaximetroP[playerid][0]); PlayerTextDrawHide(Passageiro[playerid], TextTaximetroP[playerid][1]);
TextDrawHideForPlayer(playerid, TextTaximetro[0]); TextDrawHideForPlayer(playerid, TextTaximetro[1]);
PlayerTextDrawHide(playerid, TextTaximetroP[playerid][0]); PlayerTextDrawHide(playerid, TextTaximetroP[playerid][1]);
Passageiro[playerid] = -1;
}
}
else
{
if(Passageiro[playerid] > -1)
{
SendClientMessage(Passageiro[playerid], 0xFFFF00FF, "| CORRIDA | Seu taxista saiu do servidor e sua corrida foi cancelada!");
TextDrawHideForPlayer(Passageiro[playerid], TextTaximetro[0]); TextDrawHideForPlayer(Passageiro[playerid], TextTaximetro[1]);
PlayerTextDrawHide(Passageiro[playerid], TextTaximetroP[playerid][0]); PlayerTextDrawHide(Passageiro[playerid], TextTaximetroP[playerid][1]);
Passageiro[playerid] = -1;
}
}
}
return 1;
}
stock AtualizarBTC(playerid)
{
new strm[70];
format(strm, sizeof(strm), "%d", ValorBTC[0]);
format(strm, sizeof(strm), "1_BTC_=_$%s", AttNumeroDecimal(strm));
TextDrawSetString(TextBTC[3], strm);
new mercado = (ValorBTC[0] - ValorBTC[1]) * 100 / ValorBTC[0];
if(mercado >= 0)
{
format(strm, sizeof(strm), "+%d%s", mercado, "%");
TextDrawSetString(TextBTC[4], strm);
TextDrawBoxColor(TextBTC[4], 0x00FF0077);
}
else
{
format(strm, sizeof(strm), "%d%s", mercado, "%");
TextDrawSetString(TextBTC[4], strm);
TextDrawBoxColor(TextBTC[4], 0xFF000077);
}
for(new t; t < 6; t++)
{
TextDrawShowForPlayer(playerid, TextBTC[t]);
}
format(strm, sizeof(strm), "%02.06f", BTC[playerid]);
PlayerTextDrawSetString(playerid, TextBTCP[playerid][0], strm);
new valor = floatround(floatmul(float(ValorBTC[0]), BTC[playerid]), floatround_round);
format(strm, sizeof(strm), "%d", valor); format(strm, sizeof(strm), "$%s", AttNumeroDecimal(strm));
PlayerTextDrawSetString(playerid, TextBTCP[playerid][1], strm);
for(new t; t < 2; t++)
{
PlayerTextDrawShow(playerid, TextBTCP[playerid][t]);
}
}
stock CountIP(const ip[])
{
new b = 0;
foreach(Player, i) if(IsPlayerConnected(i) && new_strcmp(GetIP(i), ip)) b++;
return b;
}
stock GetIP(playerid)
{
new ip[20];
GetPlayerIp(playerid,ip,sizeof(ip));
return ip;
}
stock Conectado(const nick[])
{
foreach(Player, i)
{
if(IsPlayerConnected(i) && Spawnado[i] == true && new_strcmp(PlayerName(i), nick)) return 1;
}
return 0;
}
stock MsgAvisoPerm(playerid, const msg[])
{
PlayerTextDrawSetString(playerid, MsgText[playerid], msg);
PlayerTextDrawShow(playerid, MsgText[playerid]);
}
stock MsgAviso(playerid, segundos, const msg[])
{
PlayerTextDrawSetString(playerid, MsgText[playerid], msg);
PlayerTextDrawShow(playerid, MsgText[playerid]);
SegundosAviso[playerid] = segundos;
}
stock GetPlayerVoltas(playerid)
{
new voltas; if(Mochila[playerid] == 0) voltas = 15; else if(Mochila[playerid] == 1) voltas = 30; else if(Mochila[playerid] == 2) voltas = 45;
return voltas;
}
stock BarracaProxima(playerid)
{
new Float:P[3], id = -1;
for(new i; i < 16; i++)
{
GetDynamicObjectPos(Barraquinha[i], P[0], P[1], P[2]);
if(IsPlayerInRangeOfPoint(playerid, 2.0, P[0], P[1], P[2]))
{
id = i;
break;
}
}
return id;
}
stock AtacharItem(playerid, idx, edit, plataforma)
{
switch(ModeloItem[playerid][idx])
{
case 8:
{
SetPlayerAttachedObject(playerid, idx, 339, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case 9:
{
SetPlayerAttachedObject(playerid, idx, 341, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case 22:
{
SetPlayerAttachedObject(playerid, idx, 346, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case 23:
{
SetPlayerAttachedObject(playerid, idx, 347, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case 24:
{
SetPlayerAttachedObject(playerid, idx, 348, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case 25:
{
SetPlayerAttachedObject(playerid, idx, 349, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case 26:
{
SetPlayerAttachedObject(playerid, idx, 350, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case 27:
{
SetPlayerAttachedObject(playerid, idx, 351, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case 28:
{
SetPlayerAttachedObject(playerid, idx, 352, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case 29:
{
SetPlayerAttachedObject(playerid, idx, 353, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case 30:
{
SetPlayerAttachedObject(playerid, idx, 355, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case 31:
{
SetPlayerAttachedObject(playerid, idx, 356, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case 34:
{
SetPlayerAttachedObject(playerid, idx, 358, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
case BONECA:
{
SetPlayerAttachedObject(playerid, idx, BONECA, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], 0.00200000, 0.05600002, 0.05599969, -1);
}
case TOURO:
{
SetPlayerAttachedObject(playerid, idx, TOURO, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], 0.14299957, 0.14399960, 0.14799986, -1);
}
case DRAGAO:
{
SetPlayerAttachedObject(playerid, idx, DRAGAO, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], 0.15199995, 0.11699979, 0.08700016, -1);
}
case COWBOY:
{
SetPlayerAttachedObject(playerid, idx, COWBOY, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], 0.00200000, 0.05799997, 0.05799983, -1);
}
case CORTAVENTO:
{
SetPlayerAttachedObject(playerid, idx, CORTAVENTO, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], 0.02400000, 0.02400000, 0.02299997, -1);
}
case TEXACO:
{
SetPlayerAttachedObject(playerid, idx, TEXACO, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], 0.04499997, 0.04700002, 0.03599956, -1);
}
case DRUNK:
{
SetPlayerAttachedObject(playerid, idx, DRUNK, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], 0.02600003, 0.02599996, 0.04, -1);
}
case DISCO:
{
SetPlayerAttachedObject(playerid, idx, DISCO, OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], 0.045, 0.045, 0.06, -1);
}
case BALAO1, BALAO2, BALAO3, BALAO4, BALAO5:
{
SetPlayerAttachedObject(playerid, idx, ModeloItem[playerid][idx], OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], 0.00999999, 0.00999999, 0.01299997, -1);
}
default:
{
SetPlayerAttachedObject(playerid, idx, ModeloItem[playerid][idx], OssoItem[playerid][idx], PosItem[playerid][idx][0], PosItem[playerid][idx][1], PosItem[playerid][idx][2], PosItem[playerid][idx][3], PosItem[playerid][idx][4], PosItem[playerid][idx][5], PosItem[playerid][idx][6], PosItem[playerid][idx][7], PosItem[playerid][idx][8], -1);
}
}
if(edit == 1 && plataforma == 0)
{
EditAttachedObject(playerid, idx);
}
if(edit == 1 && plataforma == 1)
{
new Float:Pos[2][3], Float:R;
GetPlayerPos(playerid, Pos[0][0], Pos[0][1], Pos[0][2]); GetPlayerPos(playerid, Pos[1][0], Pos[1][1], Pos[1][2]);
GetXYInFrontOfPlayer(playerid, Pos[0][0], Pos[0][1], 3.0);
GetPlayerFacingAngle(playerid, R);
SetPlayerCameraPos(playerid, Pos[0][0], Pos[0][1], Pos[0][2]+0.5);
SetPlayerCameraLookAt(playerid, Pos[1][0], Pos[1][1], Pos[1][2]+0.5, CAMERA_MOVE);
SetPlayerFacingAngle(playerid, R);
for(new t; t < 30; t++)
{
TextDrawShowForPlayer(playerid, TextCam[t]);
}
SelectTextDraw(playerid, 0xFFFFFF22);
}
}forward ConectarNaFrequencia(playerid, freq);
public ConectarNaFrequencia(playerid, freq){
FrequenciaConectada[playerid] = freq;
SvAttachListenerToStream(Frequencia[freq], playerid);
return 1;
}
stock InfoItem(playerid, item)
{
new mensagem[260];
switch(SlotMochila[playerid][item])
{
case 22:
{
mensagem = "{0040FF}ITEM: {FFFFFF}PISTOLA 9mm\n\n{2E9AFE}DESCRICAO: {FFFFFF}Armamento de fogo";
}
case 23:
{
mensagem = "{0040FF}ITEM: {FFFFFF}PISTOLA SILENCED\n\n{2E9AFE}DESCRICAO: {FFFFFF}Armamento de fogo";
}
case 24:
{
mensagem = "{0040FF}ITEM: {FFFFFF}DESERT EAGLE\n\n{2E9AFE}DESCRICAO: {FFFFFF}Armamento de fogo";
}
case 25:
{
mensagem = "{0040FF}ITEM: {FFFFFF}SHOTGUN\n\n{2E9AFE}DESCRICAO: {FFFFFF}Armamento de fogo";
}
case 26:
{
mensagem = "{0040FF}ITEM: {FFFFFF}SAWNOFF SHOTGUN\n\n{2E9AFE}DESCRICAO: {FFFFFF}Armamento de fogo";
}
case 27:
{
mensagem = "{0040FF}ITEM: {FFFFFF}COMBAT SHOTGUN\n\n{2E9AFE}DESCRICAO: {FFFFFF}Armamento de fogo";
}
case 28:
{
mensagem = "{0040FF}ITEM: {FFFFFF}MICRO SMG/UZI\n\n{2E9AFE}DESCRICAO: {FFFFFF}Armamento de fogo";
}
case 29:
{
mensagem = "{0040FF}ITEM: {FFFFFF}MP5\n\n{2E9AFE}DESCRICAO: {FFFFFF}Armamento de fogo";
}
case 30:
{
mensagem = "{0040FF}ITEM: {FFFFFF}AK\n\n{2E9AFE}DESCRICAO: {FFFFFF}Armamento de fogo";
}
case 31:
{
mensagem = "{0040FF}ITEM: {FFFFFF}M4\n\n{2E9AFE}DESCRICAO: {FFFFFF}Armamento de fogo";
}
case 34:
{
mensagem = "{0040FF}ITEM: {FFFFFF}SNIPER RIFLE\n\n{2E9AFE}DESCRICAO: {FFFFFF}Armamento de fogo";
}
case XBURGER:
{
mensagem = "{0040FF}ITEM: {FFFFFF}X-BURGER\n\n{2E9AFE}DESCRICAO: {FFFFFF}Alimento que ao consumido aumenta 25 por cento da sua fome";
}
case XBACON:
{
mensagem = "{0040FF}ITEM: {FFFFFF}X-BACON\n\n{2E9AFE}DESCRICAO: {FFFFFF}Alimento que ao consumido aumenta 30 por cento da sua fome";
}
case XTUDO:
{
mensagem = "{0040FF}ITEM: {FFFFFF}X-TUDO\n\n{2E9AFE}DESCRICAO: {FFFFFF}Alimento que ao consumido aumenta 45 por cento da sua fome";
}
case PIZZA:
{
mensagem = "{0040FF}ITEM: {FFFFFF}PIZZA\n\n{2E9AFE}DESCRICAO: {FFFFFF}Alimento que ao consumido aumenta 100 por cento da sua fome";
}
case COCA:
{
mensagem = "{0040FF}ITEM: {FFFFFF}COCA-COLA\n\n{2E9AFE}DESCRICAO: {FFFFFF}Alimento que ao consumido aumenta 100 por cento da sua sede";
}
case FANTA:
{
mensagem = "{0040FF}ITEM: {FFFFFF}FANTA\n\n{2E9AFE}DESCRICAO: {FFFFFF}Alimento que ao consumido aumenta 50 por cento da sua sede";
}
case GUARANA:
{
mensagem = "{0040FF}ITEM: {FFFFFF}GUARANA\n\n{2E9AFE}DESCRICAO: {FFFFFF}Alimento que ao consumido aumenta 50 por cento da sua sede";
}
case SUCO:
{
mensagem = "{0040FF}ITEM: {FFFFFF}SUCO\n\n{2E9AFE}DESCRICAO: {FFFFFF}Alimento que ao consumido aumenta 30 por cento da sua sede";
}
case HEINEKEN:
{
mensagem = "{0040FF}ITEM: {FFFFFF}HEINEKEN\n\n{2E9AFE}DESCRICAO: {FFFFFF}Bebida alcoolica que ao consumida aumenta 20 por cento da sede\n{81BEF7}Teor Alcoolico: {FFFFFF}+50/100";
}
case BUDWEISER:
{
mensagem = "{0040FF}ITEM: {FFFFFF}BUDWEISER\n\n{2E9AFE}DESCRICAO: {FFFFFF}Bebida alcoolica que ao consumida aumenta 20 por cento da sede\n{81BEF7}Teor Alcoolico: {FFFFFF}+40/100";
}
case WHISKY:
{
mensagem = "{0040FF}ITEM: {FFFFFF}WHISKY\n\n{2E9AFE}DESCRICAO: {FFFFFF}Bebida alcoolica que ao consumida aumenta 20 por cento da sede\n{81BEF7}Teor Alcoolico: {FFFFFF}+80/100";
}
case VODKA:
{
mensagem = "{0040FF}ITEM: {FFFFFF}VODKA\n\n{2E9AFE}DESCRICAO: {FFFFFF}Bebida alcoolica que ao consumida aumenta 20 por cento da sede\n{81BEF7}Teor Alcoolico: {FFFFFF}+90/100";
}
case VINHO:
{
mensagem = "{0040FF}ITEM: {FFFFFF}VINHO\n\n{2E9AFE}DESCRICAO: {FFFFFF}Bebida alcoolica que ao consumida aumenta 20 por cento da sede\n{81BEF7}Teor Alcoolico: {FFFFFF}+20/100";
}
case ENERGETICO:
{
mensagem = "{0040FF}ITEM: {FFFFFF}ENERGETICO\n\n{2E9AFE}DESCRICAO: {FFFFFF}Bebida energetica que ao consumida aumenta 20 por cento da sede\n{81BEF7}Teor Alcoolico: {FFFFFF}+0/100\n{81BEF7}Perca de sono: {FFFFFF}-20/100\n{81BEF7}Efeito Colateral: {FFFFFF}-10/100 de vida";
}
case CIGARRODEMACONHA:
{
mensagem = "{0040FF}ITEM: {FFFFFF}CIGARRO DE MACONHA\n\n{2E9AFE}DESCRICAO: {FFFFFF}Uma droga que pode ser comercializada e consumida\nrecuperando +30 de colete";
}
case PLANTADEMACONHA:
{
mensagem = "{0040FF}ITEM: {FFFFFF}PLANTA DE MACONHA\n\n{2E9AFE}DESCRICAO: {FFFFFF}Item produzido pelas organizacoes criminosas que sao usados para fazer cigarros de maconha";
}
case FERRAMENTAS:
{
mensagem = "{0040FF}ITEM: {FFFFFF}CAIXA DE FERRAMENTAS\n\n{2E9AFE}DESCRICAO: {FFFFFF}Item utilizado para reparar veiculos proximos, atraves do comando /Consertar";
}
case GALAO:
{
mensagem = "{0040FF}ITEM: {FFFFFF}GALAO DE COMBUSTIVEL\n\n{2E9AFE}DESCRICAO: {FFFFFF}Item utilizado para abastecer veiculos proximos com 10 litros de combustivel\natraves da tecla H";
}
case MATERIAISPRONTO:
{
mensagem = "{0040FF}ITEM: {FFFFFF}MATERIAIS\n\n{2E9AFE}DESCRICAO: {FFFFFF}Item produzido pelas organizacoes criminosas que sao usados para fabricar de armas de fogo";
}
case VEADO:
{
mensagem = "{0040FF}ITEM: {FFFFFF}CARNE DE VEADO\n\n{2E9AFE}DESCRICAO: {FFFFFF}Esse e um  animal que os Cacadores matam para serem vendidos nos supermercados 24/7\nlocalizado com um copo rosa no mapa";
}
case 1608:
{
mensagem = "{0040FF}ITEM: {FFFFFF}TUBARAO\n\n{2E9AFE}DESCRICAO: {FFFFFF}Esse e um  animal capiturado pelos pescadores que podem ser vendidos nos supermercados 24/7\nlocalizado como com um rosa no mapa";
}
case 1600:
{
mensagem = "{0040FF}ITEM: {FFFFFF}TUCUNARE AZUL\n\n{2E9AFE}DESCRICAO: {FFFFFF}Esse e um  animal capiturado pelos pescadores que podem ser vendidos nos supermercados 24/7\nlocalizado com um copo rosa no mapa";
}
case 19630:
{
mensagem = "{0040FF}ITEM: {FFFFFF}TILAPIA\n\n{2E9AFE}DESCRICAO: {FFFFFF}Esse e um  animal capiturado pelos pescadores que podem ser vendidos nos supermercados 24/7\nlocalizado com um copo rosa no mapa";
}
case 1604:
{
mensagem = "{0040FF}ITEM: {FFFFFF}PACU\n\n{2E9AFE}DESCRICAO: {FFFFFF}Esse e um  animal capiturado pelos pescadores que podem ser vendidos nos supermercados 24/7\nlocalizado com um copo rosa no mapa";
}
case 1599:
{
mensagem = "{0040FF}ITEM: {FFFFFF}DOURADO\n\n{2E9AFE}DESCRICAO: {FFFFFF}Esse e um  animal capiturado pelos pescadores que podem ser vendidos nos supermercados 24/7\nlocalizado com um copo rosa no mapa";
}
case DINAMITE:
{
mensagem = "{0040FF}ITEM: {FFFFFF}DINAMITE\n\n{2E9AFE}DESCRICAO: {FFFFFF}Plante essa dinamite e crie uma explosao no local";
}
case PANELA:
{
mensagem = "{0040FF}ITEM: {FFFFFF}PANELA\n\n{2E9AFE}DESCRICAO: {FFFFFF}Acessorio que alem de vestir seu personagem tambem te protege de head shot";
}
case LUZAZUL:
{
mensagem = "{0040FF}ITEM: {FFFFFF}LUZ AZUL\n\n{2E9AFE}DESCRICAO: {FFFFFF}Acessorio SEMI RARO para vestir seu personagem";
}
case LUZVERMELHA:
{
mensagem = "{0040FF}ITEM: {FFFFFF}LUZ VERMELHA\n\n{2E9AFE}DESCRICAO: {FFFFFF}Acessorio SEMI RARO para vestir seu personagem";
}
case FOGO:
{
mensagem = "{0040FF}ITEM: {FFFFFF}FOGO\n\n{2E9AFE}DESCRICAO: {FFFFFF}Acessorio SEMI RARO para vestir seu personagem";
}
case 10:
{
mensagem = "{0040FF}ITEM: {FFFFFF}MERCADORIA BS\n\n{2E9AFE}DESCRICAO: {FFFFFF}Entregue essa mercadoria na empresa que voce trabalha, use /LocalizarEmpresa ID";
}
default:
{
mensagem = "{0040FF}ITEM: {FFFFFF}ACESSORIO\n\n{2E9AFE}DESCRICAO: {FFFFFF}Acessorio para vestir seu personagem";
}
}
ShowPlayerDialog(playerid, 555, DIALOG_STYLE_MSGBOX, "{FFFFFF}Info Item", mensagem, "Entendi", "Fechar");
}
stock VenderItem(playerid, item, b, i)
{
new result;
switch(SlotMochila[playerid][item])
{
case FOGO, LUZVERMELHA, LUZAZUL:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]-1.8, 0, 0, -90);
}
case FACA, GORRO:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]-0.17, 0, 0, 180);
}
case TARTARUGA:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]+0.1, 0, 0, 90);
}
case TOCACLUCKINBELL:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]-0.15, 0, -90, 90);
}
case GUITARRA1, GUITARRA2, GUITARRA3:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]+0.40, 0, 0, -90);
}
case PRANCHA1, PRANCHA2:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]+0.87, 0, 0, -90);
}
case BOLA:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]-0.051, 0, 0, -90);
}
case ESTRELA:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]-0.4, 0, 0, -90);
}
case CIRCULOCHAMATIVO, MASCARADIABO:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2], 0, 0, -90);
}
case CAVEIRA, DINAMITE, PINTODEBORRACHA:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]-0.15, 0, 0, -90);
}
case BONEPOLICIA, OCULOS1,OCULOS2,OCULOS3,OCULOS4,OCULOS5,OCULOS6,OCULOS7,OCULOS8,OCULOS9,OCULOS10,OCULOS11,OCULOS12,OCULOS13,OCULOS14,
OCULOS15,OCULOS16,OCULOS17,OCULOS18,OCULOS19,OCULOS20,OCULOS21,OCULOS22,OCULOS23,OCULOS24,OCULOS25,OCULOS26,OCULOS27,OCULOS28,OCULOS29,OCULOS30,
OCULOS31,OCULOS32,OCULOS33, CHAPEU7,CHAPEU8,CHAPEU9,CHAPEU10,CHAPEU11,CHAPEU12,CAPACETE1,CAPACETE2,CAPACETE3,CAPACETE4,CAPACETE5,BASTAO,CHAPEU13,SKATE:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]-0.25, 0, 0, 0);
}
case CORACAO, LANTERNA, MARTELO,COLETEPOLICE,COLETE:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]-0.25, -90, 0, 0);
}
case PANELA:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]-0.15, 0, 0, 0);
}
case MOCHILA, PA, BANDANA1,BANDANA2,BANDANA3,BANDANA4,BANDANA5,BANDANA6,BANDANA7,BANDANA8,BANDANA9,
BANDANA10,BANDANA11,BANDANA12,BANDANA13,BANDANA14,BANDANA15,BANDANA16,BANDANA17,BANDANA18,BANDANA19,
BOINA1,BOINA2,BOINA3,BOINA4,TOCA1,TOCA2,TOCA3,TOCA4,TOCA5,TOCA6,TOCA7,TOCA8,TOCA9,TOCA10,TOCA11,TOCA12,
TOCA13,TOCA14,TOCA15,TOCA16,TOCA17,TOCA18,TOCA19,TOCA20,CHAPEUGUTE,PEDECABRA,BONE1,BONE2,BONE3,BONE4,BONE5,
BONE6,BONE7,BONE8,BONE9,BONE10,BONE11,BONE12,BONE13,BONE14,BONE15,BONEGUTE,CHAPEU1,CHAPEU2,CHAPEU3,CHAPEU4,
CHAPEU5,CHAPEU6,MASCARA1,MASCARA2,MASCARA3,MASCARA4,MASCARA5,MASCARA6,ARARA,BANDANA20,BANDANA21,BANDANA22,
BANDANA23,BANDANA24,BANDANA25,BANDANA26,BANDANA27,BANDANA28,BANDANA29,RINGMASTER,TOCA21,TOCA22,TOCA23,BONE17:
{
result = 1;
ItemBarraquinha[b][i] = CreateDynamicObject(SlotMochila[playerid][item], PosBarraquinhas[b][i][0], PosBarraquinhas[b][i][1], PosBarraquinhas[b][i][2]-0.25, 0, -90, 0);
}
}
if(result == 1)
{
ItemDaBarraquinha[playerid] = i;
CoinsItemBarraquinha[b][i] = 989898;
QuantidadeSlotMochila[playerid][item] --; if(QuantidadeSlotMochila[playerid][item] <= 0) SlotMochila[playerid][item] = 0;
ShowPlayerDialog(playerid, D_VALORITEM, DIALOG_STYLE_INPUT, "{FFFFFF}Valor do Item", "{FFFFFF}Digite o {088A08}valor {FFFFFF}do item que voce esta vendendo", "Selecionar", "Selecionar");
Streamer_Update(playerid);
for(new t; t < 27; t++)
{
TextDrawHideForPlayer(playerid, TextInv[t]);
}
for(new t; t < 46; t++)
{
PlayerTextDrawHide(playerid, TextInvP[playerid][t]);
}
CancelSelectTextDraw(playerid);
}
else
{
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], -2071690155);
PlayerTextDrawShow(playerid,TextInvP[playerid][SlotSelecionado[playerid]]);
SlotSelecionado[playerid] = -1;
ItemSelecionado[playerid] = -1;
PaginaSelecionada[playerid] = -1;
MsgAviso(playerid, 3, "~r~Esse item nao pode ser vendido");
return 1;
}
return 1;
}
stock DroparItem(playerid, item)
{
new result;
for(new i; i < MAX_ITEM; i++)
{
if(Item[i] == 0)
{
new Float:P[4]; GetPlayerPos(playerid, P[0], P[1], P[2]); GetXYInFrontOfPlayer(playerid, P[0], P[1], 0.7); GetPlayerFacingAngle(playerid, P[3]);
switch(SlotMochila[playerid][item])
{
case 8, 339:
{
Item[i] = CreateDynamicObject(339, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Katana\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case 9, 341:
{
Item[i] = CreateDynamicObject(341, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Motoserra\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case 22:
{
Item[i] = CreateDynamicObject(346, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Pistola 9mm\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case 23:
{
Item[i] = CreateDynamicObject(347, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Silenced 9mm\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case 24:
{
Item[i] = CreateDynamicObject(348, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Desert Eagle\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case 25:
{
Item[i] = CreateDynamicObject(349, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Shotgun\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case 26:
{
Item[i] = CreateDynamicObject(350, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Sawnoff Shotgun\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case 27:
{
Item[i] = CreateDynamicObject(351, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Combat Shotgun\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case 28:
{
Item[i] = CreateDynamicObject(352, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}UZI\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case 29:
{
Item[i] = CreateDynamicObject(353, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}MP5\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case 30:
{
Item[i] = CreateDynamicObject(355, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}AK-47\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case 31:
{
Item[i] = CreateDynamicObject(356, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}M4\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case 34:
{
Item[i] = CreateDynamicObject(358, P[0], P[1], P[2]-0.99, 90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Sniper Rifle\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
SlotMochila[playerid][item] = 0; QuantidadeItem[i] = QuantidadeSlotMochila[playerid][item]; QuantidadeSlotMochila[playerid][item] = 0;
}
case PLANTADEMACONHA:
{
Item[i] = CreateDynamicObject(PLANTADEMACONHA, P[0], P[1], P[2]-1.2, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Planta de Maconha\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.3, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case CIGARRODEMACONHA:
{
Item[i] = CreateDynamicObject(CIGARRODEMACONHA, P[0], P[1], P[2]-0.8, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Baseado\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case GALAO:
{
Item[i] = CreateDynamicObject(GALAO, P[0], P[1], P[2]-0.7, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Galao\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.4, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case XBURGER:
{
Item[i] = CreateDynamicObject(XBURGER, P[0], P[1], P[2]-0.9, -16.8, -88.8, 2.3);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}X-Burger\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case XTUDO:
{
Item[i] = CreateDynamicObject(XTUDO, P[0], P[1], P[2]-0.99, -22.5, -79.7, -2.2);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}X-Tudo\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case XBACON:
{
Item[i] = CreateDynamicObject(XBACON, P[0], P[1], P[2]-0.9, -102.6, 86.7, -67);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}X-Bacon\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case PIZZA:
{
Item[i] = CreateDynamicObject(PIZZA, P[0], P[1], P[2]-0.99, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Pizza\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.7, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case COCA:
{
Item[i] = CreateDynamicObject(COCA, P[0], P[1], P[2]-0.99, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Coca-Cola\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.3, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case FANTA:
{
Item[i] = CreateDynamicObject(FANTA, P[0], P[1], P[2]-0.99, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Fanta Uva\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.2, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case GUARANA:
{
Item[i] = CreateDynamicObject(GUARANA, P[0], P[1], P[2]-0.8, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Guarana\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.4, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case SUCO:
{
Item[i] = CreateDynamicObject(SUCO, P[0], P[1], P[2]-0.99, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Suco\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.5, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case HEINEKEN:
{
Item[i] = CreateDynamicObject(HEINEKEN, P[0], P[1], P[2]-0.8, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Heineken\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.4, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case BUDWEISER:
{
Item[i] = CreateDynamicObject(BUDWEISER, P[0], P[1], P[2]-0.99, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Budweiser\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.4, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case WHISKY:
{
Item[i] = CreateDynamicObject(WHISKY, P[0], P[1], P[2]-0.99, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Whisky\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.5, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case VODKA:
{
Item[i] = CreateDynamicObject(VODKA, P[0], P[1], P[2]-0.8, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Vodka\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.45, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case ENERGETICO:
{
Item[i] = CreateDynamicObject(ENERGETICO, P[0], P[1], P[2]-0.99, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Energetico\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.35, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case VINHO:
{
Item[i] = CreateDynamicObject(VINHO, P[0], P[1], P[2]-0.99, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Vinho\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.35, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case FERRAMENTAS:
{
Item[i] = CreateDynamicObject(FERRAMENTAS, P[0], P[1], P[2]-0.9, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Ferramentas\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.5, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case KITMEDICO:
{
Item[i] = CreateDynamicObject(KITMEDICO, P[0], P[1], P[2]-0.9, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Kit-Medico\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.5, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case CAVEIRA:
{
Item[i] = CreateDynamicObject(CAVEIRA, P[0], P[1], P[2]-0.9, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Caveira\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.5, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case CORACAO:
{
Item[i] = CreateDynamicObject(CORACAO, P[0], P[1], P[2]-0.9, -90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Coracao\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case DINAMITE:
{
Item[i] = CreateDynamicObject(DINAMITE, P[0], P[1], P[2]-0.9, 0.0, -90.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Dinamite\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case PA:
{
Item[i] = CreateDynamicObject(PA, P[0], P[1], P[2]-0.9, -270.0, -90.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}PA\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case PINTODEBORRACHA:
{
Item[i] = CreateDynamicObject(PINTODEBORRACHA, P[0], P[1], P[2]-0.7, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Chainsaw-Penis\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.5, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case BANDANA1,BANDANA2,BANDANA3,BANDANA4,BANDANA5,BANDANA6,BANDANA7,BANDANA8,BANDANA9,
BANDANA10,BANDANA11,BANDANA12,BANDANA13,BANDANA14,BANDANA15,BANDANA16,BANDANA17,BANDANA18,BANDANA19,
BANDANA20, BANDANA21, BANDANA22, BANDANA23, BANDANA24, BANDANA25, BANDANA26, BANDANA27, BANDANA28, BANDANA29:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, 0.0, -90.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Bandana\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case BOINA1,BOINA2,BOINA3,BOINA4:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, 0.0, -90.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Boina\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case TOCA1,TOCA2,TOCA3,TOCA4,TOCA5,TOCA6,TOCA7,TOCA8,TOCA9,TOCA10,TOCA11,TOCA12,TOCA13,TOCA14,TOCA15,TOCA16,TOCA17,TOCA18,TOCA19,TOCA20,
RINGMASTER, TOCA21, TOCA22, TOCA23:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, 0.0, -90.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Toca\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case CHAPEUGUTE:
{
Item[i] = CreateDynamicObject(CHAPEUGUTE, P[0], P[1], P[2]-0.9, 0.0, -90.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Bone\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case BONEPOLICIA:
{
Item[i] = CreateDynamicObject(BONEPOLICIA, P[0], P[1], P[2]-0.9, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Bone de Policia\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case LANTERNA:
{
Item[i] = CreateDynamicObject(LANTERNA, P[0], P[1], P[2]-0.9, -90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Lanterna\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case PEDECABRA:
{
Item[i] = CreateDynamicObject(PEDECABRA, P[0], P[1], P[2]-0.9, 0.0, -90.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Pa de Cabra\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case MARTELO:
{
Item[i] = CreateDynamicObject(MARTELO, P[0], P[1], P[2]-0.9, -90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Martelo\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case OCULOS1,OCULOS2,OCULOS3,OCULOS4,OCULOS5,OCULOS6,OCULOS7,OCULOS8,OCULOS9,OCULOS10,OCULOS11,OCULOS12,OCULOS13,OCULOS14,
OCULOS15,OCULOS16,OCULOS17,OCULOS18,OCULOS19,OCULOS20,OCULOS21,OCULOS22,OCULOS23,OCULOS24,OCULOS25,OCULOS26,OCULOS27,OCULOS28,OCULOS29,OCULOS30,
OCULOS31,OCULOS32,OCULOS33:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}oculos\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case BONE1,BONE2,BONE3,BONE4,BONE5,BONE6,BONE7,BONE8,BONE9,BONE10,BONE11,BONE12,BONE13,BONE14,BONE15,BONEGUTE, BONE17:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, 0.0, -90.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Bone\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case CHAPEU1,CHAPEU2,CHAPEU3,CHAPEU4,CHAPEU5,CHAPEU6:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, 0.0, -90.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Chapeu\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case CHAPEU7,CHAPEU8,CHAPEU9,CHAPEU10,CHAPEU11,CHAPEU12,CHAPEU13:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Chapeu\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case CAPACETE1,CAPACETE2,CAPACETE3,CAPACETE4,CAPACETE5:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Capacete\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case BASTAO:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, -0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Bastao\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case MASCARA1, MASCARA2, MASCARA3, MASCARA4, MASCARA5,MASCARA6:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, -0.0, -90.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Mascara\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.6, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case PANELA:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.8, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Panela\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.5, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case COLETEPOLICE:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, -90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Colete Police\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.4, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case ESTRELA:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-1.0, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Estrela do mar\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.4, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case BOLA:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.7, 0.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Bola\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.4, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case COLETE:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, -90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Colete\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.4, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
case LOCKPICK:
{
Item[i] = CreateDynamicObject(SlotMochila[playerid][item], P[0], P[1], P[2]-0.9, -90.0, 0.0, -P[3]);
TextoItem[i] = CreateDynamic3DTextLabel("{00FF00}Lock Pick\n{FFFFFF}Pressione ALT para pegar", 0x2EFE2EFF, P[0], P[1], P[2]-0.4, 3.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1);
result = 1;
}
default:
{
result = -1;
MsgAviso(playerid, 3, "~r~ESSE ITEM NAO PODE SER DROPADO");
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], -2071690155);
ItemPreviewRot(playerid, SlotMochila[playerid][ItemSelecionado[playerid]], TextInvP[playerid][SlotSelecionado[playerid]]);
PlayerTextDrawShow(playerid,TextInvP[playerid][SlotSelecionado[playerid]]);
SlotSelecionado[playerid] = -1;
ItemSelecionado[playerid] = -1;
PaginaSelecionada[playerid] = -1;
}
}
Streamer_Update(playerid);
if(result == 1)
{
QuantidadeSlotMochila[playerid][item] --;
if(QuantidadeSlotMochila[playerid][item] <= 0)
{
SlotMochila[playerid][item] = 0;
}
}
if(result != -1)
{
ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0, 1);
for(new t; t < 21; t++)
{
TextDrawHideForPlayer(playerid, TextInv[t]);
}
for(new t; t < 46; t++)
{
PlayerTextDrawHide(playerid, TextInvP[playerid][t]);
}
CancelSelectTextDraw(playerid);
}
return 1;
}
}
MsgAviso(playerid, 3, "~r~O servidor atingiu o limite de itens dropados");
return 1;
}
stock UsarItem(playerid, item)
{
new result;
switch(SlotMochila[playerid][item])
{
case 8, 9:
{
GivePlayerWeaponExC(playerid, SlotMochila[playerid][item], QuantidadeSlotMochila[playerid][item]);
SlotMochila[playerid][item] = 0; QuantidadeSlotMochila[playerid][item] = 0;
result = 2;
}
case 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 34:
{
GivePlayerWeaponExC(playerid, SlotMochila[playerid][item], QuantidadeSlotMochila[playerid][item]);
ApplyAnimation(playerid, "RIFLE", "RIFLE_LOAD", 4.1, 0, 0, 0, 0, 0, 1);
SlotMochila[playerid][item] = 0; QuantidadeSlotMochila[playerid][item] = 0;
result = 2;
}
case XBURGER:
{
SegurandoMao[playerid] = XBURGER;
SetPlayerAttachedObject(playerid, 5, 19094, 6, 0.0469, 0.0639, 0.0219, 139.9000, -162.8998, 31.0000, 0.5160, 0.4320, 0.4860, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar um X-Burger, pressione F para comer ou digite /guardar para guarda-lo no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case XBACON:
{
SegurandoMao[playerid] = XBACON;
SetPlayerAttachedObject(playerid, 5, 2880, 6, 0.0870, 0.1559, -0.0589, 139.9000, -162.8998, 31.0000, 1.0900, 0.9839, 0.9290, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar um X-Bacon, pressione F para comer ou digite /guardar para guarda-lo no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case XTUDO:
{
SegurandoMao[playerid] = XTUDO;
SetPlayerAttachedObject(playerid, 5, 2880, 6, 0.0870, 0.1559, -0.0589, 139.9000, -162.8998, 31.0000, 1.0900, 0.9839, 0.9290, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar um X-Tudo, pressione F para comer ou digite /guardar para guarda-lo no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case PIZZA:
{
SegurandoMao[playerid] = PIZZA;
SetPlayerAttachedObject(playerid, 5, 19580, 6, 0.0850, 0.0819, 0.0170, 132.8000, -79.3999, 50.9000, 0.4570, 0.4510, 0.9290, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar uma Pizza, pressione F para comer ou digite /guardar para guarda-la no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case COCA:
{
SegurandoMao[playerid] = COCA;
SetPlayerAttachedObject(playerid, 5, 19822, 5, 0.1480, 0.1519, 0.1319, 142.9002, -17.5999, 58.7000, 0.5250, 0.5659, 0.5980, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar uma Coca-Cola, pressione F para beber ou digite /guardar para guarda-la no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case FANTA:
{
SegurandoMao[playerid] = FANTA;
SetPlayerAttachedObject(playerid, 5, 19821, 5, 0.1480, 0.1519, 0.1319, 142.9002, -17.5999, 58.7000, 0.5250, 0.5659, 0.5980, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar uma Fanta Uva, pressione F para beber ou digite /guardar para guarda-la no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case GUARANA:
{
SegurandoMao[playerid] = GUARANA;
SetPlayerAttachedObject(playerid, 5, 1517, 5, 0.0999, 0.0539, -0.0360, 142.9002, -17.5999, 58.7000, 0.5250, 0.5659, 0.5980, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar um Guarana, pressione F para beber ou digite /guardar para guarda-lo no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case SUCO:
{
SegurandoMao[playerid] = SUCO;
SetPlayerAttachedObject(playerid, 5, 19563, 5, 0.1330, 0.1169, 0.0809, 148.5004, -14.0999, 80.9000, 0.6020, 0.8609, 0.7860, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar um Suco, pressione F para beber ou digite /guardar para guarda-lo no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case HEINEKEN:
{
SegurandoMao[playerid] = HEINEKEN;
SetPlayerAttachedObject(playerid, 5, HEINEKEN, 5, 0.14699, 0.04999, 0.08400, 155.00013, -26.60000, -61.19997, 1.0, 1.0, 1.0, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar uma Heineken, pressione F para beber ou digite /guardar para guarda-lo no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case BUDWEISER:
{
SegurandoMao[playerid] = BUDWEISER;
SetPlayerAttachedObject(playerid, 5, BUDWEISER, 5, 0.0959, 0.1570, 0.2059, 150.100, 0.0, 0.0, 1.0, 1.0, 1.0, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar uma Budweiser, pressione F para beber ou digite /guardar para guarda-lo no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case WHISKY:
{
SegurandoMao[playerid] = WHISKY;
SetPlayerAttachedObject(playerid, 5, WHISKY, 5, 0.0959, 0.1570, 0.2059, 150.100, 0.0, 0.0, 1.0, 1.0, 1.0, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar uma Whisky, pressione F para beber ou digite /guardar para guarda-lo no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case VODKA:
{
SegurandoMao[playerid] = VODKA;
SetPlayerAttachedObject(playerid, 5, VODKA, 5, 0.05499, 0.0790, -0.01100, 142.7999, 14.000, 0.0, 1.0, 1.0, 1.0, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar uma Vodka, pressione F para beber ou digite /guardar para guarda-lo no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case ENERGETICO:
{
SegurandoMao[playerid] = ENERGETICO;
SetPlayerAttachedObject(playerid, 5, ENERGETICO, 5, 0.1659, 0.1750, 0.4430, 162.200, -5.1999, 2.4000, 1.0, 1.0, 1.0, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar um Energetico, pressione F para beber ou digite /guardar para guarda-lo no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case VINHO:
{
SegurandoMao[playerid] = VINHO;
SetPlayerAttachedObject(playerid, 5, VINHO, 5, 0.15199, 0.2239, 0.2950, 148.600, -5.19999, 2.4000, 1.0, 1.0, 1.0, 0xFFFFFFFF, 0xFFFFFFFF);
SendClientMessage(playerid, -1, "| INFO | Voce acaba de pegar um Vinho, pressione F para beber ou digite /guardar para guarda-lo no inventario");
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case CIGARRODEMACONHA:
{
SendClientMessage(playerid, -1, "| INFO | Voce esta fumando 1 cigarro de maconha");
if(GetPlayerSpecialAction(playerid) == SPECIAL_ACTION_NONE)
{
SetPlayerSpecialAction(playerid, SPECIAL_ACTION_SMOKE_CIGGY);
}
ApplyAnimation(playerid,"SMOKING", "M_SMK_IN", 4.1, 0, 0, 0, 0, 0, 1);
new Float:Colete; GetPlayerArmour(playerid, Colete);
SetPlayerArmour(playerid, Colete + 50.0);
if(Colete > 100.0)
{
SetPlayerArmour(playerid, 100.0);
new NivelBebado = GetPlayerDrunkLevel(playerid);
SetPlayerDrunkLevel(playerid, NivelBebado + 5000 + random(5001));
}
result = 1;
}
case CAVEIRA,CORACAO,PA,PINTODEBORRACHA,BANDANA1,BANDANA2,BANDANA3,BANDANA4,BANDANA5,BANDANA6,BANDANA7,BANDANA8,BANDANA9,
BANDANA10,BANDANA11,BANDANA12,BANDANA13,BANDANA14,BANDANA15,BANDANA16,BANDANA17,BANDANA18,BANDANA19,BANDANA20,BANDANA21,BANDANA22,
BANDANA23,BANDANA24,BANDANA25,BANDANA26,BANDANA27,BANDANA28,BANDANA29,BOINA1,BOINA2,BOINA3,BOINA4,TOCA1,TOCA2,RINGMASTER,CHAPEUGUTE,BONEPOLICIA,
TOCA3,TOCA4,TOCA5,TOCA6,TOCA7,TOCA8,TOCA9,TOCA10,TOCA11,TOCA12,TOCA13,TOCA14,TOCA15,TOCA16,TOCA17,TOCA18,TOCA19,TOCA21,TOCA22,TOCA23,BONE17,
LANTERNA,PEDECABRA,MARTELO,OCULOS1,OCULOS2,OCULOS3,OCULOS4,OCULOS5,OCULOS6,OCULOS7,OCULOS8,OCULOS9,OCULOS10,OCULOS11,OCULOS12,OCULOS13,OCULOS14,
OCULOS15,OCULOS16,OCULOS17,OCULOS18,OCULOS19,OCULOS20,OCULOS21,OCULOS22,OCULOS23,OCULOS24,OCULOS25,OCULOS26,OCULOS27,OCULOS28,OCULOS29,OCULOS30,
OCULOS31,OCULOS32,OCULOS33,BONE1,BONE2,BONE3,BONE4,BONE5,BONE6,BONE7,BONE8,BONE9,BONE10,BONE11,BONE12,BONE13,BONE14,BONE15,BONEGUTE,CHAPEU1,CHAPEU13,MASCARA6,
CHAPEU2,CHAPEU3,CHAPEU4,CHAPEU5,CHAPEU6,CHAPEU7,CHAPEU8,CHAPEU9,CHAPEU10,CHAPEU11,CHAPEU12,CAPACETE1,CAPACETE2,CAPACETE3,CAPACETE4,CAPACETE5,PANELA,
ESTRELA,BOLA,ARARA,MOCHILA,FACA,FOGO,LUZVERMELHA,LUZAZUL,CIRCULOCHAMATIVO,TARTARUGA,PRANCHA1,PRANCHA2,TOCACLUCKINBELL,MASCARADIABO,GORRO,GUITARRA1,GUITARRA2,GUITARRA3:
{
MsgAviso(playerid, 4, "~g~~h~Para usar esse item arraste ele para o lado esquerdo do inventario"),
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], -2071690155);
ItemPreviewRot(playerid, SlotMochila[playerid][ItemSelecionado[playerid]], TextInvP[playerid][SlotSelecionado[playerid]]);
PlayerTextDrawShow(playerid,TextInvP[playerid][SlotSelecionado[playerid]]);
SlotSelecionado[playerid] = -1;
ItemSelecionado[playerid] = -1;
PaginaSelecionada[playerid] = -1;
}
case DINAMITE:
{
PlayerIdBanco[playerid] = EntrouBanco[playerid];
GameTextForPlayer(playerid, "~r~DINAMITE PLANTADA!", 3000, 3);
SendClientMessage(playerid, -1, "| DINAMITE | Afaste-se do local, a dinamite ira explodir!");
if(IsPlayerInRangeOfPoint(playerid, 8.0, -31.381217, -26.194713, 1261.542236))
{
SendClientMessage(playerid, -1, "| INFO | O Assalto sera realizado em 2 minutos!");
TimerAssalto[playerid][1] = SetTimerEx("ExplodirDinamite", 120000, false, "d", playerid);
GiveProcurado(playerid, 1);
foreach(Player, i)
{
if(IsPlayerConnected(i) && Spawnado[i] == true)
{
if(PROF[i] == PM || PROF[i] == ROTA  || PROF[i] == CHOQUE || PROF[i] == ROTAM || PROF[i] == BOPE || PROF[i] == PC || PROF[i] == PF || PROF[i] == EXERCITO)
{
new zone[MAX_ZONE_NAME]; GetPlayer2DZone(playerid, zone, MAX_ZONE_NAME);
format(String, sizeof(String), "| DP | O(A) Mafioso(a) %s[%d] esta assaltano a fazenda id %d", PlayerName(playerid), playerid, GetPlayerVirtualWorld(playerid));
SendClientMessage(i, GetPlayerColor(i), String);
}
}
}
}
else
{
TimerAssalto[playerid][1] = SetTimerEx("ExplodirDinamite", 7000, false, "d", playerid);
}
ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0, 1);
GetPlayerPos(playerid, XDinamite[playerid], YDinamite[playerid], ZDinamite[playerid]);
GetXYInFrontOfPlayer(playerid, XDinamite[playerid], YDinamite[playerid], 0.5);
Explosivos[playerid][1] = CreateDynamicObject(1654, XDinamite[playerid], YDinamite[playerid], ZDinamite[playerid]-0.9,332.49572754,269.99450684,180.00042725);
Streamer_Update(playerid);
result = 1;
}
case FERRAMENTAS:
{
SetPlayerAttachedObject(playerid, 5, 19921, 6, 0.0279, 0.0280, 0.0000, -81.9000, -173.6000, 104.4000, 0.8220, 0.8630, 0.7470, 0xFFFFFFFF, 0xFFFFFFFF);
SegurandoMao[playerid] = FERRAMENTAS;
GameTextForPlayer(playerid, "~b~Use ~w~/Consertar", 2500, 3); result = 1;
}
case GALAO:
{
SetPlayerAttachedObject(playerid, 5, 1650, 6, 0.1399, 0.0180, 0.0419, 0.0000, -90.0000, -16.1000, 1.0000, 1.0000, 1.0000, 0xFFFFFFFF, 0xFFFFFFFF);
SegurandoMao[playerid] = GALAO;
GameTextForPlayer(playerid, "~b~Pressione ~w~H", 2500, 3); result = 1;
}
case KITMEDICO:
{
SegurandoMao[playerid] = KITMEDICO;
SetPlayerAttachedObject(playerid, 5, 11738, 6, 0.2759, 0.0290, 0.0330, 0.0000, -98.1000, -11.7000, 1.0000, 1.0000, 1.0000, 0xFFFFFFFF, 0xFFFFFFFF);
GameTextForPlayer(playerid, "~b~Pressione ~w~F", 2500, 3); result = 1;
}
case 35..312:
{
SkinPlayer[playerid] = SlotMochila[playerid][item];
SetPlayerSkin(playerid, SkinPlayer[playerid]); result = 2;
}
case MAGICBOX:
{
ShowPlayerDialog(playerid, D_BOXMAGIC, DIALOG_STYLE_MSGBOX, "{A901DB}Magic Box", "{FFFFFF}Ao abrir {A901DB}Magic Box {FFFFFF}voce pode ganhar:\n\nVIP\nITENS\nSKINS\nLEVEL\nDINHEIRO\n\nCada chance custa {FFFF00}1K de COINS{FFFFFF}.\nAntes de abrir, verifique se tem espaco no seu invetario.\n\nA {A901DB}Magic Box {FFFFFF} uma caixinha de surpresas...  ser de bem quem nao se assusta com o que tem dentro!\n\nBoa sorte", "Abrir", "Cancelar");
}
case COLETE:
{
if((gettime() - TimerColete[playerid]) >= 300)
{
SetPlayerArmour(playerid, 100.0);
TimerColete[playerid] = gettime();
result = 1;
}
else
{
MsgAviso(playerid, 3, "~r~VOCE SO PODE USAR O COLETE A CADA 5 MINUTOS");
}
}
case LOCKPICK:
{
new idv = VeiculoProximo(playerid);
if(idv > -1)
{
if(vTrancado[idv] == true)
{
AbrindoCarro[playerid] = 0;
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], "Tentando Abrir...");
PlayerTextDrawShow(playerid, TextProduzirArma[playerid]);
SetPlayerProgressBarMaxValue(playerid, barfabarmas[playerid], 100.0);
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], AbrindoCarro[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
ApplyAnimation(playerid, "INT_HOUSE", "WASH_UP", 4.1, 1, 0, 0, 0, 60000, 1);
TempoAbrindo[playerid] = SetTimerEx("AbrindoCarroLockPick", 100, false, "i", playerid);
TogglePlayerControllable(playerid, 0);
SetPVarInt(playerid, "CarroSendoRoubadoLockPick", idv);
result = 1;
}
else
{
MsgAviso(playerid, 3, "~r~ESTE VEICULO NAO ESTA TRANCADO");
}
}
else
{
MsgAviso(playerid, 3, "~r~VOCE NAO ESTA PROXIMO DE UM VEICULO");
}
}
default:
{
MsgAviso(playerid, 3, "~r~Esse item nao pode ser usado"),
PlayerTextDrawBackgroundColor(playerid, TextInvP[playerid][SlotSelecionado[playerid]], -2071690155);
ItemPreviewRot(playerid, SlotMochila[playerid][ItemSelecionado[playerid]], TextInvP[playerid][SlotSelecionado[playerid]]);
PlayerTextDrawShow(playerid,TextInvP[playerid][SlotSelecionado[playerid]]);
SlotSelecionado[playerid] = -1;
ItemSelecionado[playerid] = -1;
PaginaSelecionada[playerid] = -1;
}
}
if(result > 0)
{
for(new t; t < 21; t++)
{
TextDrawHideForPlayer(playerid, TextInv[t]);
}
for(new t; t < 46; t++)
{
PlayerTextDrawHide(playerid, TextInvP[playerid][t]);
}
CancelSelectTextDraw(playerid);
}
if(result == 1)
{
QuantidadeSlotMochila[playerid][item] --;
if(QuantidadeSlotMochila[playerid][item] <= 0)
{
SlotMochila[playerid][item] = 0;
}
}
}
forward AbrindoCarroLockPick(playerid);
public AbrindoCarroLockPick(playerid)
{
new vehicleid = GetPVarInt(playerid, "CarroSendoRoubadoLockPick");
if(AbrindoCarro[playerid] < 100)
{
AbrindoCarro[playerid] ++;
new Float:pertocarro[3]; GetVehiclePos(vehicleid, pertocarro[0],pertocarro[1],pertocarro[2]);
if(IsPlayerInRangeOfPoint(playerid, 4.0, pertocarro[0],pertocarro[1],pertocarro[2]))
{
PlayerTextDrawSetString(playerid, TextProduzirArma[playerid], "Tentando Abrir...");
SetPlayerProgressBarValue(playerid, barfabarmas[playerid], AbrindoCarro[playerid]);
ShowPlayerProgressBar(playerid, barfabarmas[playerid]);
ApplyAnimation(playerid, "INT_HOUSE", "WASH_UP", 4.1, 1, 0, 0, 0, 60000, 1);
TempoAbrindo[playerid] = SetTimerEx("AbrindoCarroLockPick", random(100)+random(300), false, "i", playerid);
}
else
{
TogglePlayerControllable(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
MsgAviso(playerid, 3, "~r~VOCE NAO ESTA PROXIMO AO VEICULO");
AbrindoCarro[playerid] = 0;
KillTimer(TempoAbrindo[playerid]);
TogglePlayerControllable(playerid, 1);
ClearAnimations(playerid);
ClearAnimations(playerid);
}
}
else
{
TogglePlayerControllable(playerid, 1);
HidePlayerProgressBar(playerid, barfabarmas[playerid]);
PlayerTextDrawHide(playerid, TextProduzirArma[playerid]);
AbrindoCarro[playerid] = 0;
KillTimer(TempoAbrindo[playerid]);
VeiculoRoubado[vehicleid] = 1;
vTrancado[vehicleid] = false;
MsgAviso(playerid, 3, "~g~VOCE CONSEGUIU ABRIR O VEICULO");
ClearAnimations(playerid);
ClearAnimations(playerid);
GiveProcurado(playerid, 1);
}
return 1;
}
stock CheckLimite(item, quantidadeA, QuantidadeB)
{
new result;
switch(item)
{
case 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 34:
{
if(quantidadeA + QuantidadeB >= 1000)
{
result = 0;
}
else
{
result = 1;
}
}
case MATERIAISPRONTO, PLANTADEMACONHA, CIGARRODEMACONHA, 1599, 1604, 19630, 1600, 1608:
{
if(quantidadeA + QuantidadeB > 2)
{
result = 0;
}
else
{
result = 1;
}
}
case XTUDO, XBURGER, XBACON, PIZZA, COCA, FANTA, GUARANA, SUCO, FERRAMENTAS, KITMEDICO, GALAO:
{
if(quantidadeA + QuantidadeB > 10)
{
result = 0;
}
else
{
result = 1;
}
}
default:
{
if(quantidadeA + QuantidadeB >= 1000)
{
result = 0;
}
else
{
result = 1;
}
}
}
return result;
}
stock pPegarNome(playerid){
new Nome[MAX_PLAYER_NAME];
GetPlayerName(playerid, Nome, MAX_PLAYER_NAME);
return Nome;
}
stock ItemPreviewRotBarraquinha(playerid, item, PlayerText:textdraw)
{
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.000000, 0.000000, 1.000000);
PlayerTextDrawSetPreviewModel(playerid, textdraw, GetDynamicObjectModel(item));
switch(GetDynamicObjectModel(item))
{
case 0:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.000000, 0.000000, 111.000000);
case PINTODEBORRACHA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -5.000000, 0.000000, -37.000000, 0.9);
case BOINA1:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.000000, 0.000000, 0.8);
case BOINA2:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.000000, 0.000000, 0.8);
case BOINA3:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.000000, 0.000000, 0.8);
case BOINA4:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.000000, 0.000000, 0.8);
case TOCA1, TOCA2, TOCA3, TOCA4, TOCA5, TOCA6, TOCA7, TOCA8, TOCA9, TOCA10, TOCA11, TOCA12, TOCA13, TOCA14, TOCA15, TOCA16, TOCA17, TOCA18, TOCA19, TOCA20:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -250.000000, 0.000000, 90.000000, 1.0);
case CHAPEUGUTE, BONEGUTE:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.000000, 0.000000, 1.0);
case BONEPOLICIA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.000000, 0.000000, 58.000000, 1.0);
case LANTERNA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 90.000000, 30.000000, 0.000000, 0.9);
case PEDECABRA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -180.000000, 114.000000, 90.000000, 1.0);
case OCULOS1, OCULOS2, OCULOS3, OCULOS4, OCULOS5, OCULOS6, OCULOS7, OCULOS8, OCULOS9, OCULOS10, OCULOS11, OCULOS12, OCULOS13, OCULOS14,
OCULOS15, OCULOS16, OCULOS17, OCULOS18, OCULOS19, OCULOS20, OCULOS21, OCULOS22, OCULOS23, OCULOS24, OCULOS25, OCULOS26, OCULOS27, OCULOS28,
OCULOS29, OCULOS30, OCULOS31, OCULOS32, OCULOS33:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -13.000000, 0.000000, 70.000000, 0.8);
case BONE1, BONE2, BONE3, BONE4, BONE5, BONE6, BONE7, BONE8, BONE9, BONE10, BONE11, BONE12, BONE13, BONE14, BONE15:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 90.000000, 40.000000, 110.000000, 1.0);
case CHAPEU2, CHAPEU3, CHAPEU4, CHAPEU5, CHAPEU6:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -90.000000, 80.000000, -90.000000, 1.0);
case CHAPEU7, CHAPEU8, CHAPEU9, CHAPEU10, CHAPEU11, CHAPEU12:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.000000, 260.000000, 1.0);
case BASTAO:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 90.000000, 0.000000, -52.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case MASCARA1:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -12.000000, 0.000000, 70.000000, 0.8);
case MASCARA2, MASCARA3, MASCARA4:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.000000, 90.000000, 0.8);
case MASCARA5:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.000000, 0.000000, 0.8);
case BANDANA20, BANDANA21, BANDANA22, BANDANA23, BANDANA24, BANDANA25, BANDANA26, BANDANA27, BANDANA28, BANDANA29:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 15.000000, -264.0, 90.000000, 0.9);
case RINGMASTER, TOCA21, TOCA22, TOCA23:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.0, 0.000000, 0.9);
case BONE17:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 10.0, 0.000000, 0.9);
case MASCARA6:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.000000, -90.0, 0.000000, 0.9);
case ESTRELA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -90.000000, 0.0, -18.000000, 1.5);
case BOLA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.0, 208.000000, 1.3);
case CHAPEU1:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -90.000000, 80.000000, -90.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case CHAPEU13:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.000000, -90.0, 0.000000, 0.9),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case FACA, FOGO, LUZVERMELHA, LUZAZUL:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 48.0, 90.000000, 1.1),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case CIRCULOCHAMATIVO:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -20.000000, 0.0, -120.000000, 1.1),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case TARTARUGA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -13.000000, 0.0, -23.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case PRANCHA1, PRANCHA2, GUITARRA1, GUITARRA2, GUITARRA3:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.0, 180.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case TOCACLUCKINBELL, ARARA, COLETEPOLICE:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.0, 0.000000, 0.9),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case MASCARADIABO, GORRO, MOCHILA, SKATE:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.0, 0.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case 19836:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 90.000000, 0.0, 90.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case 2907, 2905, 2906:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -90.000000, 0.0, 0.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case 2908:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -90.000000, 50.0, 0.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case 3092:
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
}
}
stock ItemPreviewRot(playerid, item, PlayerText:textdraw)
{
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.000000, 0.000000, 1.000000);
PlayerTextDrawSetPreviewModel(playerid, textdraw, item);
switch(item)
{
case 8, 339:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 43.0, 32.0, -31.0, 1.0),
PlayerTextDrawSetPreviewModel(playerid, textdraw, 339);
case 9, 341:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 349.0, 3.0, 76.0, 2.0),
PlayerTextDrawSetPreviewModel(playerid, textdraw, 341);
case 22, 346:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -6.0, 0.0, 56.0, 1.0),
PlayerTextDrawSetPreviewModel(playerid, textdraw, 346);
case 23, 347:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -12.0, 0.0, 66.0, 1.0),
PlayerTextDrawSetPreviewModel(playerid, textdraw, 347);
case 24, 348:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -2.0, 0.0, 70.0, 1.0),
PlayerTextDrawSetPreviewModel(playerid, textdraw, 348);
case 25, 349:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, 0.0, -35.0, 1.6),
PlayerTextDrawSetPreviewModel(playerid, textdraw, 349);
case 26, 350:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.0, 4.0, 78.0, 1.28),
PlayerTextDrawSetPreviewModel(playerid, textdraw, 350);
case 27, 351:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -9.0, 4.0, 74.0, 2.0),
PlayerTextDrawSetPreviewModel(playerid, textdraw, 351);
case 28, 352:
PlayerTextDrawSetPreviewModel(playerid, textdraw, 352);
case 29, 353:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.0, 0.0, 65.0, 1.7),
PlayerTextDrawSetPreviewModel(playerid, textdraw, 353);
case 30, 355:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, -35.0, 0.0, 1.7),
PlayerTextDrawSetPreviewModel(playerid, textdraw, 355);
case 31, 356:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, -35.0, 0.0, 1.7),
PlayerTextDrawSetPreviewModel(playerid, textdraw, 356);
case 34, 358:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, -35.0, 0.0, 1.7),
PlayerTextDrawSetPreviewModel(playerid, textdraw, 358);
case 0:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.000000, 0.000000, -20.000000, 111.000000);
case 1608:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.000000, 0.000000, 0.800000);
case MATERIAISPRONTO:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -40.000000, 0.000000, 220.000000, 1.000000);
case CIGARRODEMACONHA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 125.000000, 43.000000, 21.000000, 1.25);
case XBURGER:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -80.000000, -60.000000, -50.000000, 1.10);
case XTUDO:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -72.000000, -39.000000, -43.000000, 1.3);
case XBACON:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -90.000000, 0.000000, 0.000000, 1.3);
case PIZZA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -90.000000, 0.000000, 0.000000, 1.2);
case COCA, FANTA, GUARANA, SUCO, KITMEDICO:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.000000, 0.000000, 1.2);
case FERRAMENTAS:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -27.000000, 0.000000, 164.000000, 1.1);
case 1599, 1604, 1600:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.000000, -60.000000, 1.0);
case PINTODEBORRACHA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -5.000000, 0.000000, -37.000000, 0.9);
case BOINA1:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.000000, 0.000000, 0.8);
case BOINA2:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.000000, 0.000000, 0.8);
case BOINA3:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.000000, 0.000000, 0.8);
case BOINA4:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.000000, 0.000000, 0.8);
case TOCA1, TOCA2, TOCA3, TOCA4, TOCA5, TOCA6, TOCA7, TOCA8, TOCA9, TOCA10, TOCA11, TOCA12, TOCA13, TOCA14, TOCA15, TOCA16, TOCA17, TOCA18, TOCA19, TOCA20:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -250.000000, 0.000000, 90.000000, 1.0);
case CHAPEUGUTE, BONEGUTE:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.000000, 0.000000, 1.0);
case BONEPOLICIA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.000000, 0.000000, 58.000000, 1.0);
case LANTERNA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 90.000000, 30.000000, 0.000000, 0.9);
case PEDECABRA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -180.000000, 114.000000, 90.000000, 1.0);
case OCULOS1, OCULOS2, OCULOS3, OCULOS4, OCULOS5, OCULOS6, OCULOS7, OCULOS8, OCULOS9, OCULOS10, OCULOS11, OCULOS12, OCULOS13, OCULOS14,
OCULOS15, OCULOS16, OCULOS17, OCULOS18, OCULOS19, OCULOS20, OCULOS21, OCULOS22, OCULOS23, OCULOS24, OCULOS25, OCULOS26, OCULOS27, OCULOS28,
OCULOS29, OCULOS30, OCULOS31, OCULOS32, OCULOS33:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -13.000000, 0.000000, 70.000000, 0.8);
case BONE1, BONE2, BONE3, BONE4, BONE5, BONE6, BONE7, BONE8, BONE9, BONE10, BONE11, BONE12, BONE13, BONE14, BONE15:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 90.000000, 40.000000, 110.000000, 1.0);
case CHAPEU2, CHAPEU3, CHAPEU4, CHAPEU5, CHAPEU6:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -90.000000, 80.000000, -90.000000, 1.0);
case CHAPEU1:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -90.000000, 80.000000, -90.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case CHAPEU13:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.000000, -90.000000, 0.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case COLETEPOLICE:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.0, 0.000000, 0.9),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case CHAPEU7, CHAPEU8, CHAPEU9, CHAPEU10, CHAPEU11, CHAPEU12:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.000000, 260.000000, 1.0);
case BASTAO:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 90.000000, 0.000000, -52.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case MASCARA1:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -12.000000, 0.000000, 70.000000, 0.8);
case MASCARA2, MASCARA3, MASCARA4:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.000000, 90.000000, 0.8);
case MASCARA5:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.000000, 0.000000, 0.8);
case BANDANA20, BANDANA21, BANDANA22, BANDANA23, BANDANA24, BANDANA25, BANDANA26, BANDANA27, BANDANA28, BANDANA29:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 15.000000, -264.0, 90.000000, 0.9);
case RINGMASTER, TOCA21, TOCA22, TOCA23:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.0, 0.000000, 0.9);
case BONE17:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 10.0, 0.000000, 0.9);
case MASCARA6:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.000000, -90.0, 0.000000, 0.9);
case 10:
PlayerTextDrawSetPreviewModel(playerid, textdraw, 1579);
case ESTRELA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -90.000000, 0.0, -18.000000, 1.5);
case BOLA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.0, 208.000000, 1.3);
case FACA, FOGO, LUZVERMELHA, LUZAZUL:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 48.0, 90.000000, 1.1),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case CIRCULOCHAMATIVO:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -20.000000, 0.0, -120.000000, 1.1),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case TARTARUGA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -13.000000, 0.0, -23.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case PRANCHA1, PRANCHA2, GUITARRA1, GUITARRA2, GUITARRA3:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.0, 180.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case TOCACLUCKINBELL, ARARA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, -90.0, 0.000000, 0.9),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case MASCARADIABO, GORRO, MOCHILA, SKATE:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.000000, 0.0, 0.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case BONECA:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, 0.0, -80.0, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0x0000FF77);
case TOURO:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -10.0, 0.0, -135.0, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0x0000FF77);
case TOXA1, TOXA2:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -15.0, -35.0, 0.0, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0x0000FF77);
case DRAGAO:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, 0.0, 87.0, 1.15),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0x0000FF77);
case COWBOY:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, 0.0, 90.0, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0x0000FF77);
case CORTAVENTO, TEXACO, DRUNK, DISCO, BALAO1, BALAO2, BALAO3, BALAO4, BALAO5:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, 0.0, 0.0, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0x0000FF77);
case MAGICBOX:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 334.0, 3.0, 41.0, 1.122),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0x6B54B6FF);
case 19836:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 90.000000, 0.0, 90.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case 2907, 2905, 2906:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -90.000000, 0.0, 0.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case 2908:
PlayerTextDrawSetPreviewRot(playerid, textdraw, -90.000000, 50.0, 0.000000, 1.0),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case 3092:
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
case 19320:
PlayerTextDrawSetPreviewRot(playerid, textdraw, 0.0, 0.0, 0.0, 0.650),
PlayerTextDrawBackgroundColor(playerid, textdraw, 0xFF400077);
}
}
stock GetValorItem(item)
{
new valor[7];
switch(item)
{
case ARARA,MOCHILA:{valor = "20000";}
case CIRCULOCHAMATIVO,LUZAZUL:{valor = "40000";}
default: valor = "15000";
}
return valor;
}
stock IsVehicleOccupied(vehicleid)
{
foreach(Player, i) if(IsPlayerInVehicle( i, vehicleid) && GetPlayerState(i) == PLAYER_STATE_DRIVER)
return 1; return 0;
}
stock NotTrailerAtached(vehicle)
{
foreach(Player, i)
{
if(IsPlayerInAnyVehicle(i) && vehicle == GetVehicleTrailer(GetPlayerVehicleID(i)))
{
return 0;
}
}
return 1;
}
stock CarMaisProximo(playerid){
new pVeiculo = -1,Float:vPos[4];
for(new V = 0; V < MAX_VEHICLES; V++){
GetVehiclePos(V,vPos[0], vPos[1], vPos[2]);
if(GetVehicleModel(V) >= 400)
if(IsPlayerInRangeOfPoint(playerid, 10.0, vPos[0], vPos[1], vPos[2])){
GetVehicleZAngle(V, vPos[3]);
vPos[0] = vPos[0] -C_GetInfCarros(GetVehicleModel(V)) * floatsin(-vPos[3], degrees);
vPos[1] = vPos[1] -C_GetInfCarros(GetVehicleModel(V)) * floatcos(-vPos[3], degrees);
if(IsPlayerInRangeOfPoint(playerid, 2.0, vPos[0], vPos[1], vPos[2])){
if(VehPermPortaMal[C_GetTipoCar(GetVehicleModel(V))] == 0) return pVeiculo = -2;
pVeiculo = V; break;
}
}
}
return pVeiculo;
}
stock AttVelocimetro(playerid)
{
new veh = GetPlayerVehicleID(playerid); new modelo = GetVehicleModel(veh);
new zone[MAX_ZONE_NAME]; GetPlayer2DZone(playerid, zone, MAX_ZONE_NAME);
new Velocidade[4]; format(Velocidade, sizeof(Velocidade), "%d", VelocidadeDoVeiculo(veh));
new idv[40]; format(idv, sizeof(idv), "~y~~h~KM/H    ~b~~h~~h~ID ~w~%d", veh);
new nome[23]; format(nome, sizeof(nome), "~b~~h~~h~%s", NomeVeiculo(veh));
new combustivel[23];
GetVehicleHealth(veh, VidaVehEx[veh]);
GetVehicleDamageStatus(veh, Paineis[veh], Portas[veh], Luzes[veh], Pneus[veh]);
if(VidaVehEx[veh] >= 200.0 && VidaVehEx[veh] <= 300.0)
{
SetVehicleHealth(veh, 300.1);
if(vQuebrado[veh] == false)
{
vQuebrado[veh] = true;
SendClientMessage(playerid, -1, "| INFO | Seu veiculo quebrou, chame um mecanico para conserta-lo! ~> /Mecanico");
GameTextForPlayer(playerid, "~r~Veiculo Quebrado", 3000, 3);
new motor, farol, alarme, portas, capo, portamalas, objetivo;
GetVehicleParamsEx(veh, motor, farol, alarme, portas, capo, portamalas, objetivo);
SetVehicleParamsEx(veh, VEHICLE_PARAMS_OFF, 0, alarme, portas, capo, portamalas, objetivo);
RemovePlayerFromVehicle(playerid);
}
}
else if(VidaVehEx[veh] >= 999.0)
{
if(vQuebrado[veh] == true)
{
vQuebrado[veh] = false;
}
}
if(modelo != 417 && modelo != 425 && modelo != 430 && modelo != 446 && modelo != 447 && modelo != 449 && modelo != 452 && modelo != 453 && modelo != 454 &&
modelo != 460 && modelo != 469 && modelo != 472 && modelo != 473 && modelo != 476 && modelo != 481 && modelo != 484 && modelo != 487 && modelo != 488 && modelo != 493 &&
modelo != 497 && modelo != 509 && modelo != 510 && modelo != 511 && modelo != 512 && modelo != 513 && modelo != 519 && modelo != 520 && modelo != 537 && modelo != 538 &&
modelo != 548 && modelo != 553 && modelo != 563 && modelo != 577 && modelo != 592 && modelo != 593 && modelo != 595)
{
if(IsPlayerInRangeOfPoint(playerid, 20.0, -2681.60303, 1765.79773, 67.49690) && RadarQuebrado[0] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 120)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 180)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 20.0, -1897.15259, 2377.17261, 50.46350) && RadarQuebrado[1] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 120)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 180)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 20.0, -604.61359, 641.31488, 18.75900) && RadarQuebrado[2] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 120)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 180)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 30.0, 1476.89673, 842.92499, 8.76500) && RadarQuebrado[3] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 120)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 180)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 30.0, 1937.78271, 2531.29150, 8.75650) && RadarQuebrado[4] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 120)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 180)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 10.0, 662.6431,1993.3218,7.4171) && RadarQuebrado[5] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 100)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 150)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '100Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '100Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 20.0, 1700.68140, -717.79242, 50.68060) && RadarQuebrado[6] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 120)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 180)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 20.0, 377.3586,120.7405,5.9342) || IsPlayerInRangeOfPoint(playerid, 20.0, 366.2987,139.2048,6.4846) && RadarQuebrado[7] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 80)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 130)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '80Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '80Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 10.0, -146.4971,-1292.6436,2.6953) && RadarQuebrado[8] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 80)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 130)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '80Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '80Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 20.0, -1222.4493,-763.1383,63.7787) && RadarQuebrado[9] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 80)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 130)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '80Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '80Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 20.0, -1903.98279, -817.98114, 43.95180) && RadarQuebrado[10] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 120)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 180)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 20.0, -174.24817, -1505.96826, 12.62990) && RadarQuebrado[11] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 120)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 180)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 15.0, -1100.17041, -2857.89429, 66.65480) && RadarQuebrado[12] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 120)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 180)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 20.0, -2929.31714, -1566.33569, 10.14520) && RadarQuebrado[13] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 120)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 180)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 15.0,  -2255.49194, -11.22166, 34.16339) && RadarQuebrado[14] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 100)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 150)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '100Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '100Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 15.0,  -1652.17236, 400.73740, 6.03077) && RadarQuebrado[15] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 80)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 130)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '80Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '80Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 15.0,  1234.47424, -935.65942, 41.50040) && RadarQuebrado[16] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 100)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 150)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '100Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '100Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 18.0, 1349.78418, -1423.73450, 12.54150) && RadarQuebrado[17] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 80)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 130)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '80Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '80Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 15.0, 2766.96338, 122.59060, 21.52630) && RadarQuebrado[18] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 120)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 180)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '120Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
if(IsPlayerInRangeOfPoint(playerid, 20.0, 2057.44360, 1193.18018, 9.66381) && RadarQuebrado[19] == false)
{
new velocidade = VelocidadeDoVeiculo(GetPlayerVehicleID(playerid));
if(velocidade <= 100)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~g~RADAR", 2000, 3);
}
}
else
{
new bool:fardado = false;
for(new s; s < 16; s++)
{
if(GetPlayerSkin(playerid) == FardaSkin[s] || GetPlayerSkin(playerid) == 287)
{
fardado = true;
break;
}
}
if(IsPlayerAdmin(playerid) || NivelAdmin[playerid] > 0)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por ser da Administracao", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(fardado == true)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por estar Fardado", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else if(PROF[playerid] == PARAMEDICO && GetVehicleModel(GetPlayerVehicleID(playerid)) == 416)
{
if(PassouRadar[playerid] == 0)
{
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h voce nao levou multa por esta conduzindo uma Ambulancia", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
PassouRadar[playerid] = 5;
GameTextForPlayer(playerid, "~y~RADAR LIBERADO", 2000, 3);
}
}
else
{
if(PassouRadar[playerid] == 0)
{
if(velocidade >= 150)
{
GiveProcurado(playerid, 1);
}
if(Multa[playerid] < 5)
{
Multa[playerid] ++;
ValorMulta[playerid] = ValorMulta[playerid] + velocidade*3;
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '100Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Portanto, voce foi multado por esse excesso de velocidade em $%d", velocidade*3);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | No momento voce tem %d multas e precisa paga-las no Detran", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Caso complete 6 multas acumuladas voce pagara uma taxa de $6000");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
else if(Multa[playerid] == 5)
{
Multa[playerid] = 0;
ValorMulta[playerid] = 0;
if(SaldoBancario[playerid] > -999999)
{
SaldoBancario[playerid] -= 6000;
}
PassouRadar[playerid] = 5;
TextDrawShowForPlayer(playerid, Flash);
GameTextForPlayer(playerid, "~r~MULTA", 2500, 3);
PlayerPlaySound(playerid, 1132, 0.0, 0.0, 0.0);
SetTimerEx("FlashFotoSair", 2000, false, "d", playerid);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
format(String, sizeof(String), "| RADAR | Velocidade registrada: %dKm/h", velocidade);
SendClientMessage(playerid, COR_AMARELO, String);
format(String, sizeof(String), "| MULTA | Voce foi pego com a velocidade acima do limite permitido nessa rodovia '100Km/h'");
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | Voce pagou uma taxa de $6000 por deixar acumular 6 multas", Multa[playerid]);
SendClientMessage(playerid, -1, String);
format(String, sizeof(String), "| MULTA | O Valor foi descontado automaticamente da sua conta bancaria");
SendClientMessage(playerid, -1, String);
SendClientMessage(playerid, COR_VERDE, "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[ RADAR ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
}
}
}
}
}
}
if(modelo==400||modelo==457||modelo==462||modelo==478||modelo==485||modelo==530||modelo==531||modelo==571||modelo==572||modelo==574||modelo==583)
{
if(Combustivel[veh] > 10.0)
{
format(combustivel, sizeof(combustivel), "~w~%0.1fL", Combustivel[veh]);
}
else
{
format(combustivel, sizeof(combustivel), "~w~%0.1fL", Combustivel[veh]);
}
}
else if(modelo==403||modelo==406||modelo==407||modelo==408||modelo==430||modelo==431||modelo==433||modelo==437||modelo==443||modelo==446||modelo==452||modelo==453||modelo==454||modelo==455||modelo==472||modelo==473||modelo==484||modelo==486||modelo==493||modelo==514||modelo==515||modelo==524||modelo==532 ||modelo==537||modelo==538||modelo==539||modelo==544||modelo==573||modelo==578||modelo==595)
{
if(Combustivel[veh] > 10.0)
{
format(combustivel, sizeof(combustivel), "~w~%0.1fL", Combustivel[veh]);
}
else
{
format(combustivel, sizeof(combustivel), "~w~%0.1fL", Combustivel[veh]);
}
}
else if(modelo==417||modelo==425||modelo==447||modelo==460||modelo==469||modelo==476||modelo==597||modelo==511||modelo==512||modelo==513||modelo==519||modelo==520||modelo==548||modelo==553||modelo==563||modelo==577||modelo==592||modelo==593)
{
if(Combustivel[veh] > 10.0)
{
format(combustivel, sizeof(combustivel), "~w~%0.1fL", Combustivel[veh]);
}
else
{
format(combustivel, sizeof(combustivel), "~w~%0.1fL", Combustivel[veh]);
}
}
else if(modelo == 481 || modelo == 509 || modelo == 510)
{
format(combustivel, sizeof(combustivel), "~w~N/A");
}
else
{
if(Combustivel[veh] > 10.0)
{
format(combustivel, sizeof(combustivel), "~w~%0.1fL", Combustivel[veh]);
}
else
{
format(combustivel, sizeof(combustivel), "~w~%0.1fL", Combustivel[veh]);
}
}
PlayerTextDrawSetString(playerid, TextVelo[playerid][10], zone);
PlayerTextDrawSetString(playerid, TextVelo[playerid][6], Velocidade);
PlayerTextDrawSetString(playerid, TextVelo[playerid][8], nome);
PlayerTextDrawSetString(playerid, TextVelo[playerid][9], combustivel);
new motor, farol, alarme, portas, capo, portamalas, objetivo;
GetVehicleParamsEx(veh, motor, farol, alarme, portas, capo, portamalas, objetivo);
if(Abastecendo[playerid] == false)
{
if(motor == VEHICLE_PARAMS_ON && modelo != 481 && modelo != 509 && modelo != 510)
{
if(Combustivel[veh] > 0.002)
{
Combustivel[veh] -= 0.002;
}
else
{
SetVehicleParamsEx(veh, VEHICLE_PARAMS_OFF, 0, alarme, portas, capo, portamalas, objetivo);
SendClientMessage(playerid, -1, "| INFO | O Combustivel do seu veiculo acabou");
}
}
}
else if(Abastecendo[playerid] == true)
{
if(motor == VEHICLE_PARAMS_OFF)
{
if(modelo==400||modelo==457||modelo==462||modelo==478||modelo==485||modelo==530||modelo==531||modelo==571||modelo==572||modelo==574||modelo==583)
{
if(Combustivel[veh] < 50.0)
{
if(Money[playerid] >= 2 || VIP[playerid] > 0)
{
Combustivel[veh] += 0.05;
LitrosAbastecidos[playerid] += 0.05;
ValorPorLitro[playerid] ++;
if(ValorPorLitro[playerid] >= 10)
{
if(VIP[playerid] == 0)
{
Money[playerid] -= 2;
ValorGasto[playerid] += 2;
}
ValorPorLitro[playerid] = 0;
new strinfo[30]; format(strinfo, sizeof(strinfo), "Litros_Abastecidos:_~g~%0.1fL", LitrosAbastecidos[playerid]);
PlayerTextDrawSetString(playerid, TextAbastecerP[playerid][1], strinfo);
format(strinfo, sizeof(strinfo), "Valor_Gasto:_~g~$%d", ValorGasto[playerid]);
PlayerTextDrawSetString(playerid, TextAbastecerP[playerid][2], strinfo);
}
}
else
{
SendClientMessage(playerid, 0xFFFF00FF, "| INFO | Voce nao tem dinheiro suficiente para continuar abastecendo");
Abastecendo[playerid] = false;
for(new p; p < MAX_POSTOS; p++)
{
if(IsPlayerInRangeOfPoint(playerid, 40.0, pX[p], pY[p], pZ[p]))
{
new tirar = floatround(LitrosAbastecidos[playerid], floatround_round);
if(pLitros[p] >= tirar)
{
pLitros[p] -= tirar;
}
else
{
pLitros[p] = 0;
}
if(!new_strcmp(pDono[p], "Ninguem"))
{
pLucro[p] += ValorGasto[playerid];
}
format(String, sizeof(String), "{708090}Posto ID %d\n{FF6347}Dono(a): {FFFFFF}%s\n{FF6347}Combustivel: {FFFFFF}%dL\n{FF6347}Lucro: {00FF00}$%d", p, pDono[p], pLitros[p], pLucro[p]);
UpdateDynamic3DTextLabelText(TextoPosto[p], -1, String);
}
}
TextDrawHideForPlayer(playerid, TextAbastecer[0]); TextDrawHideForPlayer(playerid, TextAbastecer[1]);
for(new t; t < 3; t++)
{
PlayerTextDrawHide(playerid, TextAbastecerP[playerid][t]);
}
}
}
else
{
format(String, sizeof(String), "| INFO | O tanque do seu veiculo encheu e voce gastou $%d", ValorGasto[playerid]);
SendClientMessage(playerid, 0xFFFF00FF, String);
Abastecendo[playerid] = false;
for(new p; p < MAX_POSTOS; p++)
{
if(IsPlayerInRangeOfPoint(playerid, 40.0, pX[p], pY[p], pZ[p]))
{
new tirar = floatround(LitrosAbastecidos[playerid], floatround_round);
if(pLitros[p] >= tirar)
{
pLitros[p] -= tirar;
}
else
{
pLitros[p] = 0;
}
if(!new_strcmp(pDono[p], "Ninguem"))
{
pLucro[p] += ValorGasto[playerid];
}
format(String, sizeof(String), "{708090}Posto ID %d\n{FF6347}Dono(a): {FFFFFF}%s\n{FF6347}Combustivel: {FFFFFF}%dL\n{FF6347}Lucro: {00FF00}$%d", p, pDono[p], pLitros[p], pLucro[p]);
UpdateDynamic3DTextLabelText(TextoPosto[p], -1, String);
}
}
TextDrawHideForPlayer(playerid, TextAbastecer[0]); TextDrawHideForPlayer(playerid, TextAbastecer[1]);
for(new t; t < 3; t++)
{
PlayerTextDrawHide(playerid, TextAbastecerP[playerid][t]);
}
}
}
else if(modelo==403||modelo==406||modelo==407||modelo==408||modelo==430||modelo==431||modelo==433||modelo==437||modelo==443||modelo==446||modelo==452||modelo==453||modelo==454||modelo==455||modelo==472||modelo==473||modelo==484||modelo==486||modelo==493||modelo==514||modelo==515||modelo==524||modelo==532 ||modelo==537||modelo==538||modelo==539||modelo==544||modelo==573||modelo==578||modelo==595)
{
if(Combustivel[veh] < 300.0)
{
if(Money[playerid] >= 4 || VIP[playerid] > 0)
{
Combustivel[veh] += 0.05;
LitrosAbastecidos[playerid] += 0.05;
ValorPorLitro[playerid] ++;
if(ValorPorLitro[playerid] >= 10)
{
if(VIP[playerid] == 0)
{
Money[playerid] -= 4;
ValorGasto[playerid] += 4;
}
ValorPorLitro[playerid] = 0;
new strinfo[30]; format(strinfo, sizeof(strinfo), "Litros_Abastecidos:_~g~%0.1fL", LitrosAbastecidos[playerid]);
PlayerTextDrawSetString(playerid, TextAbastecerP[playerid][1], strinfo);
format(strinfo, sizeof(strinfo), "Valor_Gasto:_~g~$%d", ValorGasto[playerid]);
PlayerTextDrawSetString(playerid, TextAbastecerP[playerid][2], strinfo);
}
}
else
{
SendClientMessage(playerid, 0xFFFF00FF, "| INFO | Voce nao tem dinheiro suficiente para continuar abastecendo");
Abastecendo[playerid] = false;
for(new p; p < MAX_POSTOS; p++)
{
if(IsPlayerInRangeOfPoint(playerid, 40.0, pX[p], pY[p], pZ[p]))
{
new tirar = floatround(LitrosAbastecidos[playerid], floatround_round);
if(pLitros[p] >= tirar)
{
pLitros[p] -= tirar;
}
else
{
pLitros[p] = 0;
}
if(!new_strcmp(pDono[p], "Ninguem"))
{
pLucro[p] += ValorGasto[playerid];
}
format(String, sizeof(String), "{708090}Posto ID %d\n{FF6347}Dono(a): {FFFFFF}%s\n{FF6347}Combustivel: {FFFFFF}%dL\n{FF6347}Lucro: {00FF00}$%d", p, pDono[p], pLitros[p], pLucro[p]);
UpdateDynamic3DTextLabelText(TextoPosto[p], -1, String);
}
}
TextDrawHideForPlayer(playerid, TextAbastecer[0]); TextDrawHideForPlayer(playerid, TextAbastecer[1]);
for(new t; t < 3; t++)
{
PlayerTextDrawHide(playerid, TextAbastecerP[playerid][t]);
}
}
}
else
{
format(String, sizeof(String), "| INFO | O tanque do seu veiculo encheu e voce gastou $%d", ValorGasto[playerid]);
SendClientMessage(playerid, 0xFFFF00FF, String);
Abastecendo[playerid] = false;
for(new p; p < MAX_POSTOS; p++)
{
if(IsPlayerInRangeOfPoint(playerid, 40.0, pX[p], pY[p], pZ[p]))
{
new tirar = floatround(LitrosAbastecidos[playerid], floatround_round);
if(pLitros[p] >= tirar)
{
pLitros[p] -= tirar;
}
else
{
pLitros[p] = 0;
}
if(!new_strcmp(pDono[p], "Ninguem"))
{
pLucro[p] += ValorGasto[playerid];
}
format(String, sizeof(String), "{708090}Posto ID %d\n{FF6347}Dono(a): {FFFFFF}%s\n{FF6347}Combustivel: {FFFFFF}%dL\n{FF6347}Lucro: {00FF00}$%d", p, pDono[p], pLitros[p], pLucro[p]);
UpdateDynamic3DTextLabelText(TextoPosto[p], -1, String);
}
}
TextDrawHideForPlayer(playerid, TextAbastecer[0]); TextDrawHideForPlayer(playerid, TextAbastecer[1]);
for(new t; t < 3; t++)
{
PlayerTextDrawHide(playerid, TextAbastecerP[playerid][t]);
}
}
}
else if(modelo==417||modelo==425||modelo==447||modelo==460||modelo==469||modelo==476||modelo==597||modelo==511||modelo==512||modelo==513||modelo==519||modelo==520||modelo==548||modelo==553||modelo==563||modelo==577||modelo==592||modelo==593)
{
if(Combustivel[veh] < 400.0)
{
if(Money[playerid] >= 5 || VIP[playerid] > 0)
{
Combustivel[veh] += 0.05;
LitrosAbastecidos[playerid] += 0.05;
ValorPorLitro[playerid] ++;
if(ValorPorLitro[playerid] >= 10)
{
if(VIP[playerid] == 0)
{
Money[playerid] -= 5;
ValorGasto[playerid] += 5;
}
ValorPorLitro[playerid] = 0;
new strinfo[30]; format(strinfo, sizeof(strinfo), "Litros_Abastecidos:_~g~%0.1fL", LitrosAbastecidos[playerid]);
PlayerTextDrawSetString(playerid, TextAbastecerP[playerid][1], strinfo);
format(strinfo, sizeof(strinfo), "Valor_Gasto:_~g~$%d", ValorGasto[playerid]);
PlayerTextDrawSetString(playerid, TextAbastecerP[playerid][2], strinfo);
}
}
else
{
SendClientMessage(playerid, 0xFFFF00FF, "| INFO | Voce nao tem dinheiro suficiente para continuar abastecendo");
Abastecendo[playerid] = false;
for(new p; p < MAX_POSTOS; p++)
{
if(IsPlayerInRangeOfPoint(playerid, 40.0, pX[p], pY[p], pZ[p]))
{
new tirar = floatround(LitrosAbastecidos[playerid], floatround_round);
if(pLitros[p] >= tirar)
{
pLitros[p] -= tirar;
}
else
{
pLitros[p] = 0;
}
if(!new_strcmp(pDono[p], "Ninguem"))
{
pLucro[p] += ValorGasto[playerid];
}
format(String, sizeof(String), "{708090}Posto ID %d\n{FF6347}Dono(a): {FFFFFF}%s\n{FF6347}Combustivel: {FFFFFF}%dL\n{FF6347}Lucro: {00FF00}$%d", p, pDono[p], pLitros[p], pLucro[p]);
UpdateDynamic3DTextLabelText(TextoPosto[p], -1, String);
}
}
TextDrawHideForPlayer(playerid, TextAbastecer[0]); TextDrawHideForPlayer(playerid, TextAbastecer[1]);
for(new t; t < 3; t++)
{
PlayerTextDrawHide(playerid, TextAbastecerP[playerid][t]);
}
}
}
else
{
format(String, sizeof(String), "| INFO | O tanque do seu veiculo encheu e voce gastou $%d", ValorGasto[playerid]);
SendClientMessage(playerid, 0xFFFF00FF, String);
Abastecendo[playerid] = false;
for(new p; p < MAX_POSTOS; p++)
{
if(IsPlayerInRangeOfPoint(playerid, 40.0, pX[p], pY[p], pZ[p]))
{
new tirar = floatround(LitrosAbastecidos[playerid], floatround_round);
if(pLitros[p] >= tirar)
{
pLitros[p] -= tirar;
}
else
{
pLitros[p] = 0;
}
if(!new_strcmp(pDono[p], "Ninguem"))
{
pLucro[p] += ValorGasto[playerid];
}
format(String, sizeof(String), "{708090}Posto ID %d\n{FF6347}Dono(a): {FFFFFF}%s\n{FF6347}Combustivel: {FFFFFF}%dL\n{FF6347}Lucro: {00FF00}$%d", p, pDono[p], pLitros[p], pLucro[p]);
UpdateDynamic3DTextLabelText(TextoPosto[p], -1, String);
}
}
TextDrawHideForPlayer(playerid, TextAbastecer[0]); TextDrawHideForPlayer(playerid, TextAbastecer[1]);
for(new t; t < 3; t++)
{
PlayerTextDrawHide(playerid, TextAbastecerP[playerid][t]);
}
}
}
else
{
if(Combustivel[veh] < 60.0)
{
if(Money[playerid] >= 3 || VIP[playerid] > 0)
{
Combustivel[veh] += 0.05;
LitrosAbastecidos[playerid] += 0.05;
ValorPorLitro[playerid] ++;
if(ValorPorLitro[playerid] >= 10)
{
if(VIP[playerid] == 0)
{
Money[playerid] -= 3;
ValorGasto[playerid] += 3;
}
ValorPorLitro[playerid] = 0;
new strinfo[30]; format(strinfo, sizeof(strinfo), "Litros_Abastecidos:_~g~%0.1fL", LitrosAbastecidos[playerid]);
PlayerTextDrawSetString(playerid, TextAbastecerP[playerid][1], strinfo);
format(strinfo, sizeof(strinfo), "Valor_Gasto:_~g~$%d", ValorGasto[playerid]);
PlayerTextDrawSetString(playerid, TextAbastecerP[playerid][2], strinfo);
}
}
else
{
SendClientMessage(playerid, 0xFFFF00FF, "| INFO | Voce nao tem dinheiro suficiente para continuar abastecendo");
Abastecendo[playerid] = false;
for(new p; p < MAX_POSTOS; p++)
{
if(IsPlayerInRangeOfPoint(playerid, 40.0, pX[p], pY[p], pZ[p]))
{
new tirar = floatround(LitrosAbastecidos[playerid], floatround_round);
if(pLitros[p] >= tirar)
{
pLitros[p] -= tirar;
}
else
{
pLitros[p] = 0;
}
if(!new_strcmp(pDono[p], "Ninguem"))
{
pLucro[p] += ValorGasto[playerid];
}
format(String, sizeof(String), "{708090}Posto ID %d\n{FF6347}Dono(a): {FFFFFF}%s\n{FF6347}Combustivel: {FFFFFF}%dL\n{FF6347}Lucro: {00FF00}$%d", p, pDono[p], pLitros[p], pLucro[p]);
UpdateDynamic3DTextLabelText(TextoPosto[p], -1, String);
}
}
TextDrawHideForPlayer(playerid, TextAbastecer[0]); TextDrawHideForPlayer(playerid, TextAbastecer[1]);
for(new t; t < 3; t++)
{
PlayerTextDrawHide(playerid, TextAbastecerP[playerid][t]);
}
}
}
else
{
format(String, sizeof(String), "| INFO | O tanque do seu veiculo encheu e voce gastou $%d", ValorGasto[playerid]);
SendClientMessage(playerid, 0xFFFF00FF, String);
Abastecendo[playerid] = false;
for(new p; p < MAX_POSTOS; p++)
{
if(IsPlayerInRangeOfPoint(playerid, 40.0, pX[p], pY[p], pZ[p]))
{
new tirar = floatround(LitrosAbastecidos[playerid], floatround_round);
if(pLitros[p] >= tirar)
{
pLitros[p] -= tirar;
}
else
{
pLitros[p] = 0;
}
if(!new_strcmp(pDono[p], "Ninguem"))
{
pLucro[p] += ValorGasto[playerid];
}
format(String, sizeof(String), "{708090}Posto ID %d\n{FF6347}Dono(a): {FFFFFF}%s\n{FF6347}Combustivel: {FFFFFF}%dL\n{FF6347}Lucro: {00FF00}$%d", p, pDono[p], pLitros[p], pLucro[p]);
UpdateDynamic3DTextLabelText(TextoPosto[p], -1, String);
}
}
TextDrawHideForPlayer(playerid, TextAbastecer[0]); TextDrawHideForPlayer(playerid, TextAbastecer[1]);
for(new t; t < 3; t++)
{
PlayerTextDrawHide(playerid, TextAbastecerP[playerid][t]);
}
}
}
}
else
{
Abastecendo[playerid] = false;
for(new p; p < MAX_POSTOS; p++)
{
if(IsPlayerInRangeOfPoint(playerid, 40.0, pX[p], pY[p], pZ[p]))
{
new tirar = floatround(LitrosAbastecidos[playerid], floatround_round);
if(pLitros[p] >= tirar)
{
pLitros[p] -= tirar;
}
else
{
pLitros[p] = 0;
}
if(!new_strcmp(pDono[p], "Ninguem"))
{
pLucro[p] += ValorGasto[playerid];
}
format(String, sizeof(String), "{708090}Posto ID %d\n{FF6347}Dono(a): {FFFFFF}%s\n{FF6347}Combustivel: {FFFFFF}%dL\n{FF6347}Lucro: {00FF00}$%d", p, pDono[p], pLitros[p], pLucro[p]);
UpdateDynamic3DTextLabelText(TextoPosto[p], -1, String);
}
}
TextDrawHideForPlayer(playerid, TextAbastecer[0]); TextDrawHideForPlayer(playerid, TextAbastecer[1]);
for(new t; t < 3; t++)
{
PlayerTextDrawHide(playerid, TextAbastecerP[playerid][t]);
}
}
}
}
stock CheckCaseSensitivity(nick[])
{
for(new i; i < strlen(nick); i++)
{
if(nick[i] == 'Q'){nick[i] = 'q';}
else if(nick[i] == 'W'){nick[i] = 'w';}
else if(nick[i] == 'E'){nick[i] = 'e';}
else if(nick[i] == 'R'){nick[i] = 'r';}
else if(nick[i] == 'T'){nick[i] = 't';}
else if(nick[i] == 'Y'){nick[i] = 'y';}
else if(nick[i] == 'U'){nick[i] = 'u';}
else if(nick[i] == 'I'){nick[i] = 'i';}
else if(nick[i] == 'O'){nick[i] = 'o';}
else if(nick[i] == 'P'){nick[i] = 'p';}
else if(nick[i] == 'A'){nick[i] = 'a';}
else if(nick[i] == 'S'){nick[i] = 's';}
else if(nick[i] == 'D'){nick[i] = 'd';}
else if(nick[i] == 'F'){nick[i] = 'f';}
else if(nick[i] == 'G'){nick[i] = 'g';}
else if(nick[i] == 'H'){nick[i] = 'h';}
else if(nick[i] == 'J'){nick[i] = 'j';}
else if(nick[i] == 'K'){nick[i] = 'k';}
else if(nick[i] == 'L'){nick[i] = 'l';}
else if(nick[i] == 'Z'){nick[i] = 'z';}
else if(nick[i] == 'X'){nick[i] = 'x';}
else if(nick[i] == 'C'){nick[i] = 'c';}
else if(nick[i] == 'V'){nick[i] = 'v';}
else if(nick[i] == 'B'){nick[i] = 'b';}
else if(nick[i] == 'N'){nick[i] = 'n';}
else if(nick[i] == 'M'){nick[i] = 'm';}
}
new StringConta[50];
format(StringConta, sizeof(StringConta), "ContasSensitivity/%s.ini", nick);
if(!DOF2_FileExists(StringConta))
{
DOF2_CreateFile(StringConta);
return 1;
}
return 0;
}
stock DellCaseSensitivity(nick[])
{
for(new i; i < strlen(nick); i++)
{
if(nick[i] == 'Q'){nick[i] = 'q';}
else if(nick[i] == 'W'){nick[i] = 'w';}
else if(nick[i] == 'E'){nick[i] = 'e';}
else if(nick[i] == 'R'){nick[i] = 'r';}
else if(nick[i] == 'T'){nick[i] = 't';}
else if(nick[i] == 'Y'){nick[i] = 'y';}
else if(nick[i] == 'U'){nick[i] = 'u';}
else if(nick[i] == 'I'){nick[i] = 'i';}
else if(nick[i] == 'O'){nick[i] = 'o';}
else if(nick[i] == 'P'){nick[i] = 'p';}
else if(nick[i] == 'A'){nick[i] = 'a';}
else if(nick[i] == 'S'){nick[i] = 's';}
else if(nick[i] == 'D'){nick[i] = 'd';}
else if(nick[i] == 'F'){nick[i] = 'f';}
else if(nick[i] == 'G'){nick[i] = 'g';}
else if(nick[i] == 'H'){nick[i] = 'h';}
else if(nick[i] == 'J'){nick[i] = 'j';}
else if(nick[i] == 'K'){nick[i] = 'k';}
else if(nick[i] == 'L'){nick[i] = 'l';}
else if(nick[i] == 'Z'){nick[i] = 'z';}
else if(nick[i] == 'X'){nick[i] = 'x';}
else if(nick[i] == 'C'){nick[i] = 'c';}
else if(nick[i] == 'V'){nick[i] = 'v';}
else if(nick[i] == 'B'){nick[i] = 'b';}
else if(nick[i] == 'N'){nick[i] = 'n';}
else if(nick[i] == 'M'){nick[i] = 'm';}
}
new StringConta[50];
format(StringConta, sizeof(StringConta), "ContasSensitivity/%s.ini", nick);
if(DOF2_FileExists(StringConta))
{
DOF2_RemoveFile(StringConta);
return 1;
}
return 0;
}
stock VerifyExpiredDays(days)
return (days) < gettime();
stock ConvertToDays(n)
{
new t[5];
t[4] = n-gettime();
t[0] = t[4] / 3600;
t[1] = ((t[4] / 60) - (t[0] * 60));
t[2] = (t[4] - ((t[0] * 3600) + (t[1] * 60)));
t[3] = (t[0]/24);
if(t[3] > 0)
t[0] = t[0] % 24,
format(String, sizeof(String), "%d dia(s) %dh %dm %ds", t[3], t[0], t[1], t[2]);
else if(t[0] > 0)
format(String, sizeof(String), "%dh %dm %ds", t[0], t[1], t[2]);
else
format(String, sizeof(String), "%dm %ds", t[1], t[2]);
return String;
}
stock UltimoLogin(n)
{
new t[5], msg[30];
t[4] = gettime()-n;
t[0] = t[4] / 3600;
t[1] = ((t[4] / 60) - (t[0] * 60));
t[2] = (t[4] - ((t[0] * 3600) + (t[1] * 60)));
t[3] = (t[0]/24);
if(t[3] > 0)
t[0] = t[0] % 24,
format(msg, sizeof(msg), "%d dia(s) e %d hora(s)", t[3], t[0]);
else if(t[0] > 0)
format(msg, sizeof(msg), "%d hora(s) e %d minuto(s)", t[0], t[1]);
else
format(msg, sizeof(msg), "%d minuto(s)", t[1]);
return msg;
}forward tQ_AntiCar();
public tQ_AntiCar(){
for (new i = 0; i < rC_MaxVehcl; i++)
if(rC_AntiCar[i] == 0 && GetVehicleModel(i) != 0)
DestroyVehicle(i);
return 1;
}
stock ConvertTimeAdm(playerid)
{
new t[5], msg[30];
t[4] = 126000-SegundosSalarioAdmin[playerid];
t[0] = t[4] / 3600;
t[1] = ((t[4] / 60) - (t[0] * 60));
t[2] = (t[4] - ((t[0] * 3600) + (t[1] * 60)));
t[3] = (t[0]/24);
if(t[3] > 0)
t[0] = t[0] % 24,
format(msg, sizeof(msg), "%d dia(s) e %d hora(s)", t[3], t[0]);
else if(t[0] > 0)
format(msg, sizeof(msg), "%d hora(s) e %d minuto(s)", t[0], t[1]);
else
format(msg, sizeof(msg), "%d minuto(s)", t[1]);
return msg;
}
stock FileLog(const file[], const string[])
{
new Hora, Minuto; gettime(Hora, Minuto);
new Dia, Mes, Ano; getdate(Dia, Mes, Ano);
new timestr[32], data[180], File:hFile, thefile[32];
format(timestr,32,"%02d/%02d/%02d - %02d:%02d ",Ano, Mes, Dia, Hora, Minuto);
format(data, sizeof(data), "%s%s\r\n",timestr,string);
format(thefile, sizeof(thefile), "Logs/%s.log", file);
hFile = fopen(thefile, io_append);
fwrite(hFile, data);
fclose(hFile);
return 1;
}
stock GiveProcurado(playerid, pr)
{
if(NivelProcurado[playerid] + pr <= 20)
{
NivelProcurado[playerid] += pr;
}
else if(NivelProcurado[playerid] + pr > 20)
{
NivelProcurado[playerid] = 20;
}
if(NivelProcurado[playerid] > 0)
{
new _str[10];
format(_str, sizeof(_str), "%d", NivelProcurado[playerid]);
PlayerTextDrawSetString(playerid, TextEstrelas[playerid][1], _str);
PlayerTextDrawShow(playerid, TextEstrelas[playerid][0]);
PlayerTextDrawShow(playerid, TextEstrelas[playerid][1]);
}
else
{
PlayerTextDrawSetString(playerid, TextEstrelas[playerid][1], "0");
PlayerTextDrawShow(playerid, TextEstrelas[playerid][0]);
PlayerTextDrawShow(playerid, TextEstrelas[playerid][1]);
}
return 1;
}
stock ResetProcurado(playerid)
{
NivelProcurado[playerid] = 0;
PlayerTextDrawSetString(playerid, TextEstrelas[playerid][1], "0");
PlayerTextDrawShow(playerid, TextEstrelas[playerid][0]);
PlayerTextDrawShow(playerid, TextEstrelas[playerid][1]);
return 1;
}
stock ValorSkinComum(skin)
{
switch(skin)
{
case 129,130,131,132,133,134,135,136,137,157,158,159,160,161,200,201,202,212,213,230: return 1000;
case 50,51,52,54,72,77,78,79,82,83,84,88,89,94,95,96,101,128,203,222,223,253,258,259,260: return 30000;
default: return 0;
}
return 0;
}
stock ValorVeiculo(vehicleid)
{
new valor, model = GetVehicleModel(vehicleid);
if(model == 400) {valor = 47000;}
else if(model == 401) {valor = 25000;}
else if(model == 402) {valor = 65000;}
else if(model == 403) {valor = 120000;}
else if(model == 404) {valor = 36000;}
else if(model == 405) {valor = 30000;}
else if(model == 409) {valor = 90000;}
else if(model == 410) {valor = 20000;}
else if(model == 411) {valor = 160000;}
else if(model == 412) {valor = 30000;}
else if(model == 413) {valor = 40000;}
else if(model == 414) {valor = 40000;}
else if(model == 415) {valor = 55000;}
else if(model == 418) {valor = 45000;}
else if(model == 419) {valor = 60000;}
else if(model == 421) {valor = 55000;}
else if(model == 422) {valor = 30000;}
else if(model == 424) {valor = 28000;}
else if(model == 426) {valor = 39000;}
else if(model == 429) {valor = 95000;}
else if(model == 431) {valor = 100000;}
else if(model == 434) {valor = 170000;}
else if(model == 436) {valor = 20000;}
else if(model == 437) {valor = 150000;}
else if(model == 439) {valor = 43000;}
else if(model == 440) {valor = 37000;}
else if(model == 442) {valor = 45000;}
else if(model == 443) {valor = 105000;}
else if(model == 444) {valor = 70000;}
else if(model == 445) {valor = 52000;}
else if(model == 451) {valor = 150000;}
else if(model == 455) {valor = 85000;}
else if(model == 456) {valor = 63000;}
else if(model == 457) {valor = 10000;}
else if(model == 458) {valor = 37000;}
else if(model == 459) {valor = 31000;}
else if(model == 461) {valor = 12000;}
else if(model == 462) {valor = 7000;}
else if(model == 463) {valor = 25000;}
else if(model == 466) {valor = 41000;}
else if(model == 467) {valor = 41000;}
else if(model == 468) {valor = 9000;}
else if(model == 471) {valor = 16000;}
else if(model == 474) {valor = 35000;}
else if(model == 475) {valor = 36000;}
else if(model == 477) {valor = 56000;}
else if(model == 478) {valor = 29000;}
else if(model == 479) {valor = 30000;}
else if(model == 480) {valor = 26000;}
else if(model == 481) {valor = 1000;}
else if(model == 482) {valor = 37000;}
else if(model == 483) {valor = 41000;}
else if(model == 485) {valor = 10000;}
else if(model == 489) {valor = 40000;}
else if(model == 491) {valor = 41000;}
else if(model == 492) {valor = 36000;}
else if(model == 494) {valor = 115000;}
else if(model == 495) {valor = 81000;}
else if(model == 496) {valor = 29000;}
else if(model == 498) {valor = 32000;}
else if(model == 499) {valor = 32000;}
else if(model == 500) {valor = 70000;}
else if(model == 502) {valor = 115000;}
else if(model == 503) {valor = 115000;}
else if(model == 504) {valor = 45000;}
else if(model == 505) {valor = 40000;}
else if(model == 506) {valor = 130000;}
else if(model == 507) {valor = 65000;}
else if(model == 508) {valor = 110000;}
else if(model == 509) {valor = 1000;}
else if(model == 510) {valor = 3000;}
else if(model == 514) {valor = 120000;}
else if(model == 515) {valor = 130000;}
else if(model == 516) {valor = 36000;}
else if(model == 517) {valor = 36000;}
else if(model == 518) {valor = 36000;}
else if(model == 521) {valor = 16000;}
else if(model == 522) {valor = 80000;}
else if(model == 526) {valor = 25000;}
else if(model == 527) {valor = 25000;}
else if(model == 529) {valor = 30000;}
else if(model == 533) {valor = 60000;}
else if(model == 534) {valor = 85000;}
else if(model == 535) {valor = 61000;}
else if(model == 535) {valor = 56000;}
else if(model == 539) {valor = 100000;}
else if(model == 540) {valor = 29000;}
else if(model == 541) {valor = 155000;}
else if(model == 542) {valor = 25000;}
else if(model == 543) {valor = 25000;}
else if(model == 545) {valor = 135000;}
else if(model == 546) {valor = 33000;}
else if(model == 547) {valor = 33000;}
else if(model == 549) {valor = 25000;}
else if(model == 550) {valor = 43000;}
else if(model == 551) {valor = 35000;}
else if(model == 554) {valor = 47000;}
else if(model == 555) {valor = 50000;}
else if(model == 556) {valor = 75000;}
else if(model == 557) {valor = 73000;}
else if(model == 558) {valor = 56000;}
else if(model == 559) {valor = 41000;}
else if(model == 560) {valor = 65000;}
else if(model == 561) {valor = 65000;}
else if(model == 562) {valor = 65000;}
else if(model == 565) {valor = 35000;}
else if(model == 566) {valor = 34000;}
else if(model == 567) {valor = 49000;}
else if(model == 568) {valor = 22000;}
else if(model == 571) {valor = 8000;}
else if(model == 572) {valor = 9000;}
else if(model == 573) {valor = 63000;}
else if(model == 575) {valor = 38000;}
else if(model == 576) {valor = 37000;}
else if(model == 579) {valor = 75000;}
else if(model == 580) {valor = 98000;}
else if(model == 581) {valor = 12000;}
else if(model == 583) {valor = 10000;}
else if(model == 585) {valor = 30000;}
else if(model == 586) {valor = 25000;}
else if(model == 587) {valor = 47000;}
else if(model == 589) {valor = 30000;}
else if(model == 600) {valor = 25000;}
else if(model == 602) {valor = 28000;}
else if(model == 603) {valor = 55000;}
else if(model == 417) {valor = 300000;}
else if(model == 447) {valor = 100000;}
else if(model == 469) {valor = 150000;}
else if(model == 476) {valor = 200000;}
else if(model == 487) {valor = 500000;}
else if(model == 511) {valor = 350000;}
else if(model == 512) {valor = 150000;}
else if(model == 513) {valor = 170000;}
else if(model == 519) {valor = 500000;}
else if(model == 563) {valor = 250000;}
else if(model == 593) {valor = 270000;}
else if(model == 446) {valor = 150000;}
else if(model == 452) {valor = 135000;}
else if(model == 454) {valor = 140000;}
else if(model == 460) {valor = 250000;}
else if(model == 473) {valor = 110000;}
else if(model == 484) {valor = 90000;}
else if(model == 493) {valor = 160000;}
else {valor = 55555;}
return valor;
}
forward xTLoopRoubo(playerid,xCofre,xTipo);
public xTLoopRoubo(playerid,xCofre,xTipo){
new xTstring[128];
if(xTipo == 0){
if(cT_AddRoubCofre[playerid] >= 30){
cT_AddRoubCofre[playerid] = 0;
KillTimer(cT_xTKillROUBcOF[playerid]);
ClearAnimations(playerid,1);
cT_xTKillROUBcOF[playerid] = SetTimerEx("xTLoopRoubo", 1000, true,"iii",playerid,xCofre,1);
return SendClientMessage(playerid, 0xFFFFFFFF, "Dinamite foi plantada!");
}
if(!IsPlayerInRangeOfPoint(playerid,3.0,Cr_PosCofres[xCofre][0],Cr_PosCofres[xCofre][1],Cr_PosCofres[xCofre][2])){
cT_AddRoubCofre[playerid] = 0;
KillTimer(cT_xTKillROUBcOF[playerid]);
ClearAnimations(playerid,1);
return SendClientMessage(playerid, 0xFF0000FF, "Voc� afastou de perto do Cofre!");
}
format(xTstring, sizeof (xTstring), "~n~~n~~n~~n~~n~Dinamite~n~~r~%i~w~/~g~30",cT_AddRoubCofre[playerid]);
}else if(xTipo == 1){
if(cT_AddRoubCofre[playerid] >= 50){
cT_AddRoubCofre[playerid] = 0;
KillTimer(cT_xTKillROUBcOF[playerid]);
ClearAnimations(playerid,1);
Cr_StCofres[xCofre] = 1;
SetTimerEx("Cr_RepCofre", 1000*60*5, false,"i",xCofre);
DestroyDynamicObject(Cr_pObjCofre[xCofre]);
Cr_pObjCofre[xCofre] = CreateDynamicObject(1829, Cr_PosCofres[xCofre][0], Cr_PosCofres[xCofre][1], Cr_PosCofres[xCofre][2]-0.55, 0.0, 0.0, Cr_PosCofres[xCofre][3]-180.0);
CreateExplosion(Cr_PosCofres[xCofre][0], Cr_PosCofres[xCofre][1], Cr_PosCofres[xCofre][2]-0.55, 4, 10.0);
format(xTstring, sizeof(xTstring), "Cofre\n{FFFFFF}/cofre\n{FF0000}Explodido");
UpdateDynamic3DTextLabelText(Cr_TxtLbcofre[xCofre], 0xFF0000FF, xTstring);
return SendClientMessage(playerid, 0xFFFFFFFF, "Cofre foi explodido!");
}
format(xTstring, sizeof (xTstring), "~n~~n~~n~~n~~n~Explosao~n~~r~%i~w~/~g~50",cT_AddRoubCofre[playerid]);
}else if(xTipo == 2){
if(cT_AddRoubCofre[playerid] >= 50){
cT_AddRoubCofre[playerid] = 0;
KillTimer(cT_xTKillROUBcOF[playerid]);
ClearAnimations(playerid,1);
Cr_RepCofre(xCofre);
return SendClientMessage(playerid, 0xFFFFFFFF, "Cofre foi Reparado!");
}
format(xTstring, sizeof (xTstring), "~n~~n~~n~~n~~n~Reparando~n~~r~%i~w~/~g~50",cT_AddRoubCofre[playerid]);
}
GameTextForPlayer(playerid,xTstring,1000,5);
cT_AddRoubCofre[playerid]++;
return 1;
}
stock VelocidadeVeiculo(vehicleid)
{
new vel, model = GetVehicleModel(vehicleid);
if(model == 400) {vel = 151;}
else if(model == 401) {vel = 139;}
else if(model == 402) {vel = 176;}
else if(model == 403) {vel = 103;}
else if(model == 404) {vel = 127;}
else if(model == 405) {vel = 154;}
else if(model == 409) {vel = 151;}
else if(model == 410) {vel = 122;}
else if(model == 411) {vel = 209;}
else if(model == 412) {vel = 162;}
else if(model == 413) {vel = 104;}
else if(model == 414) {vel = 102;}
else if(model == 415) {vel = 184;}
else if(model == 418) {vel = 109;}
else if(model == 419) {vel = 141;}
else if(model == 421) {vel = 145;}
else if(model == 422) {vel = 132;}
else if(model == 424) {vel = 127;}
else if(model == 426) {vel = 164;}
else if(model == 429) {vel = 193;}
else if(model == 434) {vel = 157;}
else if(model == 436) {vel = 141;}
else if(model == 439) {vel = 159;}
else if(model == 440) {vel = 128;}
else if(model == 442) {vel = 131;}
else if(model == 444) {vel = 104;}
else if(model == 445) {vel = 157;}
else if(model == 451) {vel = 185;}
else if(model == 455) {vel = 149;}
else if(model == 457) {vel = 90;}
else if(model == 458) {vel = 148;}
else if(model == 459) {vel = 128;}
else if(model == 461) {vel = 151;}
else if(model == 462) {vel = 105;}
else if(model == 463) {vel = 134;}
else if(model == 466) {vel = 141;}
else if(model == 467) {vel = 132;}
else if(model == 468) {vel = 137;}
else if(model == 471) {vel = 104;}
else if(model == 474) {vel = 141;}
else if(model == 475) {vel = 163;}
else if(model == 477) {vel = 176;}
else if(model == 478) {vel = 133;}
else if(model == 479) {vel = 134;}
else if(model == 480) {vel = 176;}
else if(model == 481) {vel = 69;}
else if(model == 482) {vel = 150;}
else if(model == 483) {vel = 116;}
else if(model == 485) {vel = 94;}
else if(model == 489) {vel = 132;}
else if(model == 490) {vel = 134;}
else if(model == 491) {vel = 141;}
else if(model == 492) {vel = 132;}
else if(model == 494) {vel = 203;}
else if(model == 495) {vel = 166;}
else if(model == 496) {vel = 156;}
else if(model == 498) {vel = 102;}
else if(model == 499) {vel = 116;}
else if(model == 500) {vel = 135;}
else if(model == 502) {vel = 203;}
else if(model == 503) {vel = 203;}
else if(model == 504) {vel = 163;}
else if(model == 505) {vel = 132;}
else if(model == 506) {vel = 172;}
else if(model == 507) {vel = 156;}
else if(model == 508) {vel = 102;}
else if(model == 509) {vel = 75;}
else if(model == 510) {vel = 95;}
else if(model == 516) {vel = 148;}
else if(model == 517) {vel = 151;}
else if(model == 518) {vel = 155;}
else if(model == 521) {vel = 153;}
else if(model == 522) {vel = 167;}
else if(model == 526) {vel = 149;}
else if(model == 527) {vel = 141;}
else if(model == 529) {vel = 141;}
else if(model == 533) {vel = 160;}
else if(model == 534) {vel = 159;}
else if(model == 535) {vel = 151;}
else if(model == 535) {vel = 149;}
else if(model == 536) {vel = 166;}
else if(model == 539) {vel = 93;}
else if(model == 540) {vel = 141;}
else if(model == 541) {vel = 191;}
else if(model == 542) {vel = 157;}
else if(model == 543) {vel = 142;}
else if(model == 545) {vel = 141;}
else if(model == 546) {vel = 141;}
else if(model == 547) {vel = 135;}
else if(model == 549) {vel = 145;}
else if(model == 550) {vel = 137;}
else if(model == 551) {vel = 162;}
else if(model == 554) {vel = 141;}
else if(model == 555) {vel = 149;}
else if(model == 556) {vel = 104;}
else if(model == 557) {vel = 104;}
else if(model == 558) {vel = 147;}
else if(model == 559) {vel = 168;}
else if(model == 560) {vel = 162;}
else if(model == 561) {vel = 148;}
else if(model == 562) {vel = 168;}
else if(model == 565) {vel = 155;}
else if(model == 566) {vel = 154;}
else if(model == 567) {vel = 166;}
else if(model == 568) {vel = 138;}
else if(model == 571) {vel = 88;}
else if(model == 572) {vel = 57;}
else if(model == 573) {vel = 104;}
else if(model == 575) {vel = 166;}
else if(model == 576) {vel = 149;}
else if(model == 578) {vel = 125;}
else if(model == 579) {vel = 151;}
else if(model == 580) {vel = 144;}
else if(model == 581) {vel = 142;}
else if(model == 583) {vel = 80;}
else if(model == 585) {vel = 144;}
else if(model == 586) {vel = 135;}
else if(model == 587) {vel = 158;}
else if(model == 589) {vel = 153;}
else if(model == 600) {vel = 142;}
else if(model == 602) {vel = 163;}
else if(model == 603) {vel = 164;}
else if(model == 417) {vel = 120;}
else if(model == 447) {vel = 135;}
else if(model == 469) {vel = 135;}
else if(model == 476) {vel = 120;}
else if(model == 487) {vel = 169;}
else if(model == 511) {vel = 134;}
else if(model == 512) {vel = 140;}
else if(model == 513) {vel = 155;}
else if(model == 519) {vel = 255;}
else if(model == 563) {vel = 120;}
else if(model == 593) {vel = 146;}
else if(model == 446) {vel = 190;}
else if(model == 452) {vel = 150;}
else if(model == 454) {vel = 122;}
else if(model == 460) {vel = 150;}
else if(model == 473) {vel = 97;}
else if(model == 484) {vel = 58;}
else if(model == 493) {vel = 155;}
else {vel = 99999;}
return vel;
}
stock VerificarVeiculoT(playerid, model)
{
new result;
switch(model)
{
case 400, 401, 402, 404, 405, 410, 411, 412, 413, 415, 418, 419, 421, 422, 424, 426, 429, 434, 436, 439, 440, 442,
444, 445, 451, 455, 457, 458, 459, 461, 462, 463, 466, 467, 468, 471, 474, 475, 477, 478, 479, 480, 481, 482, 483,
485, 489, 491, 492, 494, 495, 496, 500, 502, 503, 504, 505, 506, 507, 508, 509, 510, 516, 517, 518, 521, 522, 526,
527, 529, 533 ,534, 535, 539, 540, 541, 542, 543, 545, 546, 547, 549, 550, 551, 554, 555, 556, 557, 558, 559, 560,
561, 562, 565, 566, 567, 568, 571, 572, 573, 575, 576, 579, 580, 581, 583, 585, 586, 587, 589, 600, 602, 603: result = model;
default: result = 0;
}
if(result == 0)
{
if(VModel[playerid] > 400 && VModel[playerid] < 603)
{
if(BotaoConce[playerid] == true)
{
VModel[playerid] ++; VerificarVeiculoT(playerid, VModel[playerid]); return 0;
}
else
{
VModel[playerid] --; VerificarVeiculoT(playerid, VModel[playerid]); return 0;
}
}
else
{
if(BotaoConce[playerid] == true)
{
VModel[playerid] = 400; VerificarVeiculoT(playerid, VModel[playerid]); return 0;
}
else
{
VModel[playerid] = 603; VerificarVeiculoT(playerid, VModel[playerid]); return 0;
}
}
}
return 0;
}
stock ValorVeiculoModelAE(playerid, model)
{
new result;
switch(model)
{
case 417, 447, 469, 476, 487, 511, 512, 513, 519, 563, 593: result = model;
default: result = 0;
}
if(result == 0)
{
if(VModel[playerid] > 417 && VModel[playerid] < 593)
{
if(BotaoConce[playerid] == true)
{
VModel[playerid] ++; ValorVeiculoModelAE(playerid, VModel[playerid]); return 0;
}
else
{
VModel[playerid] --; ValorVeiculoModelAE(playerid, VModel[playerid]); return 0;
}
}
else
{
if(BotaoConce[playerid] == true)
{
VModel[playerid] = 417; ValorVeiculoModelAE(playerid, VModel[playerid]); return 0;
}
else
{
VModel[playerid] = 593; ValorVeiculoModelAE(playerid, VModel[playerid]); return 0;
}
}
}
return 0;
}
stock ValorVeiculoModelAQ(playerid, model)
{
new result;
switch(model)
{
case 446, 452, 454, 460, 473, 484, 493: result = model;
default: result = 0;
}
if(result == 0)
{
if(VModel[playerid] > 446 && VModel[playerid] < 493)
{
if(BotaoConce[playerid] == true)
{
VModel[playerid] ++; ValorVeiculoModelAQ(playerid, VModel[playerid]); return 0;
}
else
{
VModel[playerid] --; ValorVeiculoModelAQ(playerid, VModel[playerid]); return 0;
}
}
else
{
if(BotaoConce[playerid] == true)
{
VModel[playerid] = 446; ValorVeiculoModelAQ(playerid, VModel[playerid]); return 0;
}
else
{
VModel[playerid] = 493; ValorVeiculoModelAQ(playerid, VModel[playerid]); return 0;
}
}
}
return 0;
}
stock VeiculoProximo(playerid)
{
new Float:X, Float:Y, Float:Z, id = -1;
for(new I = 1; I < GetVehiclePoolSize()+1; I++)
{
GetVehiclePos(I, X, Y, Z);
if(IsPlayerInRangeOfPoint(playerid, 4.0, X, Y, Z))
{
id = I;
break;
}
}
return id;
}
stock VeiculoProximo8m(playerid)
{
new Float:X, Float:Y, Float:Z, id = -1;
for(new I = 1; I < GetVehiclePoolSize()+1; I++)
{
if(GetVehicleModel(I) > 0)
{
if(GetPlayerVehicleID(playerid) != I)
{
GetVehiclePos(I, X, Y, Z);
if(IsPlayerInRangeOfPoint(playerid, 8.0, X, Y, Z))
{
id = I;
break;
}
}
}
}
return id;
}
stock AddStaticVehicleExC(jmodelo,Float:jX,Float:jY,Float:jZ,Float:jA,jCor1,jCor2,jDelay,jaddsiren=0){
new xSlot;
xSlot = AddStaticVehicleEx(jmodelo,jX,jY,jZ,jA,jCor1,jCor2,jDelay, jaddsiren);
rC_AntiCar[xSlot] = jmodelo;
return xSlot;
}
stock VelocidadeDoVeiculo(vehicleid)
{
new Float:xPos[3];
GetVehicleVelocity(vehicleid, xPos[0], xPos[1], xPos[2]);
return floatround(floatsqroot(xPos[0] * xPos[0] + xPos[1] * xPos[1] + xPos[2] * xPos[2]) * 170.00);
}
stock GetPlayerSpeed(playerid)
{
new Float:velocity[4];
if(IsPlayerInAnyVehicle(playerid))
GetVehicleVelocity(GetPlayerVehicleID(playerid),velocity[0],velocity[1],velocity[2]);
else GetPlayerVelocity(playerid,velocity[0],velocity[1],velocity[2]);
velocity[3] = floatsqroot(floatpower(floatabs(velocity[0]), 2.0) + floatpower(floatabs(velocity[1]), 2.0) + floatpower(floatabs(velocity[2]), 2.0)) * 97;
return floatround(velocity[3]);
}
stock NomeVeiculo(vehicleid){
new vehmodel = GetVehicleModel(vehicleid);
new nameVeh[75];
if (vehmodel < 400 || vehmodel > 611) {
strcat(nameVeh, "Nenhum");
return nameVeh;
}
strcat(nameVeh, VehicleNames[vehmodel - 400]);
return nameVeh;
}
stock GetVehicleRotation(vehicleid,&Float:rx,&Float:ry,&Float:rz){
new Float:qw,Float:qx,Float:qy,Float:qz;
GetVehicleRotationQuat(vehicleid,qw,qx,qy,qz);
rx = asin(2*qy*qz-2*qx*qw);
ry = -atan2(qx*qz+qy*qw,0.5-qx*qx-qy*qy);
rz = -atan2(qx*qy+qz*qw,0.5-qx*qx-qz*qz);
}
stock GetVehicleZone(vehicleid)
{
new Float:x, Float:y, Float:z, zonee[30];
GetVehiclePos(vehicleid, x, y, z);
for(new i = 0; i != sizeof(gSAZoness); i++ )
{
if(x >= gSAZoness[i][SAZONE_AREAA][0] && x <= gSAZoness[i][SAZONE_AREAA][3] && y >= gSAZoness[i][SAZONE_AREAA][1] && y <= gSAZoness[i][SAZONE_AREAA][4])
{
format(zonee, sizeof(zonee), gSAZoness[i][SAZONE_NAMEE], 0);
}
}
return zonee;
}
stock GetZonePos(Float:x, Float:y)
{
new zonee[30];
for(new i = 0; i != sizeof(gSAZoness); i++ )
{
if(x >= gSAZoness[i][SAZONE_AREAA][0] && x <= gSAZoness[i][SAZONE_AREAA][3] && y >= gSAZoness[i][SAZONE_AREAA][1] && y <= gSAZoness[i][SAZONE_AREAA][4])
{
format(zonee, sizeof(zonee), gSAZoness[i][SAZONE_NAMEE], 0);
}
}
return zonee;
}
forward uQ_LpFixArm();
public uQ_LpFixArm(){
for(new i=0; i<MAX_PLAYERS; i++)
if(IsPlayerConnected(i) && AstraModo[i] != ASTRA_MODO_PVP)
if(GetPlayerWeapon(i) > 1)
if(uQBSWeaponID[i][GetPlayerWeapon(i)] != 1)
ResetPlayerWeaponsExC(i),SendClientMessage(i, 0xFF0000FF, "Voc� perdeu todas as armas com suspeita de Armas Ilegal no Servidor!");
return 1;
}
forward GetPlayerHospital(playerid);
public GetPlayerHospital(playerid)
{
if(!IsPlayerConnected(playerid))
{
return -1;
}
new Float:distancia = 100000.000, Float:dist, prevhosp;
for(new hospid = 0; hospid < 8; hospid++)
{
if(hospid == 0) {dist = GetPlayerDistanceToPoint(playerid, 1176.5480,-1323.2540);}
else if(hospid == 1) {dist = GetPlayerDistanceToPoint(playerid, 2035.9244, -1413.1837);}
else if(hospid == 2) {dist = GetPlayerDistanceToPoint(playerid, 1579.1146, 1769.1814);}
else if(hospid == 3) {dist = GetPlayerDistanceToPoint(playerid, -316.0515, 1055.0485);}
else if(hospid == 4) {dist = GetPlayerDistanceToPoint(playerid, -1514.7839, 2523.5173);}
else if(hospid == 5) {dist = GetPlayerDistanceToPoint(playerid, -2660.3928, 633.1524);}
else if(hospid == 6) {dist = GetPlayerDistanceToPoint(playerid, -2207.5203, -2285.8203);}
else if(hospid == 7) {dist = GetPlayerDistanceToPoint(playerid, 1245.3052, 333.9335);}
if((dist < distancia))
{
distancia = dist;
prevhosp = hospid;
}
}
return prevhosp;
}
forward GetPlayerDP(playerid);
public GetPlayerDP(playerid)
{
if(!IsPlayerConnected(playerid))
{
return -1;
}
new Float:distancia = 100000.000, Float:dist, prevhosp;
for(new hospid = 0; hospid < 8; hospid++)
{
if(hospid == 0) {dist = GetPlayerDistanceToPoint(playerid, 1554.9657,-1675.6466);}
else if(hospid == 1) {dist = GetPlayerDistanceToPoint(playerid, 627.2767,-571.7728);}
else if(hospid == 2) {dist = GetPlayerDistanceToPoint(playerid, -217.4765,979.2430);}
else if(hospid == 3) {dist = GetPlayerDistanceToPoint(playerid, 2287.1208,2431.3518);}
else if(hospid == 4) {dist = GetPlayerDistanceToPoint(playerid, -1390.0145,2637.9114);}
else if(hospid == 5) {dist = GetPlayerDistanceToPoint(playerid, -1605.5885,711.4365);}
else if(hospid == 6) {dist = GetPlayerDistanceToPoint(playerid, -2162.0771,-2385);}
else if(hospid == 7) {dist = GetPlayerDistanceToPoint(playerid, 2895.5820,-848.7189);}
if((dist < distancia))
{
distancia = dist;
prevhosp = hospid;
}
}
return prevhosp;
}
forward Kickar(playerid);
public Kickar(playerid)
{
Kick(playerid);
return 1;
}
forward Banir(playerid);
public Banir(playerid)
{
Ban(playerid);
return 1;
}
forward ReiniciarServer();
public ReiniciarServer()
{
FileLog("Reiniciamento", "O Servidor foi reiniciado!");
SendRconCommand("exit");
}
stock GetPlayerDistanceToPoint(playerid, Float:x, Float:y)
{
new Float:tmpdis;
new Float:x1, Float:y1, Float:z1;
GetPlayerPos(playerid, x1, y1, z1);
tmpdis = floatsqroot(floatpower(floatabs(floatsub(x,x1)),2)+floatpower(floatabs(floatsub(y,y1)),2));
return floatround(tmpdis);
}
stock AttNumeroDecimal(str[])
{
new StringD[21]; format(StringD, sizeof(StringD), "%s", str);
if(strlen(StringD) == 4)
{
strins(StringD, ".", 1);
}
else if(strlen(StringD) == 5)
{
strins(StringD, ".", 2);
}
else if(strlen(StringD) == 6)
{
strins(StringD, ".", 3);
}
else if(strlen(StringD) == 7)
{
strins(StringD, ".", 1);
strins(StringD, ".", 5);
}
else if(strlen(StringD) == 8)
{
strins(StringD, ".", 2);
strins(StringD, ".", 6);
}
else if(strlen(StringD) == 9)
{
strins(StringD, ".", 3);
strins(StringD, ".", 7);
}
else if(strlen(StringD) > 9)
{
strins(StringD, ".", 1);
strins(StringD, ".", 5);
strins(StringD, ".", 9);
}
return StringD;
}
stock IsValidInput(const ipstr[])
{
for(new i = 0; ipstr[i] != EOS; ++i)
{
switch(ipstr[i])
{
case '0'..'9', 'A'..'Z', 'a'..'z', '_', '[', '@', ']', '.':
continue;
default:
return 0;
}
}
return 1;
}
strtok(const string[], &index)
{
new length = strlen(string);
while ((index < length) && (string[index] <= ' '))
{
index++;
}
new offset = index;
new result[25];
while ((index < length) && (string[index] > ' ') && ((index - offset) < (sizeof(result) - 1)))
{
result[index - offset] = string[index];
index++;
}
result[index - offset] = EOS;
return result;
}
stock DialogMaps(playerid)
{
new strmaps[550];
strcat(strmaps, "{FF0000} {FFFFFF}Agencias de Empregos\n");
strcat(strmaps, "{FF0000} {FFFFFF}Departamentos de Policia\n");
strcat(strmaps, "{FF0000} {FFFFFF}Prefeituras\n");
strcat(strmaps, "{FF0000} {FFFFFF}Detran\n");
strcat(strmaps, "{FF0000} {FFFFFF}Hospitais\n");
strcat(strmaps, "{FF0000} {FFFFFF}Auto escolas\n");
strcat(strmaps, "{FF0000} {FFFFFF}Bancos\n");
strcat(strmaps, "{FF0000} {FFFFFF}Caixas Eletronicos\n");
strcat(strmaps, "{FF0000} {FFFFFF}Concessionarias\n");
strcat(strmaps, "{FF0000} {FFFFFF}Hoteis\n");
strcat(strmaps, "{FF0000} {FFFFFF}Areas VIP\n");
strcat(strmaps, "{FF0000} {FFFFFF}Favela\n");
strcat(strmaps, "{FF0000} {FFFFFF}HQ Organizacoes\n");
strcat(strmaps, "{FF0000} {FFFFFF}HQ Profissoes\n");
strcat(strmaps, "{FF0000} {FFFFFF}Outros Locais\n");
strcat(strmaps, "{FF0000} {FFFFFF}Desligar Maps");
ShowPlayerDialog(playerid, D_GPS, DIALOG_STYLE_LIST, "{FFFF00}Maps / GPS", strmaps, "Selecionar", "Fechar");
return 1;
}
forward Tq_LpRoubarPl(playerid);
public Tq_LpRoubarPl(playerid){
new xLocal = yQ_RoubLocl[playerid],xGrana = random(1000)+1250,string[128];
ClearAnimations(playerid,1);
format(string, sizeof(string), "Voc� roubou a registradora e saqueou $2500", xGrana);
DinheiroSujo[playerid] += 2500;
SendClientMessage(playerid, 0xFFFFFFFF, string);
SetTimerEx("Tq_AutoRep", 1000*60*10, false, "i", xLocal);
return 1;
}
stock PlayerName(playerid)
{
new name[MAX_PLAYER_NAME];
GetPlayerName(playerid,name,sizeof(name));
return name;
}
stock LimparChat(playerid, linhas)
{
for(new b = 0; b <= linhas; b++) SendClientMessage(playerid, -1, "");
}
stock CampoRegistro(playerid)
{
new gstring[400], pstring[80], Titulo[55];
format(pstring, sizeof(pstring), "{FFFFFF}Senha: %s\n", SENHAR[playerid]);
strcat(gstring, pstring);
format(pstring, sizeof(pstring), "{FFFFFF}Email: %s\n", EMAILR[playerid]);
strcat(gstring, pstring);
format(pstring, sizeof(pstring), "{FFFFFF}Discord: %s\n", DISCORDR[playerid]);
strcat(gstring, pstring);
format(pstring, sizeof(pstring), "{FFFFFF}Sexo: %s\n", SEXOR[playerid]);
strcat(gstring, pstring);
format(pstring, sizeof(pstring), "{FFFFFF}Escolher Cidade\n");
strcat(gstring, pstring);
format(pstring, sizeof(pstring), "{058AFF}Registrar");
strcat(gstring, pstring);
format(Titulo, sizeof(Titulo), "{04B404}Registrando: {FFFFFF}%s", PlayerName(playerid));
ShowPlayerDialog(playerid, D_REGISTRO, DIALOG_STYLE_LIST, Titulo, gstring, "Selecionar", "Cancelar");
}
stock IsPointInRangeOfPoint(Float:x, Float:y, Float:z, Float:x2, Float:y2, Float:z2, Float:range)
{
x2 -= x;
y2 -= y;
z2 -= z;
return ((x2 * x2) + (y2 * y2) + (z2 * z2)) < (range * range);
}
stock SetarCor(playerid)
{
if(PROF[playerid] == DESEMPREGADO)
{
SetPlayerColor(playerid, 0xFFFFFFFF);
}
else if(PROF[playerid] == PM)
{
SetPlayerColor(playerid, COR_PM);
}
else if(PROF[playerid] == ROTA)
{
SetPlayerColor(playerid, COR_ROTA);
}
else if(PROF[playerid] == CHOQUE)
{
SetPlayerColor(playerid, COR_CHOQUE);
}
else if(PROF[playerid] == ROTAM)
{
SetPlayerColor(playerid, COR_ROTAM);
}
else if(PROF[playerid] == BOPE)
{
SetPlayerColor(playerid, COR_BOPE);
}
else if(PROF[playerid] == PC)
{
SetPlayerColor(playerid, COR_PC);
}
else if(PROF[playerid] == PF)
{
SetPlayerColor(playerid, COR_PF);
}
else if(PROF[playerid] == EXERCITO)
{
SetPlayerColor(playerid, COR_EXERCITO);
}
else if(PROF[playerid] == PREFEITO)
{
SetPlayerColor(playerid, COR_PREFEITO);
}
}
stock sdados()
{
new h, m, s; gettime(h, m, s);
for(new c; c < MAX_CASAS; c++)
{
format(String, sizeof(String), "Casas/%d.ini", c);
if(DOF2_FileExists(String))
{
if(!new_strcmp(cDono[c], "Ninguem"))
{
if(h == 6)
{
cLixo[c] ++; cImpostos[c] ++;
}
if(cLixo[c] >= 2)
{
new PastaDono[24];
format(PastaDono, sizeof(PastaDono), "Contas/%s.ini", cDono[c]);
if(DOF2_FileExists(PastaDono))
{
DOF2_SetInt(PastaDono, "MultaCasa", DOF2_GetInt(PastaDono, "MultaCasa") + 1000);
}
}
if(cImpostos[c] >= 15)
{
cImpostos[c] = 0;
cLixo[c] = 0;
cAvenda[c] = 0;
cModelPick[c] = 1273;
cModelMapIcon[c] = 31;
format(cDono[c], 23, "Ninguem");
format(cMorador[c], 23, "Ninguem");
format(cSenha[c], 30, "-1");
format(cMensagem[c], 31, "");
new ValorNaMsg[11]; format(ValorNaMsg, sizeof(ValorNaMsg), "%d", cValor[c]);
if(cCoins[c] > 0)
{
format(cMensagemVenda[c], 80, "{FFFFFF}A venda por {00FF00}$%s {FFFFFF}e {FFFF00}%d {FFFFFF}coins", AttNumeroDecimal(ValorNaMsg), cCoins[c]);
}
else
{
format(cMensagemVenda[c], 80, "{FFFFFF}A venda por {00FF00}$%s", AttNumeroDecimal(ValorNaMsg));
}
}
}
DOF2_SetString(String, "Dono", cDono[c]);
DOF2_SetString(String, "Morador", cMorador[c]);
DOF2_SetInt(String, "Valor", cValor[c]);
DOF2_SetInt(String, "Impostos", cImpostos[c]);
DOF2_SetInt(String, "Lixo", cLixo[c]);
DOF2_SetInt(String, "Pick", cModelPick[c]);
DOF2_SetInt(String, "MapIcon", cModelMapIcon[c]);
DOF2_SetInt(String, "Avenda", cAvenda[c]);
DOF2_SetString(String, "Senha", cSenha[c]);
DOF2_SetString(String, "Mensagem", cMensagem[c]);
DOF2_SetFloat(String, "X", cX[c]);
DOF2_SetFloat(String, "Y", cY[c]);
DOF2_SetFloat(String, "Z", cZ[c]);
DOF2_SetFloat(String, "XX", cXX[c]);
DOF2_SetFloat(String, "YY", cYY[c]);
DOF2_SetFloat(String, "ZZ", cZZ[c]);
DOF2_SetFloat(String, "R", cR[c]);
DOF2_SetInt(String, "Interior", cInterior[c]);
DOF2_SetInt(String, "Upgrade", cUpgrade[c]);
DOF2_SetInt(String, "UPMAX", cUPMAX[c]);
DOF2_SetString(String, "msgvenda", cMensagemVenda[c]);
}
}
for(new e; e < MAX_EMPRESAS; e++)
{
format(String, sizeof(String), "Empresas/%d.ini", e);
if(DOF2_FileExists(String))
{
if(!new_strcmp(eDono[e], "Ninguem"))
{
if(h == 6)
{
eImpostos[e] ++;
}
if(eImpostos[e] >= 15)
{
eLucro[e] = 0;
eProducao[e] = 0;
eImpostos[e] = 0;
eAvenda[e] = 0;
eContratando[e] = 0;
format(eDono[e], 23, "Ninguem");
format(eFuncionario1[e], 23, "Ninguem");
format(eFuncionario2[e], 23, "Ninguem");
format(eFuncionario3[e], 23, "Ninguem");
eEntregasFuncionario1[e] = 0;
eEntregasFuncionario2[e] = 0;
eEntregasFuncionario3[e] = 0;
new ValorNaMsg[11]; format(ValorNaMsg, sizeof(ValorNaMsg), "%d", eValor[e]);
format(eMensagemVenda[e], 50, "{FFFF00}A venda por {00FF00}$%s", AttNumeroDecimal(ValorNaMsg));
}
}
DOF2_SetString(String, "Dono", eDono[e]);
DOF2_SetInt(String, "Valor", eValor[e]);
DOF2_SetInt(String, "Lucro", eLucro[e]);
DOF2_SetInt(String, "Producao", eProducao[e]);
DOF2_SetInt(String, "Impostos", eImpostos[e]);
DOF2_SetInt(String, "Avenda", eAvenda[e]);
DOF2_SetInt(String, "Contratando", eContratando[e]);
DOF2_SetString(String, "Funcionario1", eFuncionario1[e]);
DOF2_SetInt(String, "EntregasFuncionario1", eEntregasFuncionario1[e]);
DOF2_SetString(String, "Funcionario2", eFuncionario2[e]);
DOF2_SetInt(String, "EntregasFuncionario2", eEntregasFuncionario2[e]);
DOF2_SetString(String, "Funcionario3", eFuncionario3[e]);
DOF2_SetInt(String, "EntregasFuncionario3", eEntregasFuncionario3[e]);
DOF2_SetString(String, "msgvenda", eMensagemVenda[e]);
}
}
for(new p; p < MAX_POSTOS; p++)
{
format(String, sizeof(String), "Postos/%d.ini", p);
if(DOF2_FileExists(String))
{
if(!new_strcmp(pDono[p], "Ninguem"))
{
if(h == 6)
{
pImpostos[p] ++;
}
if(pImpostos[p] >= 15)
{
pImpostos[p] = 0;
pLucro[p] = 0;
pAvenda[p] = 0;
format(pDono[p], 25, "Ninguem");
}
}
DOF2_SetString(String, "Dono", pDono[p]);
DOF2_SetInt(String, "Impostos", pImpostos[p]);
DOF2_SetInt(String, "Lucro", pLucro[p]);
DOF2_SetInt(String, "Litros", pLitros[p]);
DOF2_SetInt(String, "AVenda", pAvenda[p]);
}
}
for(new i; i < MAX_FAZENDA; i++)
{
format(String, sizeof(String), "Fazendas/%d.ini", i);
if(DOF2_FileExists(String))
{
if(!new_strcmp(f_info[i][f_dono], "Ninguem"))
{
if(h == 6)
{
f_info[i][f_imposto] ++;
}
if(f_info[i][f_imposto] >= 15)
{
format(f_info[i][f_dono], 25, "Ninguem");
format(f_info[i][f_funcionario0], 25, "Ninguem");
format(f_info[i][f_funcionario1], 25, "Ninguem");
format(f_info[i][f_funcionario2], 25, "Ninguem");
format(f_info[i][f_nome], 31, "N/A");
f_info[i][f_produtos] = 0;
f_info[i][f_imposto] = 0;
f_info[i][f_cofre] = 0;
f_info[i][f_contratando] = 0;
}
}
DOF2_SetString(String, "Nome", f_info[i][f_nome]);
DOF2_SetString(String, "Dono", f_info[i][f_dono]);
DOF2_SetString(String, "Funcionario0", f_info[i][f_funcionario0]);
DOF2_SetString(String, "Funcionario1", f_info[i][f_funcionario1]);
DOF2_SetString(String, "Funcionario2", f_info[i][f_funcionario2]);
DOF2_SetInt(String, "Produtos", f_info[i][f_produtos]);
DOF2_SetInt(String, "Imposto", f_info[i][f_imposto]);
DOF2_SetInt(String, "Cofre", f_info[i][f_cofre]);
DOF2_SetInt(String, "Contratando", f_info[i][f_contratando]);
}
}
for(new cx; cx < 40; cx++)
{
format(String, sizeof(String), "CaixasEletronicos/%d.ini", cx);
if(DOF2_FileExists(String))
{
DOF2_SetInt(String, "Valor", CaixaMoney[cx]);
}
}
DOF2_SetInt("CaixaPref.ini", "DESEMPREGADO", SALARIODESEMPREGADO);
DOF2_SetInt("CaixaPref.ini", "CACADOR", SALARIOCACADOR);
DOF2_SetInt("CaixaPref.ini", "JORNALISTA", SALARIOJORNALISTA);
DOF2_SetInt("CaixaPref.ini", "PESCADOR", SALARIOPESCADOR);
DOF2_SetInt("CaixaPref.ini", "VENDEDOR", SALARIOVENDEDOR);
DOF2_SetInt("CaixaPref.ini", "LENHADOR", SALARIOLENHADOR);
DOF2_SetInt("CaixaPref.ini", "TAXISTA", SALARIOTAXISTA);
DOF2_SetInt("CaixaPref.ini", "GARI", SALARIOGARI);
DOF2_SetInt("CaixaPref.ini", "AGENTEDETRAN", SALARIOAGENTEDETRAN);
DOF2_SetInt("CaixaPref.ini", "MECANICO", SALARIOMECANICO);
DOF2_SetInt("CaixaPref.ini", "DNIT", SALARIODNIT);
DOF2_SetInt("CaixaPref.ini", "ADVOGADO", SALARIOADVOGADO);
DOF2_SetInt("CaixaPref.ini", "BOMBEIRO", SALARIOBOMBEIRO);
DOF2_SetInt("CaixaPref.ini", "PARAMEDICO", SALARIOPARAMEDICO);
DOF2_SetInt("CaixaPref.ini", "PETROLEIRO", SALARIOPETROLEIRO);
DOF2_SetInt("CaixaPref.ini", "CAMINHONEIRO", SALARIOCAMINHONEIRO);
DOF2_SetInt("CaixaPref.ini", "MINERADOR", SALARIOMINERADOR);
DOF2_SetInt("CaixaPref.ini", "MOTORISTABUS", SALARIOMOTORISTABUS);
DOF2_SetInt("CaixaPref.ini", "FERROVIARIA", SALARIOFERROVIARIA);
DOF2_SetInt("CaixaPref.ini", "PILOTO", SALARIOPILOTO);
DOF2_SetInt("CaixaPref.ini", "MOTOBOY", SALARIOMOTOBOY);
DOF2_SetInt("CaixaPref.ini", "CARROFORTE", SALARIOCARROFORTE);
DOF2_SetInt("CaixaPref.ini", "PM", SALARIOPM);
DOF2_SetInt("CaixaPref.ini", "ROTA", SALARIOROTA);
DOF2_SetInt("CaixaPref.ini", "CHOQUE", SALARIOCHOQUE);
DOF2_SetInt("CaixaPref.ini", "ROTAM", SALARIOROTAM);
DOF2_SetInt("CaixaPref.ini", "BOPE", SALARIOBOPE);
DOF2_SetInt("CaixaPref.ini", "PC", SALARIOPC);
DOF2_SetInt("CaixaPref.ini", "PF", SALARIOPF);
DOF2_SetInt("CaixaPref.ini", "EXERCITO", SALARIOEXERCITO);
DOF2_SetInt("CaixaPref.ini", "APOSENTADO", SALARIOAPOSENTADO);
DOF2_SetInt("CaixaPref.ini", "PREFEITO", SALARIOPREFEITO);
DOF2_SetInt("CaixaPref.ini", "Valor", CaixaPref);
DOF2_SetInt("CaixaPref.ini", "Arma1PM", Arma1PM);
DOF2_SetInt("CaixaPref.ini", "Arma2PM", Arma2PM);
DOF2_SetInt("CaixaPref.ini", "Arma3PM", Arma3PM);
DOF2_SetInt("CaixaPref.ini", "Municao1PM", Municao1PM);
DOF2_SetInt("CaixaPref.ini", "Municao2PM", Municao2PM);
DOF2_SetInt("CaixaPref.ini", "Municao3PM", Municao3PM);
DOF2_SetInt("CaixaPref.ini", "Arma1ROTA", Arma1ROTA);
DOF2_SetInt("CaixaPref.ini", "Arma2ROTA", Arma2ROTA);
DOF2_SetInt("CaixaPref.ini", "Arma3ROTA", Arma3ROTA);
DOF2_SetInt("CaixaPref.ini", "Municao1ROTA", Municao1ROTA);
DOF2_SetInt("CaixaPref.ini", "Municao2ROTA", Municao2ROTA);
DOF2_SetInt("CaixaPref.ini", "Municao3ROTA", Municao3ROTA);
DOF2_SetInt("CaixaPref.ini", "Arma1CHOQUE", Arma1CHOQUE);
DOF2_SetInt("CaixaPref.ini", "Arma2CHOQUE", Arma2CHOQUE);
DOF2_SetInt("CaixaPref.ini", "Arma3CHOQUE", Arma3CHOQUE);
DOF2_SetInt("CaixaPref.ini", "Municao1CHOQUE", Municao1CHOQUE);
DOF2_SetInt("CaixaPref.ini", "Municao2CHOQUE", Municao2CHOQUE);
DOF2_SetInt("CaixaPref.ini", "Municao3CHOQUE", Municao3CHOQUE);
DOF2_SetInt("CaixaPref.ini", "Arma1BOPE", Arma1BOPE);
DOF2_SetInt("CaixaPref.ini", "Arma2BOPE", Arma2BOPE);
DOF2_SetInt("CaixaPref.ini", "Arma3BOPE", Arma3BOPE);
DOF2_SetInt("CaixaPref.ini", "Municao1BOPE", Municao1BOPE);
DOF2_SetInt("CaixaPref.ini", "Municao2BOPE", Municao2BOPE);
DOF2_SetInt("CaixaPref.ini", "Municao3BOPE", Municao3BOPE);
DOF2_SetInt("CaixaPref.ini", "Arma1PC", Arma1PC);
DOF2_SetInt("CaixaPref.ini", "Arma2PC", Arma2PC);
DOF2_SetInt("CaixaPref.ini", "Arma3PC", Arma3PC);
DOF2_SetInt("CaixaPref.ini", "Municao1PC", Municao1PC);
DOF2_SetInt("CaixaPref.ini", "Municao2PC", Municao2PC);
DOF2_SetInt("CaixaPref.ini", "Municao3PC", Municao3PC);
DOF2_SetInt("CaixaPref.ini", "Arma1PF", Arma1PF);
DOF2_SetInt("CaixaPref.ini", "Arma2PF", Arma2PF);
DOF2_SetInt("CaixaPref.ini", "Arma3PF", Arma3PF);
DOF2_SetInt("CaixaPref.ini", "Municao1PF", Municao1PF);
DOF2_SetInt("CaixaPref.ini", "Municao2PF", Municao2PF);
DOF2_SetInt("CaixaPref.ini", "Municao3PF", Municao3PF);
DOF2_SetInt("CaixaPref.ini", "Arma1ROTAM", Arma1ROTAM);
DOF2_SetInt("CaixaPref.ini", "Arma2ROTAM", Arma2ROTAM);
DOF2_SetInt("CaixaPref.ini", "Arma3ROTAM", Arma3ROTAM);
DOF2_SetInt("CaixaPref.ini", "Municao1ROTAM", Municao1ROTAM);
DOF2_SetInt("CaixaPref.ini", "Municao2ROTAM", Municao2ROTAM);
DOF2_SetInt("CaixaPref.ini", "Municao3ROTAM", Municao3ROTAM);
DOF2_SetInt("CaixaPref.ini", "Arma1EXERCITO", Arma1EXERCITO);
DOF2_SetInt("CaixaPref.ini", "Arma2EXERCITO", Arma2EXERCITO);
DOF2_SetInt("CaixaPref.ini", "Arma3EXERCITO", Arma3EXERCITO);
DOF2_SetInt("CaixaPref.ini", "Municao1EXERCITO", Municao1EXERCITO);
DOF2_SetInt("CaixaPref.ini", "Municao2EXERCITO", Municao2EXERCITO);
DOF2_SetInt("CaixaPref.ini", "Municao3EXERCITO", Municao3EXERCITO);
DOF2_SetInt("CaixaPref.ini", "Eleicao", Eleicao);
DOF2_SetInt("CaixaPref.ini", "Quantidade", CaixaPref);
DOF2_SetInt("CofreFavela.ini", "Quantidade", CofreFavela);
DOF2_SetFloat("BTC.ini", "Oferta", Oferta);
DOF2_SetFloat("BTC.ini", "Demanda", Demanda);
DOF2_SetFloat("BTC.ini", "Mercado", Mercado);
DOF2_SetString("Private.ini", "Dono", PrivateDono);
DOF2_SetInt("Private.ini", "Lucro", PrivateLucro);
DOF2_SetInt("Lotofacil.ini", "Quantidade", AcumuladosLotofacil);
DOF2_SetInt("MegaSena.ini", "Quantidade", AcumuladosMegasena);
new vetorlinha[10];
for(new g; g < 30; g++)
{
format(vetorlinha, sizeof(vetorlinha), "Linha%d", g);
DOF2_SetString("GanhadoresLoteria.ini", vetorlinha, GanhadoresLoteria[g]);
DOF2_SetString("TrocasDeNick.ini", vetorlinha, TrocasDeNick[g]);
DOF2_SetString("BTC.ini", vetorlinha, MercadoBitcoin[g]);
}
new StrE[20];
for(new e; e < 10; e++)
{
format(StrE, sizeof(StrE), "Candidato%d", e);
DOF2_SetString("CaixaPref.ini", StrE, Candidato[e]);
format(StrE, sizeof(StrE), "SkinCandidato%d", e);
DOF2_SetInt("CaixaPref.ini", StrE, SkinCandidato[e]);
}
DOF2_SetInt("Materiais.ini", "DonoFavela0", DonoFavela[0]);
DOF2_SetInt("Materiais.ini", "DonoFavela1", DonoFavela[1]);
DOF2_SetInt("Materiais.ini", "DonoFavela2", DonoFavela[2]);
for(new g; g < MAX_ORG; g++)
{
format(StrE, sizeof(StrE), "Orgs/%d.ini", g);
if(DOF2_FileExists(StrE))
{
DOF2_SetString(StrE, "Nome", gNome[g]);
DOF2_SetString(StrE, "Lider", gLider[g]);
DOF2_SetString(StrE, "Sublider", gSublider[g]);
DOF2_SetString(StrE, "Membro0", gMembro[g][0]);
DOF2_SetString(StrE, "Membro1", gMembro[g][1]);
DOF2_SetString(StrE, "Membro2", gMembro[g][2]);
DOF2_SetString(StrE, "Membro3", gMembro[g][3]);
DOF2_SetString(StrE, "Membro4", gMembro[g][4]);
DOF2_SetString(StrE, "Membro5", gMembro[g][5]);
DOF2_SetString(StrE, "Membro6", gMembro[g][6]);
DOF2_SetString(StrE, "Membro7", gMembro[g][7]);
DOF2_SetString(StrE, "Membro8", gMembro[g][8]);
DOF2_SetString(StrE, "Membro9", gMembro[g][9]);
DOF2_SetString(StrE, "Membro10", gMembro[g][10]);
DOF2_SetString(StrE, "Membro11", gMembro[g][11]);
DOF2_SetString(StrE, "Membro12", gMembro[g][12]);
DOF2_SetString(StrE, "Membro13", gMembro[g][13]);
DOF2_SetString(StrE, "Membro14", gMembro[g][14]);
DOF2_SetString(StrE, "Membro15", gMembro[g][15]);
DOF2_SetString(StrE, "Membro16", gMembro[g][16]);
DOF2_SetString(StrE, "Membro17", gMembro[g][17]);
DOF2_SetString(StrE, "Cor", gCor[g]);
DOF2_SetInt(StrE, "Skin", gSkin[g]);
DOF2_SetInt(StrE, "VeiculoModel0", gVeiculoModel[g][0]);
DOF2_SetInt(StrE, "VeiculoModel1", gVeiculoModel[g][1]);
DOF2_SetInt(StrE, "VeiculoModel2", gVeiculoModel[g][2]);
DOF2_SetInt(StrE, "VeiculoModel3", gVeiculoModel[g][3]);
DOF2_SetInt(StrE, "VeiculoModel4", gVeiculoModel[g][4]);
DOF2_SetInt(StrE, "Cor1", gCor1[g]);
DOF2_SetInt(StrE, "Cor2", gCor2[g]);
DOF2_SetInt(StrE, "Materiais", gMateriais[g]);
DOF2_SetInt(StrE, "Maconha", gMaconha[g]);
DOF2_SetInt(StrE, "Cofre", gCofre[g]);
DOF2_SetInt(StrE, "ValorEntrega", gValorEntrega[g]);
DOF2_SetInt(StrE, "Timer", gTimer[g]);
DOF2_SetInt(StrE, "Tempo", gTempo[g]);
}
}
DOF2_SaveFile();
}
stock SalvarPlayer(playerid)
{
GetPlayerPos(playerid, PosX[playerid], PosY[playerid], PosZ[playerid]);
GetPlayerFacingAngle(playerid, PosR[playerid]);
format(String, sizeof(String), "Contas/%s.ini", PlayerName(playerid));
if(DOF2_FileExists(String))
{
new ARMAA[13], MUNICAOO[13], Arma_[10], Bala_[10];
for(new i = 0; i < 13; i++)
{
GetPlayerWeaponData(playerid,i,ARMAA[i],MUNICAOO[i]);
if(!ArmaProibida(ARMAA[i]))
{
format(Arma_,10,"Arma%d",i);
format(Bala_,10,"Municao%d",i);
DOF2_SetInt(String, Arma_, ARMAA[i]);
DOF2_SetInt(String, Bala_, MUNICAOO[i]);
}
}
new strjbl[30];
for(new j; j < 10; j++)
{
format(strjbl, sizeof(strjbl), "NomeMusica%d", j);
DOF2_SetString(String, strjbl, NomePlaylist[playerid][j]);
format(strjbl, sizeof(strjbl), "LinkMusica%d", j);
DOF2_SetString(String, strjbl, Playlist[playerid][j]);
}
GetPlayerHealth(playerid, Vidap[playerid]); GetPlayerArmour(playerid, Coletep[playerid]);
DOF2_SetInt(String, "Skin", SkinPlayer[playerid]);
DOF2_SetInt(String, "Rg", RgPlayer[playerid]);
DOF2_SetInt(String, "Level", Level[playerid]);
DOF2_SetInt(String, "mUP", mUP[playerid]);
DOF2_SetInt(String, "sUP", sUP[playerid]);
DOF2_SetInt(String, "Fome", FOME[playerid]);
DOF2_SetInt(String, "Sede", SEDE[playerid]);
DOF2_SetInt(String, "Sono", SONO[playerid]);
DOF2_SetInt(String, "Money", Money[playerid]);
DOF2_SetInt(String, "DinheiroSujo", DinheiroSujo[playerid]);
DOF2_SetInt(String, "SaldoBancario", SaldoBancario[playerid]);
DOF2_SetInt(String, "Celular", Celular[playerid]);
DOF2_SetInt(String, "CreditosCelular", CreditosCelular[playerid]);
DOF2_SetInt(String, "SemParar", SemParar[playerid]);
DOF2_SetInt(String, "UsouCMDBNF300", UsouCMDBNF[playerid]);
DOF2_SetInt(String, "Multa", Multa[playerid]);
DOF2_SetInt(String, "ValorMulta", ValorMulta[playerid]);
DOF2_SetInt(String, "BlockAssaltouCaixa", BlockAssaltouCaixa[playerid]);
DOF2_SetInt(String, "BlockAssaltouBanco", BlockAssaltouBanco[playerid]);
DOF2_SetInt(String, "BlockAssaltoCX", BlockAssaltoCX[playerid]);
DOF2_SetInt(String, "BlockPlayerAssalto", BlockPlayerAssalto[playerid]);
DOF2_SetInt(String, "RecebeuSalario", RecebeuSalario[playerid]);
DOF2_SetInt(String, "Prof", PROF[playerid]);
DOF2_SetInt(String, "Org", ORG[playerid]);
DOF2_SetInt(String, "VIP", VIP[playerid]);
DOF2_SetInt(String, "TIPOVIP", TIPOVIP[playerid]);
DOF2_SetInt(String, "KitCorrida", KitCorrida[playerid]);
DOF2_SetInt(String, "KitFesta", KitFesta[playerid]);
DOF2_SetInt(String, "Coins", COINS[playerid]);
DOF2_SetInt(String, "PlanoSaude", PlanoSaude[playerid]);
DOF2_SetInt(String, "Estagiario", Estagiario[playerid]);
DOF2_SetInt(String, "Avisos", Avisos[playerid]);
DOF2_SetInt(String, "MUV", MUV[playerid]);
DOF2_SetInt(String, "Votou", Votou[playerid]);
DOF2_SetFloat(String, "GasolinaBalao", GasolinaBalao[playerid]);
DOF2_SetInt(String, "Porte", Porte[playerid]);
DOF2_SetInt(String, "Notas", Notas[playerid]);
DOF2_SetInt(String, "HabilitacaoA", HabilitacaoA[playerid]);
DOF2_SetInt(String, "HabilitacaoB", HabilitacaoB[playerid]);
DOF2_SetInt(String, "HabilitacaoC", HabilitacaoC[playerid]);
DOF2_SetInt(String, "HabilitacaoD", HabilitacaoD[playerid]);
DOF2_SetInt(String, "HabilitacaoE", HabilitacaoE[playerid]);
DOF2_SetInt(String, "HabilitacaoF", HabilitacaoF[playerid]);
DOF2_SetInt(String, "HabilitacaoG", HabilitacaoG[playerid]);
DOF2_SetInt(String, "SegundosSalarioAdmin", SegundosSalarioAdmin[playerid]);
DOF2_SetInt(String, "Procurado", NivelProcurado[playerid]);
DOF2_SetInt(String, "HorasPreso", HorasPreso[playerid]);
DOF2_SetInt(String, "MinutosPreso", MinutosPreso[playerid]);
DOF2_SetInt(String, "SegundosPreso", SegundosPreso[playerid]);
DOF2_SetString(String, "MotivoPrisaoAdmin", MotivoPrisaoAdmin[playerid]);
DOF2_SetInt(String, "MinutosMorte", MinutosMorte[playerid]);
DOF2_SetInt(String, "SegundosMorte", SegundosMorte[playerid]);
DOF2_SetInt(String, "EntrouEmpresa", EntrouEmpresa[playerid]);
DOF2_SetInt(String, "EntrouCasa", EntrouCasa[playerid]);
DOF2_SetInt(String, "EntrouAreaVip", EntrouAreaVip[playerid]);
DOF2_SetInt(String, "EmContrato", EmContrato[playerid]);
DOF2_SetString(String, "CORTAGVIP", CORTAGVIP[playerid]);
DOF2_SetInt(String, "Alvara", Alvara[playerid]);
DOF2_SetFloat(String, "Vida", Vidap[playerid]);
DOF2_SetFloat(String, "Colete", Coletep[playerid]);
DOF2_SetFloat(String, "BTC", BTC[playerid]);
DOF2_SetInt(String, "Mochila", Mochila[playerid]);
new MT[26];
for(new m; m < GetPlayerVoltas(playerid); m++)
{
format(MT, sizeof(MT), "SlotMochila%d", m);
DOF2_SetInt(String, MT, SlotMochila[playerid][m]);
format(MT, sizeof(MT), "QuantidadeSlotMochila%d", m);
DOF2_SetInt(String, MT, QuantidadeSlotMochila[playerid][m]);
}
DOF2_SetInt(String, "PegouMercadoria", PegouMercadoria[playerid]);
DOF2_SetInt(String, "EntrouHosp", EntrouHosp[playerid]);
DOF2_SetInt(String, "EntrouDP", EntrouDP[playerid]);
DOF2_SetInt(String, "EntrouBanco", EntrouBanco[playerid]);
DOF2_SetInt(String, "EntrouPref", EntrouPref[playerid]);
DOF2_SetInt(String, "EntrouAutoEscola", EntrouAutoEscola[playerid]);
DOF2_SetInt(String, "EntrouDetran", EntrouDetran[playerid]);
DOF2_SetInt(String, "EntrouAgencia", EntrouAgencia[playerid]);
DOF2_SetInt(String, "DiaPresente", DiaPresente[playerid]);
DOF2_SetFloat(String, "PosX", PosX[playerid]);
DOF2_SetFloat(String, "PosY", PosY[playerid]);
DOF2_SetFloat(String, "PosZ", PosZ[playerid]);
DOF2_SetFloat(String, "PosR", PosR[playerid]);
DOF2_SetInt(String, "UltimoLogin1", gettime());
DOF2_SetInt(String, "UltimoInterior", GetPlayerInterior(playerid));
DOF2_SetInt(String, "idfixo", id_fixo[playerid]);
DOF2_SetInt(String, "LevelImpostoCasa", LevelImpostoCasa[playerid]);
DOF2_SetInt(String, "LevelImpostoEmpresa", LevelImpostoEmpresa[playerid]);
DOF2_SetInt(String, "LevelImpostoPosto", LevelImpostoPosto[playerid]);
if(GetPlayerVirtualWorld(playerid) >= 0)
{
DOF2_SetInt(String, "UltimoMundo", GetPlayerVirtualWorld(playerid));
}
else
{
DOF2_SetInt(String, "UltimoMundo", 0);
}
format(String, sizeof(String), "Acessorios/%s.ini", PlayerName(playerid));
if(DOF2_FileExists(String))
{
for(new m; m < 6; m++)
{
format(MT, sizeof(MT), "ModeloItem%d", m);
DOF2_SetInt(String, MT, ModeloItem[playerid][m]);
format(MT, sizeof(MT), "OssoItem%d", m);
DOF2_SetInt(String, MT, OssoItem[playerid][m]);
for(new o; o < 9; o++)
{
format(MT, sizeof(MT), "PosItem%d%d", m, o);
DOF2_SetFloat(String, MT, PosItem[playerid][m][o]);
}
}
for(new m; m < 30; m++)
{
format(strjbl, sizeof(strjbl), "contatoplayer%d", m);
DOF2_SetString(String, strjbl, ContatoPlayer[playerid][m]);
format(strjbl, sizeof(strjbl), "numerocontatoplayer%d", m);
DOF2_SetInt(String, strjbl, NumeroContatoPlayer[playerid][m]);
}
}
if(NivelAdmin[playerid] > 0)
{
format(String, sizeof(String), "Admins/%s.ini", PlayerName(playerid));
if(!DOF2_FileExists(String))
{
DOF2_CreateFile(String);
}
DOF2_SetInt(String, "Nivel", NivelAdmin[playerid]);
}
else if(Estagiario[playerid] > 0)
{
format(String, sizeof(String), "Admins/%s.ini", PlayerName(playerid));
if(!DOF2_FileExists(String))
{
DOF2_CreateFile(String);
}
DOF2_SetInt(String, "Nivel", 0);
}
DOF2_SaveFile();
}
}
stock ArmaProibida(arma)
{
new result;
switch(arma)
{
case 16, 17, 18, 35, 36, 37, 38, 39, 40: result = 1;
default: result = 0;
}
return result;
}
forward Tq_AutoRep(xLocal);
public Tq_AutoRep(xLocal){
LojaSt[xLocal][yQ_Stts] = 0;
return 1;
}
stock GetId(id)
{
foreach(Player, i)
{
if(IsPlayerConnected(i) && id_fixo[i] == id) return i;
}
return 500;
}
stock AttTag(playerid)
{
if(VIP[playerid] >= 1)
{
new TagV[7];
for(new t; t < 6; t++)
{
TagV[t] = CORTAGVIP[playerid][t+2];
}
format(myid[playerid], 12, "{%s}VIP", TagV);
return 1;
}
return 1;
}
stock CreateStrip(Float:x,Float:y,Float:z,Float:Angle)
{
for(new p = 0; p < sizeof(SpikeInfo); p++)
{
if(SpikeInfo[p][sCreated] == 0)
{
SpikeInfo[p][sCreated]=1;
SpikeInfo[p][sX]=x;
SpikeInfo[p][sY]=y;
SpikeInfo[p][sZ]=z-0.7;
SpikeInfo[p][sObject] = CreateDynamicObject(2899, x, y, z-0.9, 0, 0, Angle-90);
return 1;
}
}
return 0;
}
stock DeleteAllStrip()
{
for(new i = 0; i < sizeof(SpikeInfo); i++)
{
if(SpikeInfo[i][sCreated] == 1)
{
SpikeInfo[i][sCreated]=0;
SpikeInfo[i][sX]=0.0;
SpikeInfo[i][sY]=0.0;
SpikeInfo[i][sZ]=0.0;
DestroyDynamicObject(SpikeInfo[i][sObject]);
}
}
return 0;
}
stock DeleteClosestStrip(Float:x,Float:y,Float:z)
{
for(new i = 0; i < sizeof(SpikeInfo); i++)
{
if(IsPointInRangeOfPoint(x, y, z, SpikeInfo[i][sX], SpikeInfo[i][sY], SpikeInfo[i][sZ], 2.0))
{
if(SpikeInfo[i][sCreated] == 1)
{
SpikeInfo[i][sCreated]=0;
SpikeInfo[i][sX]=0.0;
SpikeInfo[i][sY]=0.0;
SpikeInfo[i][sZ]=0.0;
DestroyDynamicObject(SpikeInfo[i][sObject]);
}
}
}
return 0;
}
stock uQ_ResetDrop(xArmaid){
BSArmas[xArmaid] = 0;
BSQntMunc[xArmaid] = 0;
DestroyDynamicObject(BSDefObj[xArmaid]);
BSPos[0][xArmaid] = 0.0;
BSPos[1][xArmaid] = 0.0;
BSPos[2][xArmaid] = 0.0;
BSSenha[xArmaid] = 0;
BS_TimeDrp[xArmaid] = 0;
return 1;
}
encode_tires(tires1, tires2, tires3, tires4) {
return tires1 | (tires2 << 1) | (tires3 << 2) | (tires4 << 3);
}
stock RemovePlayerWeapon(playerid, weaponid)
{
new pWeaponData[13][2];
for (new i = 0; i < 13; i++)
{
GetPlayerWeaponData(playerid, i, pWeaponData[i][0], pWeaponData[i][1]);
}
ResetPlayerWeaponsExC(playerid);
for(new i=0; i<13; i++)
{
if(pWeaponData[i][0] != 0 && pWeaponData[i][0] != weaponid)
{
GivePlayerWeaponExC(playerid, pWeaponData[i][0], pWeaponData[i][1]);
}
}
return 0;
}
stock GerarCodigo(caracteres)
{
new Codigo[31];
for(new c; c < caracteres; c++)
{
new r = random(36);
if(r == 0){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "Q");}else{format(Codigo[c], 20, "a");}}
else if(r == 1){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "W");}else{format(Codigo[c], 20, "w");}}
else if(r == 2){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "E");}else{format(Codigo[c], 20, "e");}}
else if(r == 3){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "R");}else{format(Codigo[c], 20, "r");}}
else if(r == 4){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "T");}else{format(Codigo[c], 20, "t");}}
else if(r == 5){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "Y");}else{format(Codigo[c], 20, "y");}}
else if(r == 6){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "U");}else{format(Codigo[c], 20, "u");}}
else if(r == 7){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "I");}else{format(Codigo[c], 20, "i");}}
else if(r == 8){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "O");}else{format(Codigo[c], 20, "o");}}
else if(r == 9){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "P");}else{format(Codigo[c], 20, "p");}}
else if(r == 10){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "A");}else{format(Codigo[c], 20, "a");}}
else if(r == 11){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "S");}else{format(Codigo[c], 20, "s");}}
else if(r == 12){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "D");}else{format(Codigo[c], 20, "d");}}
else if(r == 13){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "F");}else{format(Codigo[c], 20, "f");}}
else if(r == 14){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "G");}else{format(Codigo[c], 20, "g");}}
else if(r == 15){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "H");}else{format(Codigo[c], 20, "h");}}
else if(r == 16){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "J");}else{format(Codigo[c], 20, "j");}}
else if(r == 17){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "K");}else{format(Codigo[c], 20, "k");}}
else if(r == 18){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "L");}else{format(Codigo[c], 20, "l");}}
else if(r == 19){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "Z");}else{format(Codigo[c], 20, "z");}}
else if(r == 20){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "X");}else{format(Codigo[c], 20, "x");}}
else if(r == 21){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "C");}else{format(Codigo[c], 20, "c");}}
else if(r == 22){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "V");}else{format(Codigo[c], 20, "v");}}
else if(r == 23){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "B");}else{format(Codigo[c], 20, "b");}}
else if(r == 24){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "N");}else{format(Codigo[c], 20, "n");}}
else if(r == 25){new rr = random(2);if(rr == 0){format(Codigo[c], 20, "M");}else{format(Codigo[c], 20, "m");}}
else if(r == 26){format(Codigo[c], 20, "0");}
else if(r == 27){format(Codigo[c], 20, "1");}
else if(r == 28){format(Codigo[c], 20, "2");}
else if(r == 29){format(Codigo[c], 20, "3");}
else if(r == 30){format(Codigo[c], 20, "4");}
else if(r == 31){format(Codigo[c], 20, "5");}
else if(r == 32){format(Codigo[c], 20, "6");}
else if(r == 33){format(Codigo[c], 20, "7");}
else if(r == 34){format(Codigo[c], 20, "8");}
else if(r == 35){format(Codigo[c], 20, "9");}
}
return Codigo;
}
stock GerarCodigoHash(caracteres)
{
new Codigo[31];
for(new c; c < caracteres; c++)
{
new r = random(36);
if(r == 0){format(Codigo[c], 20, "Q");}
else if(r == 1){format(Codigo[c], 20, "W");}
else if(r == 2){format(Codigo[c], 20, "E");}
else if(r == 3){format(Codigo[c], 20, "R");}
else if(r == 4){format(Codigo[c], 20, "T");}
else if(r == 5){format(Codigo[c], 20, "Y");}
else if(r == 6){format(Codigo[c], 20, "U");}
else if(r == 7){format(Codigo[c], 20, "I");}
else if(r == 8){format(Codigo[c], 20, "O");}
else if(r == 9){format(Codigo[c], 20, "P");}
else if(r == 10){format(Codigo[c], 20, "A");}
else if(r == 11){format(Codigo[c], 20, "S");}
else if(r == 12){format(Codigo[c], 20, "D");}
else if(r == 13){format(Codigo[c], 20, "F");}
else if(r == 14){format(Codigo[c], 20, "G");}
else if(r == 15){format(Codigo[c], 20, "H");}
else if(r == 16){format(Codigo[c], 20, "J");}
else if(r == 17){format(Codigo[c], 20, "K");}
else if(r == 18){format(Codigo[c], 20, "L");}
else if(r == 19){format(Codigo[c], 20, "Z");}
else if(r == 20){format(Codigo[c], 20, "X");}
else if(r == 21){format(Codigo[c], 20, "C");}
else if(r == 22){format(Codigo[c], 20, "V");}
else if(r == 23){format(Codigo[c], 20, "B");}
else if(r == 24){format(Codigo[c], 20, "N");}
else if(r == 25){format(Codigo[c], 20, "M");}
else if(r == 26){format(Codigo[c], 20, "0");}
else if(r == 27){format(Codigo[c], 20, "1");}
else if(r == 28){format(Codigo[c], 20, "2");}
else if(r == 29){format(Codigo[c], 20, "3");}
else if(r == 30){format(Codigo[c], 20, "4");}
else if(r == 31){format(Codigo[c], 20, "5");}
else if(r == 32){format(Codigo[c], 20, "6");}
else if(r == 33){format(Codigo[c], 20, "7");}
else if(r == 34){format(Codigo[c], 20, "8");}
else if(r == 35){format(Codigo[c], 20, "9");}
}
return Codigo;
}
stock HexToInt(const string[])
{
if(!string[0]) return 0;
new cur = 1, res = 0;
for(new i = strlen(string); i > 0; i--)
{
res += cur * (string[i - 1] - ((string[i - 1] < 58) ? (48) : (55)));
cur = cur * 16;
}
return res;
}
stock EfectCamSkin(playerid)
{
if(GetPlayerInterior(playerid) == 15)
{
SetPlayerPos(playerid, 217.5797, -98.5492, 1005.2578); SetPlayerFacingAngle(playerid, 358.5711);
InterpolateCameraPos(playerid, 214.072113, -99.076202, 1005.771972, 215.422348, -99.000694, 1005.919311, 10000);
InterpolateCameraLookAt(playerid, 219.068542, -99.154808, 1005.600341, 220.397079, -99.142913, 1005.437805, 10000);
}
else if(GetPlayerInterior(playerid) == 1)
{
SetPlayerPos(playerid, 214.6457, -40.9276, 1002.0234); SetPlayerFacingAngle(playerid, 360.0);
InterpolateCameraPos(playerid, 209.318283, -41.713188, 1002.638244, 212.253372, -41.578704, 1002.498657, 10000);
InterpolateCameraLookAt(playerid, 214.302276, -41.900070, 1002.284790, 217.244354, -41.658863, 1002.209350, 10000);
}
else if(GetPlayerInterior(playerid) == 14)
{
SetPlayerPos(playerid, 215.8977,-155.5384,1000.5234); SetPlayerFacingAngle(playerid, 0.0);
InterpolateCameraPos(playerid, 212.032608, -156.437530, 1001.159851, 213.633255, -156.424957, 1001.047180, 10000);
InterpolateCameraLookAt(playerid, 217.024230, -156.442840, 1000.870544, 218.629287, -156.344665, 1000.864807, 10000);
}
else if(GetPlayerInterior(playerid) == 3)
{
SetPlayerPos(playerid, 199.2535,-127.3301,1003.5152); SetPlayerFacingAngle(playerid, 90.0);
InterpolateCameraPos(playerid, 200.046279, -130.464950, 1004.145996, 199.998214, -129.409408, 1004.077575, 10000);
InterpolateCameraLookAt(playerid, 199.805145, -125.481117, 1003.824584, 199.820999, -124.418632, 1003.831054, 10000);
}
else if(GetPlayerInterior(playerid) == 5)
{
SetPlayerPos(playerid, 207.8346,-5.5455,1005.2109); SetPlayerFacingAngle(playerid, 180.0);
InterpolateCameraPos(playerid, 211.631164, -4.781353, 1005.750000, 210.577728, -4.797150, 1005.675354, 10000);
InterpolateCameraLookAt(playerid, 206.644226, -4.856137, 1005.396545, 205.590789, -4.871933, 1005.321899, 10000);
}
new RandomCam = random(3);
if(RandomCam == 0)
{
ApplyAnimation(playerid, "CLOTHES", "CLO_POSE_TORSO", 4.1, 1, 0, 0, 0, 0, 1);
}
else if(RandomCam == 1)
{
ApplyAnimation(playerid, "CLOTHES", "CLO_POSE_LEGS", 4.1, 1, 0, 0, 0, 0, 1);
}
else if(RandomCam == 2)
{
ApplyAnimation(playerid, "CLOTHES", "CLO_POSE_LOOP", 4.1, 1, 0, 0, 0, 0, 1);
}
}
stock SkinFeminina(skin)
{
new result;
switch(skin)
{
case 9, 10, 11, 12, 13, 31, 38, 39, 40, 41, 53, 54, 55, 56, 63, 64, 65, 69, 75, 76, 77, 85, 87, 88, 89, 90, 91, 92, 93, 129, 130, 131,
138, 139, 140, 141, 145, 148, 150, 151, 152, 157, 169, 172, 178, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 201, 205, 207, 211,
214, 215, 216, 218, 219, 224, 225, 226, 231, 232, 233, 237, 238, 243, 244, 245, 246, 251, 256, 257, 263, 298, 306, 307, 308, 309: result = 1;
default: result = 0;
}
return result;
}
stock SkinBloqueada(skin)
{
new result;
switch(skin)
{
case 0: result = skin;
default: result = 0;
}
return result;
}
stock SkinOrg(skin)
{
switch(skin)
{
case 2,107,142,143,144,148,151,162,163,166,167,170,175,176,177,179,180,181,234,235,250,305,306: return 1;
default: return 0;
}
return 0;
}
stock VeiculoBloqueado(v)
{
new result;
switch(v)
{
case 74, 406, 407, 416, 417, 420, 425, 427, 428, 430, 432, 433, 460, 470, 490, 497, 520, 528, 553, 577, 592, 596, 597, 598, 599, 601: result = v;
default: result = 0;
}
return result;
}
stock GetXYInFrontOfPlayer(playerid, &Float:x, &Float:y, Float:distance)
{
new Float:a;
GetPlayerPos(playerid, x, y, a);
GetPlayerFacingAngle(playerid, a);
if (GetPlayerVehicleID(playerid)) {
GetVehicleZAngle(GetPlayerVehicleID(playerid), a);
}
x += (distance * floatsin(-a, degrees));
y += (distance * floatcos(-a, degrees));
}
stock GetXYBehindOfVehicle(vehicleid, &Float:x, &Float:y, Float:distance)
{
new Float: a;
GetVehiclePos( vehicleid, x, y, a );
GetVehicleZAngle( vehicleid, a );
x += ( distance * floatsin( -a+180, degrees ));
y += ( distance * floatcos( -a+180, degrees ));
}
stock GetXYInFrontOfObject(objectid, &Float:x2, &Float:y2, &Float:z2, Float:distance)
{
new Float:a2;
GetObjectPos(objectid, x2, y2, z2);
GetObjectRot(objectid, a2, a2, a2);
x2 += (distance * floatsin(-a2, degrees));
y2 += (distance * floatcos(-a2, degrees));
}
stock GetXYInFrontOfPoint(&Float:x, &Float:y, Float:angle, Float:dist) {
x += (dist * floatsin(-angle, degrees));
y += (dist * floatcos(-angle, degrees));
}
stock CriarFazendas()
{
new str[400];
for(new i; i < MAX_FAZENDA; i++)
{
format(String, sizeof(String), "Fazendas/%d.ini", i);
if(DOF2_FileExists(String))
{
format(f_info[i][f_dono], 25, DOF2_GetString(String, "Dono"));
format(f_info[i][f_funcionario0], 25, DOF2_GetString(String, "Funcionario0"));
format(f_info[i][f_funcionario1], 25, DOF2_GetString(String, "Funcionario1"));
format(f_info[i][f_funcionario2], 25, DOF2_GetString(String, "Funcionario2"));
format(f_info[i][f_nome], 31, DOF2_GetString(String, "Nome"));
f_info[i][f_produtos] = DOF2_GetInt(String, "Produtos");
f_info[i][f_imposto] = DOF2_GetInt(String, "Imposto");
f_info[i][f_cofre] = DOF2_GetInt(String, "Cofre");
f_info[i][f_contratando] = DOF2_GetInt(String, "Contratando");
}
else
{
format(f_info[i][f_dono], 25, "Ninguem");
format(f_info[i][f_funcionario0], 25, "Ninguem");
format(f_info[i][f_funcionario1], 25, "Ninguem");
format(f_info[i][f_funcionario2], 25, "Ninguem");
format(f_info[i][f_nome], 31, "N/A");
f_info[i][f_produtos] = 0;
f_info[i][f_imposto] = 0;
f_info[i][f_cofre] = 0;
f_info[i][f_contratando] = 0;
DOF2_CreateFile(String);
DOF2_SetString(String, "Dono", f_info[i][f_dono]);
DOF2_SetString(String, "Funcionario0", f_info[i][f_funcionario0]);
DOF2_SetString(String, "Funcionario1", f_info[i][f_funcionario1]);
DOF2_SetString(String, "Funcionario2", f_info[i][f_funcionario2]);
DOF2_SetString(String, "Nome", f_info[i][f_nome]);
DOF2_SetInt(String, "Produtos", f_info[i][f_produtos]);
DOF2_SetInt(String, "Imposto", f_info[i][f_imposto]);
DOF2_SetInt(String, "Cofre", f_info[i][f_cofre]);
DOF2_SetInt(String, "Contratando", f_info[i][f_contratando]);
DOF2_SaveFile();
}
CreateDynamicObject(floatround(PosFazenda[i][0], floatround_round), PosFazenda[i][1], PosFazenda[i][2], PosFazenda[i][3], PosFazenda[i][4], PosFazenda[i][5], PosFazenda[i][6]);
f_info[i][f_pick] = CreateDynamicPickup(19132, 23, PickFazenda[i][0], PickFazenda[i][1], PickFazenda[i][2]);
format(str, sizeof(str), "{FFFFFF}Fazenda {6441A5}%s {FFFFFF}ID %d\n{FFFFFF}Dono: %s\n{FFFFFF}Funcionario 1: %s\n{FFFFFF}Funcionario 2: %s\n{FFFFFF}Funcionario 3: %s\n{FFFFFF}Valor: {00FF00}$500.000 {FFFFFF}e {FFFF00}50.000 Coins\n{FFFFFF}Fundos: {00FF00}$%d\n{FFFFFF}Produtos: {DF7401}%d und", f_info[i][f_nome], i, f_info[i][f_dono], f_info[i][f_funcionario0], f_info[i][f_funcionario1], f_info[i][f_funcionario2], f_info[i][f_cofre], f_info[i][f_produtos]);
f_info[i][f_texto] = CreateDynamic3DTextLabel(str, -1, PickFazenda[i][0], PickFazenda[i][1], PickFazenda[i][2], 8.0);
for(new c; c < 9; c++)
{
f_info[i][f_check][c] = CreateDynamicCP(CheckFazenda[i][c][0], CheckFazenda[i][c][1], CheckFazenda[i][c][2], 1.1, -1, -1, -1, 10.0);
f_info[i][f_textoplantas][c] = CreateDynamic3DTextLabel("{FFFFFF}Plantacao\n{FFFFFF}Jogador(a) Trabalhando: {FFF68F}Ninguem", -1, CheckFazenda[i][c][0], CheckFazenda[i][c][1], CheckFazenda[i][c][2], 30.0);
}
for(new v; v < 3; v++)
{
f_info[i][f_veiculo][v] = CreateVehicleC(468, VehFazenda[i][v][0], VehFazenda[i][v][1], VehFazenda[i][v][2], VehFazenda[i][v][3], -1, -1, 600);
}
}
}forward iQ_DelDrops();
public iQ_DelDrops(){
for(new i = 0; i < Qnt_Bolsas_Limt; i++)
if(BSArmas[i] != 0 && BS_TimeDrp[i] < gettime()){
uQ_ResetDrop(i);
}
return 1;
}
stock AddStaticVehicleC(jmodelo,Float:jX,Float:jY,Float:jZ,Float:jA,jCor1,jCor2){
new xSlot;
xSlot = AddStaticVehicle(jmodelo,jX,jY,jZ,jA,jCor1,jCor2);
rC_AntiCar[xSlot] = jmodelo;
return xSlot;
}
GetDia()
{
new WeekDay[26];
switch(((gettime()+334800)/86400-(gettime()+334800)/86400/7*7))
{
case 0: WeekDay = "deste domingo";
case 1: WeekDay = "desta segunda-feira";
case 2: WeekDay = "desta terca-feira";
case 3: WeekDay = "desta quarta-feira";
case 4: WeekDay = "desta quinta-feira";
case 5: WeekDay = "desta sexta-feira";
case 6: WeekDay = "deste sabado";
}
return WeekDay;
}
GetDay()
{
new WeekDay[15];
switch(((gettime()+334800)/86400-(gettime()+334800)/86400/7*7))
{
case 0: WeekDay = "Domingo";
case 1: WeekDay = "Segunda-feira";
case 2: WeekDay = "Terca-feira";
case 3: WeekDay = "Quarta-feira";
case 4: WeekDay = "Quinta-feira";
case 5: WeekDay = "Sexta-feira";
case 6: WeekDay = "Sabado";
}
return WeekDay;
}
GetMes()
{
new mess[10], d, m, a; getdate(a, m, d);
switch(m)
{
case 1: mess = "Janeiro";
case 2: mess = "Fevereiro";
case 3: mess = "Marco";
case 4: mess = "Abril";
case 5: mess = "Maio";
case 6: mess = "Junho";
case 7: mess = "Julho";
case 8: mess = "Agosto";
case 9: mess = "Setembro";
case 10: mess = "Outubro";
case 11: mess = "Novembro";
case 12: mess = "Dezembro";
}
return mess;
}
AttBarStatus(playerid)
{
SetPlayerProgressBarMaxValue(playerid, barfome[playerid], 6000.0);
SetPlayerProgressBarValue(playerid, barfome[playerid], FOME[playerid]);
SetPlayerProgressBarMaxValue(playerid, barsede[playerid], 4800.0);
SetPlayerProgressBarValue(playerid, barsede[playerid], SEDE[playerid]);
SetPlayerProgressBarMaxValue(playerid, barsono[playerid], 10800.0);
SetPlayerProgressBarValue(playerid, barsono[playerid], SONO[playerid]);
ShowPlayerProgressBar(playerid, barfome[playerid]);
ShowPlayerProgressBar(playerid, barsede[playerid]);
ShowPlayerProgressBar(playerid, barsono[playerid]);
return 1;
}
IsPlayerInLS(playerid) {
new Float:xls,Float:yls,Float:zls;
GetPlayerPos(playerid,xls,yls,zls);
if(xls > 0 && yls < 0) return 1;
return 0;
}
IsPlayerInSF(playerid) {
new Float:xls,Float:yls,Float:zls;
GetPlayerPos(playerid,xls,yls,zls);
if(xls < 0) return 1;
return 0;
}
IsPlayerInLV(playerid) {
new Float:xls,Float:yls,Float:zls;
GetPlayerPos(playerid,xls,yls,zls);
if(xls > 0 && yls > 0) return 1;
return 0;
}
forward HttpVPNInfo(playerid, response_code, data[]);
public HttpVPNInfo(playerid, response_code, data[])
{
new vpnMessage[64], sdialog[512];
if(response_code == 200 || response_code == 400) {
new Float:isVPN = floatstr(data);
if(isVPN < 0) {
new tmp = floatround(isVPN);
switch(tmp) {
case -1: {
format(vpnMessage, sizeof(vpnMessage), "{F74222}Erro (Input invalido)");
}
case -2: {
format(vpnMessage, sizeof(vpnMessage), "{F74222}Erro (IP Invalido)");
}
case -3: {
format(vpnMessage, sizeof(vpnMessage), "{F74222}Erro (Endereco nao rotervel / Endereco Privado)");
}
case -4: {
format(vpnMessage, sizeof(vpnMessage), "{F74222}Erro (Nao foi possivel acessar o banco de dados)");
}
case -5: {
format(vpnMessage, sizeof(vpnMessage), "{F74222}Erro (IP de origem banido)");
}
case -6: {
format(vpnMessage, sizeof(vpnMessage), "{F74222}Erro (Informacoes de contato invalidasn)");
}
default: {
format(vpnMessage, sizeof(vpnMessage), "{F74222}Erroo (Code: %d) (Data: %d)", response_code, tmp);
}
}
}
else if(isVPN == 0) {
format(vpnMessage, sizeof(vpnMessage), "{00FF00}Praticamente impossivel.");
}
else if(isVPN > 0 && isVPN < 0.6) {
format(vpnMessage, sizeof(vpnMessage), "{209120}Pouco provavel.");
}
else if(isVPN >= 0.6 && isVPN < 0.8) {
format(vpnMessage, sizeof(vpnMessage), "{E8A42E}Provavel.");
}
else if(isVPN >= 0.8 && isVPN < 1) {
format(vpnMessage, sizeof(vpnMessage), "{F7752F}Muito provavel.");
}
else if(isVPN >= 1) {
format(vpnMessage, sizeof(vpnMessage), "{FF0000}VPN detectada.");
}
}
else {
format(vpnMessage, sizeof(vpnMessage), "{F74222}Erroo (%d)", response_code);
}
format(sdialog, sizeof(sdialog),
"Opcoes\tInformacoes\n\
Status\t%s\n\
IP\t%s\n\
Reverse DNS\t%s\n\
Internet Username\t%s\n\
City\t%s\n\
Country\t%s\n\
Country Code\t%s\n\
ISP\t%s\n\
Latitude\t%s\n\
Longitude\t%s\n\
Time Zone\t%s\n\
Org\t%s\n\
Region\t%s\n\
Region Name\t%s\n\
Codigo Postal\t%s\n\
VPN/Proxy\t%s",
dPlayerInfo[targetID[playerid]][Statuss],
dPlayerInfo[targetID[playerid]][IPp],
dPlayerInfo[targetID[playerid]][Reverse],
dPlayerInfo[targetID[playerid]][As],
dPlayerInfo[targetID[playerid]][City],
dPlayerInfo[targetID[playerid]][Country],
dPlayerInfo[targetID[playerid]][CountryCode],
dPlayerInfo[targetID[playerid]][Isp],
dPlayerInfo[targetID[playerid]][Lat],
dPlayerInfo[targetID[playerid]][Lon],
dPlayerInfo[targetID[playerid]][TimeZone],
dPlayerInfo[targetID[playerid]][Org],
dPlayerInfo[targetID[playerid]][Region],
dPlayerInfo[targetID[playerid]][RegionName],
dPlayerInfo[targetID[playerid]][Zip],
vpnMessage);
ShowPlayerDialog(playerid, 555, DIALOG_STYLE_TABLIST_HEADERS, "{FFFF00}Informacoes do IP", sdialog, "OK", "");
return 1;
}
stock DestroyVehicleC(jvehicleid){
rC_AntiCar[jvehicleid] = 0;
DestroyVehicle(jvehicleid);
return jvehicleid;
}
forward DesmanchandoVeh(playerid);
public DesmanchandoVeh(playerid)
{
KillTimer(TimerDesmanchando[playerid]);
EstaDesmanchando[playerid] = 0;
TogglePlayerControllable(playerid, 1);
if(IsPlayerInRangeOfPoint(playerid, 5.0, 1348.4828,9.3824,50.7206) || IsPlayerInRangeOfPoint(playerid, 5.0, 2556.2622,-844.7983,91.0659))
{
if(IsPlayerInAnyVehicle(playerid))
{
DinheiroSujo[playerid] += 35000;
GameTextForPlayer(playerid, "~w~DINHEIRO SUJO+ ~g~$35000", 3000, 3);
DestroyVehicleC(GetPlayerVehicleID(playerid));
GiveProcurado(playerid, 1);
}
else
{
SendClientMessage(playerid, COR_ERRO, "| AVISO | O veiculo nao foi desmanchado motivo nao estava no veiculo");
}
}
else
{
SendClientMessage(playerid, COR_ERRO, "| AVISO | O veiculo nao foi desmanchado motivo estava longe do desmanche");
}
return 1;
}
forward CriandoRG(playerid);
public CriandoRG(playerid)
{
TogglePlayerControllable(playerid, 1);
GameTextForPlayer(playerid, "~g~(RG) RG CRIADO USE /RG PRA VER SEUS DOCUMENTOS (RG)" , 5000,3);
RgPlayer[playerid] = 1;
return 1;
}
forward HttpIPInfo(playerid, response_code, data[]);
public HttpIPInfo(playerid, response_code, data[])
{
if(response_code == 200) {
new output[14][64], string[160];
strexplode(output, data, ",");
dPlayerInfo[targetID[playerid]][Statuss] = output[0];
if(strfind(output[0], "sucess")) {
format(dPlayerInfo[targetID[playerid]][Statuss], 64, "{00FF00}Sucesso");
}
else {
format(dPlayerInfo[targetID[playerid]][Statuss], 64, "{F74222}Falha");
}
dPlayerInfo[targetID[playerid]][Country] = output[1];
dPlayerInfo[targetID[playerid]][CountryCode] = output[2];
dPlayerInfo[targetID[playerid]][Region] = output[3];
dPlayerInfo[targetID[playerid]][RegionName] = output[4];
dPlayerInfo[targetID[playerid]][City] = output[5];
dPlayerInfo[targetID[playerid]][Zip] = output[6];
dPlayerInfo[targetID[playerid]][Lat] = output[7];
dPlayerInfo[targetID[playerid]][Lon] = output[8];
dPlayerInfo[targetID[playerid]][TimeZone] = output[9];
dPlayerInfo[targetID[playerid]][Isp] = output[10];
dPlayerInfo[targetID[playerid]][Org] = output[11];
dPlayerInfo[targetID[playerid]][As] = output[12];
dPlayerInfo[targetID[playerid]][Reverse] = output[13];
RemoveChars(targetID[playerid]);
format(string, sizeof(string), "%s%s", HTTP_VPN_API_URL, dPlayerInfo[targetID[playerid]][IPp]);
HTTP(playerid, HTTP_GET, string, "", "HttpVPNInfo");
}
else {
format(String, sizeof(String), "| ERRO | Ocorreu um erro obtendo os dados do IP. (Code: %d) (%s)", response_code, data);
SendClientMessage(playerid, COR_ERRO, String);
}
return 1;
}
stock RemoveChars(tID)
{
strreplace(dPlayerInfo[tID][Country], "\"", "");
strreplace(dPlayerInfo[tID][CountryCode], "\"", "");
strreplace(dPlayerInfo[tID][Region], "\"", "");
strreplace(dPlayerInfo[tID][RegionName], "\"", "");
strreplace(dPlayerInfo[tID][City], "\"", "");
strreplace(dPlayerInfo[tID][Zip], "\"", "");
strreplace(dPlayerInfo[tID][Lat], "\"", "");
strreplace(dPlayerInfo[tID][Lon], "\"", "");
strreplace(dPlayerInfo[tID][TimeZone], "\"", "");
strreplace(dPlayerInfo[tID][Isp], "\"", "");
strreplace(dPlayerInfo[tID][Org], "\"", "");
strreplace(dPlayerInfo[tID][As], "\"", "");
strreplace(dPlayerInfo[tID][Reverse], "\"", "");
return 1;
}
stock IsPlayerInPlace(playerid, Float:XMin, Float:YMin, Float:XMax, Float:YMax)
{
static Float:x,Float:y,Float:z;
GetPlayerPos(playerid, x, y, z);
if( x >= XMin && y >= YMin && x < XMax && y < YMax )
return 1;
return false;
}
stock Hash(password[], salt[] = "78sdjs86d2h")
{
new ret_hash[65];
SHA256_PassHash(password, salt, ret_hash, sizeof(ret_hash));
return ret_hash;
}forward tQ_DelCarFX();
public tQ_DelCarFX(){
for (new i = 0; i < rC_MaxVehcl; i++)
if(rC_AntiCar[i] != 0 && GetVehicleModel(i) == 0)
rC_AntiCar[i] = 0;
return 1;
}stock CreateVehicleC(jmodelo,Float:jX,Float:jY,Float:jZ,Float:jA,jCor1,jCor2,jaddsiren=0){
new xSlot;
xSlot = CreateVehicle(jmodelo,jX,jY,jZ,jA,jCor1,jCor2, jaddsiren);
rC_AntiCar[xSlot] = jmodelo;
return xSlot;
}
stock wTPegDiret(playerid){
new name[24], full[50];
GetPlayerName(playerid,name,sizeof(name));
format(full,sizeof(full),"%s/%s.txt",WtPATHx,name);
return full;
}
stock SendClientMessageInRange(Float:_r, playerid, _s[],c1,c2,c3,c4,c5)
{
new Float:_x, Float:_y, Float:_z;
GetPlayerPos(playerid, _x, _y, _z);
for(new i=0; i<MAX_PLAYERS; i++)
{
if(IsPlayerConnected(i))
{
if(GetPlayerVirtualWorld(i) == GetPlayerVirtualWorld(playerid))
{
if(GetPlayerDistanceFromPoint(i,_x,_y,_z) < _r/16)
SendClientMessage(i, c1, _s);
else if(GetPlayerDistanceFromPoint(i,_x,_y,_z) < _r/8)
SendClientMessage(i, c2, _s);
else if(GetPlayerDistanceFromPoint(i,_x,_y,_z) < _r/4)
SendClientMessage(i, c3, _s);
else if(GetPlayerDistanceFromPoint(i,_x,_y,_z) < _r/2)
SendClientMessage(i, c4, _s);
else if(GetPlayerDistanceFromPoint(i,_x,_y,_z) < _r)
SendClientMessage(i, c5, _s);
}
}
}
return true;
}
stock Astra_DestruirTextdrawsRP(playerid)
{
PlayerTextDrawDestroy(playerid, TextTelaPreta[playerid]);
PlayerTextDrawDestroy(playerid, MsgText[playerid]);
PlayerTextDrawDestroy(playerid, TextProduzirArma[playerid]);
PlayerTextDrawDestroy(playerid, TextPresoP[playerid]);
PlayerTextDrawDestroy(playerid, TextSkinP[playerid][0]);
PlayerTextDrawDestroy(playerid, TextSkinP[playerid][1]);
PlayerTextDrawDestroy(playerid, TextAbastecerP[playerid][0]);
PlayerTextDrawDestroy(playerid, TextAbastecerP[playerid][1]);
PlayerTextDrawDestroy(playerid, TextAbastecerP[playerid][2]);
PlayerTextDrawDestroy(playerid, TextCargaP[playerid][0]);
PlayerTextDrawDestroy(playerid, TextCargaP[playerid][1]);
PlayerTextDrawDestroy(playerid, TextTaximetroP[playerid][0]);
PlayerTextDrawDestroy(playerid, StatusP[playerid][0]);
PlayerTextDrawDestroy(playerid, RadioTexFDawP[playerid][0]);
PlayerTextDrawDestroy(playerid, TextTaximetroP[playerid][1]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][0]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][1]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][2]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][3]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][4]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][5]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][6]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][7]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][8]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][9]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][10]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][11]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][12]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][13]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][14]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][15]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][16]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][17]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][18]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][19]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][20]);
PlayerTextDrawDestroy(playerid, TextLoginP[playerid][21]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][0]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][1]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][2]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][3]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][4]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][5]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][6]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][7]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][8]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][9]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][10]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][11]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][12]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][13]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][14]);
PlayerTextDrawDestroy(playerid, TextVelo[playerid][15]);
PlayerTextDrawDestroy(playerid, TextSniperInfoP[playerid][0]);
PlayerTextDrawDestroy(playerid, TextSniperInfoP[playerid][1]);
PlayerTextDrawDestroy(playerid, TextSniperInfoP[playerid][2]);
PlayerTextDrawDestroy(playerid, TextSniperInfoP[playerid][3]);
PlayerTextDrawDestroy(playerid, TextConceP[playerid][0]);
PlayerTextDrawDestroy(playerid, TextConceP[playerid][1]);
PlayerTextDrawDestroy(playerid, TextConceP[playerid][2]);
PlayerTextDrawDestroy(playerid, BoxText[playerid][0]);
PlayerTextDrawDestroy(playerid, TextEstrelas[playerid][0]);
PlayerTextDrawDestroy(playerid, TextEstrelas[playerid][1]);
PlayerTextDrawDestroy(playerid, TextSkinMenuP[playerid][0]);
PlayerTextDrawDestroy(playerid, TextSkinMenuP[playerid][1]);
PlayerTextDrawDestroy(playerid, TextSkinMenuP[playerid][2]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][0]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][1]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][2]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][3]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][4]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][5]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][6]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][7]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][8]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][9]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][10]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][11]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][12]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][13]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][14]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][15]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][16]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][17]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][18]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][19]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][20]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][21]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][22]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][23]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][24]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][25]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][26]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][27]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][28]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][29]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][30]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][31]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][32]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][33]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][34]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][35]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][36]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][37]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][38]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][39]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][40]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][41]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][42]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][43]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][44]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][45]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][46]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][47]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][48]);
PlayerTextDrawDestroy(playerid, TextInvP[playerid][49]);
PlayerTextDrawDestroy(playerid, TextColetarItemP[playerid][0]);
PlayerTextDrawDestroy(playerid, TextColetarItemP[playerid][1]);
PlayerTextDrawDestroy(playerid, TextColetarItemP[playerid][2]);
PlayerTextDrawDestroy(playerid, TextColetarItemP[playerid][3]);
PlayerTextDrawDestroy(playerid, TextColetarItemP[playerid][4]);
PlayerTextDrawDestroy(playerid, TextColetarItemP[playerid][5]);
PlayerTextDrawDestroy(playerid, TextColetarItemP[playerid][6]);
PlayerTextDrawDestroy(playerid, TextColetarItemP[playerid][7]);
PlayerTextDrawDestroy(playerid, TextColetarItemP[playerid][8]);
PlayerTextDrawDestroy(playerid, TextColetarItemP[playerid][9]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][0]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][1]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][2]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][3]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][4]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][5]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][6]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][7]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][8]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][9]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][10]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][11]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][12]);
PlayerTextDrawDestroy(playerid, TextBarraquinha[playerid][13]);
PlayerTextDrawDestroy(playerid, TextPresente[playerid][0]);
PlayerTextDrawDestroy(playerid, TextPresente[playerid][1]);
PlayerTextDrawDestroy(playerid, TextPresente[playerid][2]);
PlayerTextDrawDestroy(playerid, TextPresente[playerid][3]);
PlayerTextDrawDestroy(playerid, TextPresente[playerid][4]);
PlayerTextDrawDestroy(playerid, TextImobiliaria[playerid][0]);
PlayerTextDrawDestroy(playerid, TextImobiliaria[playerid][1]);
PlayerTextDrawDestroy(playerid, TextImobiliaria[playerid][2]);
PlayerTextDrawDestroy(playerid, TextImobiliaria[playerid][3]);
PlayerTextDrawDestroy(playerid, TextImobiliaria[playerid][4]);
PlayerTextDrawDestroy(playerid, TextImobiliaria[playerid][5]);
PlayerTextDrawDestroy(playerid, TextImobiliaria[playerid][6]);
PlayerTextDrawDestroy(playerid, TextImobiliaria[playerid][7]);
PlayerTextDrawDestroy(playerid, TextImobiliaria[playerid][8]);
PlayerTextDrawDestroy(playerid, TextImobiliaria[playerid][9]);
PlayerTextDrawDestroy(playerid, TextImobiliaria[playerid][10]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][0]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][1]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][2]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][3]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][4]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][5]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][6]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][7]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][8]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][9]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][10]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][11]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][12]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][13]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][14]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][15]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][16]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][17]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][18]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][19]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][20]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][21]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][22]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][23]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][24]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][25]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][26]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][27]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][28]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][29]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][30]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][31]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][32]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][33]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][34]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][35]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][36]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][37]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][38]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][39]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][40]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][41]);
PlayerTextDrawDestroy(playerid, TextMegaSena[playerid][42]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][0]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][1]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][2]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][3]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][4]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][5]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][6]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][7]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][8]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][9]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][10]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][11]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][12]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][13]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][14]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][15]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][16]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][17]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][18]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][19]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][20]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][21]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][22]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][23]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][24]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][25]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][26]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][27]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][28]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][29]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][30]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][31]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][32]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][33]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][34]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][35]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][36]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][37]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][38]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][39]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][40]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][41]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][42]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][43]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][44]);
PlayerTextDrawDestroy(playerid, TextLojaItens[playerid][45]);
PlayerTextDrawDestroy(playerid, TextCellP[playerid][0]);
PlayerTextDrawDestroy(playerid, TextCellP[playerid][1]);
PlayerTextDrawDestroy(playerid, TextCellP[playerid][2]);
PlayerTextDrawDestroy(playerid, TextCellP[playerid][3]);
PlayerTextDrawDestroy(playerid, TextCellP[playerid][4]);
PlayerTextDrawDestroy(playerid, TextCellP[playerid][5]);
PlayerTextDrawDestroy(playerid, TextCellP[playerid][6]);
PlayerTextDrawDestroy(playerid, TextBTCP[playerid][0]);
PlayerTextDrawDestroy(playerid, TextBTCP[playerid][1]);
return 1;
}
stock Astra_EscolherModo(playerid)
{
ShowPlayerDialog(playerid, ASTRA_DIALOG_MODO, DIALOG_STYLE_LIST, "{FFFFFF}Astra {FF4040}RP{FFFFFF}/{40A0FF}PVP", "{40A0FF}PVP {FFFFFF}- Arenas, combate e ranking\n{FF4040}RP {FFFFFF}- Cidade, empregos e roleplay", "Entrar", "");
return 1;
}
stock Astra_IniciarRP(playerid)
{
AstraModo[playerid] = ASTRA_MODO_RP;
TogglePlayerSpectating(playerid, 0);
SpawnPlayer(playerid);
return 1;
}
stock Astra_IniciarPVP(playerid)
{
AstraModo[playerid] = ASTRA_MODO_PVP;
StopAudioStreamForPlayer(playerid);
Astra_DestruirTextdrawsRP(playerid);
PVP_OnPlayerConnect(playerid);
for(new i = 0; i < MAX_PLAYERS; i++)
{
if(i != playerid && IsPlayerConnected(i) && AstraModo[i] == ASTRA_MODO_PVP)
{
ShowPlayerNameTagForPlayer(playerid, i, 0);
ShowPlayerNameTagForPlayer(i, playerid, 0);
}
}
format(PVP_arquivo, sizeof(PVP_arquivo), PVP_PASTA_CONTAS, PVP_PlayerName(playerid));
if(!dini_Exists(PVP_arquivo))
{
PVP_VSenha[playerid] = "astra";
PVP_VGenero[playerid] = 1;
PVP_CriarDadosPlayer(playerid);
}
else
{
PVP_VerificarLogin[playerid] = false;
for(new i; i < sizeof(PVP_Public_EscolherSpawn); i++) TextDrawShowForPlayer(playerid, PVP_Public_EscolherSpawn[i]);
SelectTextDraw(playerid, -1);
}
return 1;
}
stock Astra_RespostaModo(playerid, response, listitem)
{
if(!response) return Astra_EscolherModo(playerid);
if(listitem == 0) Astra_IniciarPVP(playerid);
else Astra_IniciarRP(playerid);
return 1;
}
